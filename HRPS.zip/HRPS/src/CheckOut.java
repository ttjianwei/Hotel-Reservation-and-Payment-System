
import java.util.*;

/**
 * represent when the customer check out
 * one reservation / walk in will make one check out 
 * @author FSP4 Group 5
 *
 */
public class CheckOut {
	/**
	 * The walkIn class to store the reservation class
	 */
	WalkIns r = new WalkIns();
	/**
	 * The walk in menu to remove the walk in in the arraylist
	 */
	WalkInMenu wm = new WalkInMenu();
	/**
	 * the payment class to call the print bill method
	 */
	Payment p = new Payment();
	/**
	 * The reservationMenu class to remove the reservation that is to be checked out
	 */
	ReservationMenu nr = new ReservationMenu();
	/**
	 * InputOutput class to write information into the XML
	 */
	InputOutput io = new InputOutput();
	/**
	 * OrderController to delete any order after checkout
	 */
	OrderController order = new OrderController();
	
	/**
	 * Check out customer with room number and print out the bill invoice;
	 * @param rd ArrayList of the reservation
	 * @param w ArrayList of walk ins
	 * @param rms ArrayList of the room
	 * @param o ArrayList of room service orders
	 */
	public void checkoutCust(ArrayList<Reservation> rd,ArrayList<WalkIns> w,ArrayList<Room> rms,ArrayList<Order> o)
	{
		Scanner sc = new Scanner(System.in);
		
		int rm=0; 
		int getrm=0;
		boolean found=false;
		int position =-1;
		boolean res = false;

		
		try {

			System.out.println("Enter room number to checkout: ");
			rm = sc.nextInt();
			sc.nextLine();
			String rmNo = "0"+rm;
			int isOcc = validateRoomAva(rmNo,rms);
			for(int i=0;i<rd.size();i++)
			{
				getrm = Integer.parseInt(rd.get(i).getResRoomNo());
				if(getrm == rm && isOcc==1)
				{
					r = (WalkIns) rd.get(i);
					position =i;
					found = true;
					res = true;
				}
			}
			//find in walkin list
			if(!found)
			{
				for(int i=0;i<w.size();i++)
				{
					getrm = Integer.parseInt(w.get(i).getRoomNo());
					if(getrm == rm && isOcc==1)
					{
						r = w.get(i);
						position =i;
						found = true;
					}
				}
			}

			
			if(found)
			{
				p.printBillInvoice(r,res,o);
				order.removeOrder(o, rmNo);
				changeRoomStatus(rmNo,rms);
				if(res)
				{
					nr.removeReservation(position);
					rd.remove(position);
				}
				else
				{
					wm.removeWalkin(position, w);
				}
			}
			else
			{
				System.out.println("Room not found/not check-in.");
			}
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
/**
 * Validation method to check if the room is occupied
 * @param rmNumber The room number that is to be checkout
 * @param rm The ArrayList of the rooms
 * @return flag 1 if is occupied and -1 if room is not found or is not occupied
 */
	public int validateRoomAva(String rmNumber,ArrayList<Room> rm) 
	{
		int flag = -1;
		for(int i=0;i<rm.size();i++)
		{
			if((rm.get(i).getRoomNo().equals(rmNumber)) && (rm.get(i).getAvailability().equals("Occupied")) )
			{
				flag =1;
			}
		}
		
		return 1;
	}
	
/**
 * Change the room status back to vacant and not check in
 * @param rmNumber The room number of the room to be changed
 * @param rm The ArrayList of rooms
 */
	public void changeRoomStatus(String rmNumber,ArrayList<Room> rm)
	{
		//change for arraylist
		for(int i=0;i<rm.size();i++)
		{
			if(rm.get(i).getRoomNo().equals(rmNumber))
			{
				rm.get(i).setAvailibility("Vacant");
				rm.get(i).setCheckInStatus("N");
			}
		}
		
		//change for XML
		io.checkOutWriteToFile(rmNumber);
	}

	

}
