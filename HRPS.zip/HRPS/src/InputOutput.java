
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
Represent handler for reading .xml and writing to .xml file 
@author FSP4
@version 1.0
@since 2016-04-06
*/ 
public class InputOutput {
	private ArrayList<Reservation> rd = new ArrayList<Reservation>();
	private ArrayList<Guest> guests = new ArrayList<Guest>();
    private ArrayList<Room> room = new ArrayList<Room>();
    private ArrayList<RoomService> rs = new ArrayList<RoomService>();
    private ArrayList<WalkIns> wi = new ArrayList<WalkIns>();
    private ArrayList<Order> order = new ArrayList<Order>();
    
    
    /**
    method to write guest details into guestList.xml file
	@param guest guest object with all the guest details
    */ 
	public void writeToGuestFile(Guest guest){
		
		try{
			String filepath = "guestList.xml";
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(filepath);
			
			
			 
			Element dataTag = doc.getDocumentElement();
			Element guestListTag =  (Element) dataTag.getElementsByTagName("Guest_List").item(0);
			Element newGuest = doc.createElement("Guest");
			Element name= doc.createElement("name");
			Element address = doc.createElement("address");
			Element country = doc.createElement("country");
			Element gender = doc.createElement("gender");
			Element nationality = doc.createElement("nationality");
			Element contact = doc.createElement("contact");
			Element creditCardNo = doc.createElement("creditCardNo");
			Element creditCardCSV = doc.createElement("creditCardCSV");
			Element creditCardExpDate= doc.createElement("creditCardExpDate");
			Element identity = doc.createElement("identity");
			name.setTextContent(guest.getGuestName());//write Guest's Name
			address.setTextContent(guest.getAddress()); //write Guest Address
			country.setTextContent(guest.getCountry());	//write Guest's country
			gender.setTextContent(guest.getGender()); //write Guest's gender
			nationality.setTextContent(guest.getNationality());	//write Guest nationality
			contact.setTextContent(guest.getContact()); //write Guest's contact
			creditCardNo.setTextContent(guest.getCreditCardNo()); //write creditCard details
			creditCardCSV.setTextContent(guest.getCreditCardCSV());//write creditCard details
			creditCardExpDate.setTextContent(guest.getCreditCardExpDate());	//write creditCard details
			identity.setTextContent(guest.getIdentity()); //Write identification No.
		 
			newGuest.appendChild(name);
			newGuest.appendChild(address);
			newGuest.appendChild(country);
			newGuest.appendChild(gender);
			newGuest.appendChild(nationality);
			newGuest.appendChild(contact);
			newGuest.appendChild(creditCardNo);
			newGuest.appendChild(creditCardCSV);
			newGuest.appendChild(creditCardExpDate);
			newGuest.appendChild(identity);
			guestListTag.appendChild(newGuest);
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);
			
			StreamResult result = new StreamResult(new File(filepath));
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			transformer.transform(source, result);
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	
 /**
    method to write room details into roomList.xml file
    @param room Room object with all the room details
 */ 
public void writeToRoomFile(Room room){
		
		try{
			String filepath = "roomList.xml";
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(filepath);
			
			
			 
			Element roomTag = doc.getDocumentElement();
			Element roomListTag =  (Element) roomTag.getElementsByTagName("Room_List").item(0);
			Element newRoom = doc.createElement("room");
			Element roomNo = doc.createElement("roomNo");
			Element roomType = doc.createElement("roomType");
			Element bedType= doc.createElement("bedType");
			Element smoking = doc.createElement("smoking");
			Element startDate = doc.createElement("startDate");
			Element endDate = doc.createElement("endDate");
			Element wifi = doc.createElement("wifi");
			Element roomView = doc.createElement("roomView");
			Element available = doc.createElement("availability");
			Element checkInStatus = doc.createElement("checkInStatus");
			roomNo.setTextContent(room.getRoomNo());
			roomType.setTextContent(room.getRoomType()); 
			bedType.setTextContent(room.getBedType());	
			smoking.setTextContent(room.isSmoking()); 
			startDate.setTextContent(room.getStartDate());	
			endDate.setTextContent(room.getEndDate()); 
			wifi.setTextContent(room.isWifi());
			roomView.setTextContent(room.isRoomView());
			available.setTextContent(room.getAvailability());
			checkInStatus.setTextContent(room.getCheckInStatus());
			newRoom.appendChild(roomNo);
			newRoom.appendChild(roomType);
			newRoom.appendChild(bedType);
			newRoom.appendChild(smoking);
			newRoom.appendChild(startDate);
			newRoom.appendChild(endDate);
			newRoom.appendChild(wifi);
			newRoom.appendChild(roomView);
			newRoom.appendChild(available);
			newRoom.appendChild(checkInStatus);
			roomListTag.appendChild(newRoom);
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);
			
			StreamResult result = new StreamResult(new File(filepath));
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			transformer.transform(source, result);
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}


/**
method to write reservation details into reservations.xml file
@param reservation Reservation object with all the reservation details
*/ 
public void writeToResFile(Reservation reservation){
	
	try{
		String filepath = "reservations.xml";
		DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
		Document doc = docBuilder.parse(filepath);
		
		
		 
		Element reservationTag = doc.getDocumentElement();
		Element reservationListTag =  (Element) reservationTag.getElementsByTagName("reservation_list").item(0);
		Element newReservation = doc.createElement("reservation");
		Element newResID = doc.createElement("resID");
		Element roomNo = doc.createElement("roomNo");
		Element noOfGuest = doc.createElement("noOfGuest");
		Element roomType = doc.createElement("roomType");
		Element bedType= doc.createElement("bedType");
		Element smoking = doc.createElement("smoking");
		Element startDate = doc.createElement("startDate");
		Element endDate = doc.createElement("endDate");
		Element wifi = doc.createElement("wifi");
		Element roomView = doc.createElement("roomView");
		Element available = doc.createElement("availability");
		Element checkInStatus = doc.createElement("checkInStatus");
		Element name= doc.createElement("name");
		Element address = doc.createElement("address");
		Element country = doc.createElement("country");
		Element gender = doc.createElement("gender");
		Element nationality = doc.createElement("nationality");
		Element contact = doc.createElement("contact");
		Element creditCardNo = doc.createElement("creditCardNo");
		Element creditCardCSV = doc.createElement("creditCardCSV");
		Element creditCardExpDate= doc.createElement("creditCardExpDate");
		Element identity = doc.createElement("identity");
		Element resStatus = doc.createElement("resStatus");
		Element checkInDate = doc.createElement("checkInDate");
		Element checkInTime = doc.createElement("checkInTime");
		newResID.setTextContent(reservation.getResID());
		roomNo.setTextContent(reservation.getResRoomNo()); 
		noOfGuest.setTextContent(reservation.getNoOfGuest());
		roomType.setTextContent(reservation.getResRoomType());	
		bedType.setTextContent(reservation.getResBedType()); 
		smoking.setTextContent(reservation.getResSmoking());	
		startDate.setTextContent(reservation.getResRoomStartDate()); 
		endDate.setTextContent(reservation.getResRoomEndDate());
		wifi.setTextContent(reservation.getResRoomWifi());
		roomView.setTextContent(reservation.getResRoomView());
		available.setTextContent(reservation.getResAvailability());
		checkInStatus.setTextContent(reservation.getCheckInStatus());
		name.setTextContent(reservation.getGuestName());//write Guest's Name
		address.setTextContent(reservation.getGuestAddress()); //write Guest Address
		country.setTextContent(reservation.getCountry());//write Guest's country
		gender.setTextContent(reservation.getGuestGender()); //write Guest's gender
		nationality.setTextContent(reservation.getGuestNationality());	//write Guest nationality
		contact.setTextContent(reservation.getGuestContacts()); //write Guest's contact
		creditCardNo.setTextContent(reservation.getCreditCardNo()); //write creditCard details
		creditCardCSV.setTextContent(reservation.getCreditCardCSV());//write creditCard details
		creditCardExpDate.setTextContent(reservation.getCreditCardExpDate());	//write creditCard details
		identity.setTextContent(reservation.getGuestIdentity()); //Write identification No.
		resStatus.setTextContent(reservation.getResStatus());
		checkInDate.setTextContent(reservation.getCheckInDate()); //Write identification No.
		checkInTime.setTextContent(reservation.getCheckInTime());
		newReservation.appendChild(newResID);
		newReservation.appendChild(roomNo);
		newReservation.appendChild(roomType);
		newReservation.appendChild(noOfGuest);
		newReservation.appendChild(bedType);
		newReservation.appendChild(smoking);
		newReservation.appendChild(startDate);
		newReservation.appendChild(endDate);
		newReservation.appendChild(wifi);
		newReservation.appendChild(roomView);
		newReservation.appendChild(available);
		newReservation.appendChild(checkInStatus);
		newReservation.appendChild(name);
		newReservation.appendChild(address);
		newReservation.appendChild(country);
		newReservation.appendChild(gender);
		newReservation.appendChild(nationality);
		newReservation.appendChild(contact);
		newReservation.appendChild(creditCardNo);
		newReservation.appendChild(creditCardCSV);
		newReservation.appendChild(creditCardExpDate);
		newReservation.appendChild(identity);
		newReservation.appendChild(resStatus);
		newReservation.appendChild(checkInDate);
		newReservation.appendChild(checkInTime);
		reservationListTag.appendChild(newReservation);
		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		DOMSource source = new DOMSource(doc);
		
		StreamResult result = new StreamResult(new File(filepath));
		transformer.setOutputProperty(OutputKeys.INDENT, "yes");
		transformer.transform(source, result);
	}
	catch(Exception e){
		e.printStackTrace();
	}
}

/**
method to write walk-in details into reservations.xml file
@param walkIn WalkIns object with all the guest walk-in details
*/ 
public void writeToWalkInFile(WalkIns walkIn){
	
	try{
		String filepath = "walkIn.xml";
		DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
		Document doc = docBuilder.parse(filepath);
		
		
		 
		Element walkInTag = doc.getDocumentElement();
		Element walkInTagListTag =  (Element) walkInTag .getElementsByTagName("walkIn_list").item(0);
		Element newWalkIn = doc.createElement("walkIn");
		Element roomNo = doc.createElement("roomNo");
		Element noOfGuest = doc.createElement("noOfGuest");
		Element roomType = doc.createElement("roomType");
		Element bedType= doc.createElement("bedType");
		Element smoking = doc.createElement("smoking");
		Element startDate = doc.createElement("startDate");
		Element endDate = doc.createElement("endDate");
		Element wifi = doc.createElement("wifi");
		Element roomView = doc.createElement("roomView");
		Element available = doc.createElement("availability");
		Element checkInStatus = doc.createElement("checkInStatus");
		Element name= doc.createElement("name");
		Element address = doc.createElement("address");
		Element country = doc.createElement("country");
		Element gender = doc.createElement("gender");
		Element nationality = doc.createElement("nationality");
		Element contact = doc.createElement("contact");
		Element creditCardNo = doc.createElement("creditCardNo");
		Element creditCardCSV = doc.createElement("creditCardCSV");
		Element creditCardExpDate= doc.createElement("creditCardExpDate");
		Element identity = doc.createElement("identity");
		roomNo.setTextContent(walkIn.getRoomNo()); 
		noOfGuest.setTextContent(walkIn.getNoOfGuest());
		roomType.setTextContent(walkIn.getRoomType());	
		bedType.setTextContent(walkIn.getBedType()); 
		smoking.setTextContent(walkIn.getSmoking());	
		startDate.setTextContent(walkIn.getRoomStartDate()); 
		endDate.setTextContent(walkIn.getRoomEndDate());
		wifi.setTextContent(walkIn.getRoomWifi());
		roomView.setTextContent(walkIn.getRoomView());
		available.setTextContent(walkIn.getAvailability());
		checkInStatus.setTextContent(walkIn.getCheckInStatus());
		name.setTextContent(walkIn.getGuestName());//write Guest's Name
		address.setTextContent(walkIn.getGuestAddress()); //write Guest Address
		country.setTextContent(walkIn.getCountry());//write Guest's country
		gender.setTextContent(walkIn.getGuestGender()); //write Guest's gender
		nationality.setTextContent(walkIn.getGuestNationality());	//write Guest nationality
		contact.setTextContent(walkIn.getGuestContacts()); //write Guest's contact
		creditCardNo.setTextContent(walkIn.getCreditCardNo()); //write creditCard details
		creditCardCSV.setTextContent(walkIn.getCreditCardCSV());//write creditCard details
		creditCardExpDate.setTextContent(walkIn.getCreditCardExpDate());	//write creditCard details
		identity.setTextContent(walkIn.getGuestIdentity()); //Write identification No.
		newWalkIn.appendChild(roomNo);
		newWalkIn.appendChild(roomType);
		newWalkIn.appendChild(noOfGuest);
		newWalkIn.appendChild(bedType);
		newWalkIn.appendChild(smoking);
		newWalkIn.appendChild(startDate);
		newWalkIn.appendChild(endDate);
		newWalkIn.appendChild(wifi);
		newWalkIn.appendChild(roomView);
		newWalkIn.appendChild(available);
		newWalkIn.appendChild(checkInStatus);
		newWalkIn.appendChild(name);
		newWalkIn.appendChild(address);
		newWalkIn.appendChild(country);
		newWalkIn.appendChild(gender);
		newWalkIn.appendChild(nationality);
		newWalkIn.appendChild(contact);
		newWalkIn.appendChild(creditCardNo);
		newWalkIn.appendChild(creditCardCSV);
		newWalkIn.appendChild(creditCardExpDate);
		newWalkIn.appendChild(identity);
		walkInTagListTag.appendChild(newWalkIn);
		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		DOMSource source = new DOMSource(doc);
		
		StreamResult result = new StreamResult(new File(filepath));
		transformer.setOutputProperty(OutputKeys.INDENT, "yes");
		transformer.transform(source, result);
	}
	catch(Exception e){
		e.printStackTrace();
	}
	
}

/**
method to update reservation details in reservations.xml
@param resPosition reservation position in the system
@param roomPosition room position in the system
*/ 
public void checkInWriteToFile(int resPosition, int roomPosition){
	
	try{
	String filepath = "reservations.xml";
	DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
	DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
	Document doc = docBuilder.parse(filepath);
	TransformerFactory transformerFactory = TransformerFactory.newInstance();
	Transformer transformer = transformerFactory.newTransformer();
	DOMSource source = new DOMSource(doc);
	StreamResult result = new StreamResult(new File(filepath));
	Node nodes = doc.getElementsByTagName("reservation").item(resPosition);
	NodeList list = nodes.getChildNodes();

	
	for (int i = 0; i != list.getLength(); ++i) {
		Node child = list.item(i);

		if (child.getNodeName().equals("checkInStatus")) {
			child.getFirstChild().setNodeValue("Y");
		}
		if (child.getNodeName().equals("availability")) {
			child.getFirstChild().setNodeValue("Occupied");
		}
	}
	//open RoomList file
	String filepath2 = "roomList.xml";
	DocumentBuilderFactory docFactory2 = DocumentBuilderFactory.newInstance();
	DocumentBuilder docBuilder2 = docFactory2.newDocumentBuilder();
	Document doc2 = docBuilder2.parse(filepath2);
	TransformerFactory transformerFactory2 = TransformerFactory.newInstance();
	Transformer transformer2 = transformerFactory2.newTransformer();
	DOMSource source2 = new DOMSource(doc2);
	StreamResult result2 = new StreamResult(new File(filepath2));
	Node nodes2 = doc2.getElementsByTagName("room").item(roomPosition);
	NodeList list2 = nodes2.getChildNodes();
	
	for (int i = 0; i != list2.getLength(); ++i) {
		Node child = list2.item(i);

		if (child.getNodeName().equals("checkInStatus")) {
			child.getFirstChild().setNodeValue("Y");
		}
		if (child.getNodeName().equals("availability")) {
			child.getFirstChild().setNodeValue("Occupied");
		}
	}
	transformer.transform(source, result);
	transformer2.transform(source2, result2);
	
}
	catch(Exception e){
		e.printStackTrace();
	}

}

public void writeOrderXML(ArrayList<String> arOrders, String rmNumber, String guestRemarks) {
	String foodItem = "";
	double foodTotalPrice = 0.0;
	Calendar cal = Calendar.getInstance();
	SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");

	try {
	
		String filepath = "orderRoomService.xml";
		DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
		Document doc = docBuilder.parse(filepath);

		Element dataTag = doc.getDocumentElement();
		Element orderListTag = (Element) dataTag.getElementsByTagName("OrderList").item(0);
		Element order = doc.createElement("order");
		Element roomNo = doc.createElement("roomNo");
		Element orderItem = doc.createElement("item");
		Element orderPrice = doc.createElement("totalPrice");
		Element orderStatus = doc.createElement("status");
		Element orderTime = doc.createElement("orderTime");
		Element orderRemarks = doc.createElement("remarks");
		
		for (int i = 0; i < arOrders.size(); i++) {
			if (i % 2 == 0) {
				foodItem = foodItem.concat(arOrders.get(i));
				foodItem = foodItem.concat(",");
			}
		}
		for (int i = 0; i < arOrders.size(); i++) {
			if (i % 2 == 1) {
				foodTotalPrice += Double.parseDouble(arOrders.get(i));
			}
		}

		roomNo.setTextContent(rmNumber);
		orderItem.setTextContent(foodItem);
		orderPrice.setTextContent(String.valueOf(foodTotalPrice));
		orderStatus.setTextContent("Confirmed");
		orderRemarks.setTextContent(guestRemarks);
		orderTime.setTextContent(sdf.format(cal.getTime()));

		order.appendChild(roomNo);
		order.appendChild(orderItem);
		order.appendChild(orderPrice);
		order.appendChild(orderStatus);
		order.appendChild(orderTime);
		order.appendChild(orderRemarks);
		
		orderListTag.appendChild(order);

		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		DOMSource source = new DOMSource(doc);

		StreamResult result = new StreamResult(new File(filepath));
		transformer.setOutputProperty(OutputKeys.INDENT, "yes");
		transformer.transform(source, result);
		
	} catch (Exception e) {
		e.printStackTrace();
	}

}

/**
method to extract all the guest and their details in the system
@return Guest returns the list of guest objects
*/ 
public ArrayList<Guest> initializeGuest(){
	
	
    try{
		File fXmlFile = new File("guestList.xml");
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
		Document doc = dBuilder.parse(fXmlFile);
		doc.getDocumentElement().normalize();
		NodeList nList = doc.getElementsByTagName("Guest");
		
		//loop through file to obtain attributes
		for (int temp = 0; temp < nList.getLength(); temp++) {
				Node nNode = nList.item(temp);
			
			if (nNode.getNodeType() == Node.ELEMENT_NODE) {
				Element eElement = (Element) nNode;		
				String name = eElement.getElementsByTagName("name").item(0).getTextContent();
				String address = eElement.getElementsByTagName("address").item(0).getTextContent();
				String country = eElement.getElementsByTagName("country").item(0).getTextContent();
				String gender = eElement.getElementsByTagName("gender").item(0).getTextContent();
				String nationality = eElement.getElementsByTagName("nationality").item(0).getTextContent();
				String contact = eElement.getElementsByTagName("contact").item(0).getTextContent();
				String creditCardNo = eElement.getElementsByTagName("creditCardNo").item(0).getTextContent();
				String creditCardCSV = eElement.getElementsByTagName("creditCardCSV").item(0).getTextContent();
				String creditCardExpDate = eElement.getElementsByTagName("creditCardExpDate").item(0).getTextContent();
				String identity = eElement.getElementsByTagName("identity").item(0).getTextContent();
				Guest tempGuest = new Guest(name,address,country, nationality,identity,gender,contact,creditCardNo,creditCardCSV,creditCardExpDate);	
				guests.add(temp,tempGuest);
			}
		}		
		
		//end of initializing guest from guestList.xml
	
}
    catch(Exception e){
    	e.printStackTrace();
    }
	return guests;
}
/**
method to extract all rooms from roomList.xml
@return room list of room in the system
*/ 
public ArrayList<Room> initializeRooms(){
	
    try{
		//start initializing of room from room.xml
		File rXmlFile = new File("roomList.xml");
		DocumentBuilderFactory dbFactory1 = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder1 = dbFactory1.newDocumentBuilder();
		Document doc1 = dBuilder1.parse(rXmlFile);
		doc1.getDocumentElement().normalize();
		NodeList rList = doc1.getElementsByTagName("room");
		//loop through file to obtain attributes
		
		for (int temp = 0; temp < rList.getLength(); temp++) {
				Node nNode = rList.item(temp);
			
			if (nNode.getNodeType() == Node.ELEMENT_NODE) {
				Element eElement = (Element) nNode;		
				String roomNo = eElement.getElementsByTagName("roomNo").item(0).getTextContent();
				String roomType = eElement.getElementsByTagName("roomType").item(0).getTextContent();
				String bedType = eElement.getElementsByTagName("bedType").item(0).getTextContent();
				String smoking = eElement.getElementsByTagName("smoking").item(0).getTextContent();
				String startDate = eElement.getElementsByTagName("startDate").item(0).getTextContent();
				String endDate = eElement.getElementsByTagName("endDate").item(0).getTextContent();
				String wifi = eElement.getElementsByTagName("wifi").item(0).getTextContent();
				String roomView = eElement.getElementsByTagName("roomView").item(0).getTextContent();
				String available = eElement.getElementsByTagName("availability").item(0).getTextContent();
				String checkInStatus = eElement.getElementsByTagName("checkInStatus").item(0).getTextContent();
				Room tempRoom = new Room(roomType,bedType,roomNo,smoking,startDate,endDate,wifi,roomView,available,checkInStatus);
				room.add(temp,tempRoom);
			}
		}		
		
		//end of initializing guest from guestList.xml

}
    catch(Exception e){
    	e.printStackTrace();
    }
	return room;
}

/**
method to extract all reservation and it's details from reservations.xml
@return rd list of reservations that exist in the system
*/ 
public ArrayList<Reservation> initializeReservations(){
	
	
try{
		File resXmlFile = new File("reservations.xml");
		DocumentBuilderFactory dbFactory2 = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder2 = dbFactory2.newDocumentBuilder();
		Document doc2 = dBuilder2.parse(resXmlFile);
		doc2.getDocumentElement().normalize();
		NodeList resList = doc2.getElementsByTagName("reservation");
		//loop through file to obtain attributes
		
		for (int temp = 0; temp < resList.getLength(); temp++) {
				Node nNode = resList.item(temp);
			
			if (nNode.getNodeType() == Node.ELEMENT_NODE) {
				Element eElement = (Element) nNode;		
				String resID = eElement.getElementsByTagName("resID").item(0).getTextContent();
				String roomNo = eElement.getElementsByTagName("roomNo").item(0).getTextContent();
				String roomType = eElement.getElementsByTagName("roomType").item(0).getTextContent();
				String noOfGuest = eElement.getElementsByTagName("noOfGuest").item(0).getTextContent();
				String bedType = eElement.getElementsByTagName("bedType").item(0).getTextContent();
				String smoking = eElement.getElementsByTagName("smoking").item(0).getTextContent();
				String startDate = eElement.getElementsByTagName("startDate").item(0).getTextContent();
				String endDate = eElement.getElementsByTagName("endDate").item(0).getTextContent();
				String wifi = eElement.getElementsByTagName("wifi").item(0).getTextContent();
				String roomView = eElement.getElementsByTagName("roomView").item(0).getTextContent();
				String availability= eElement.getElementsByTagName("availability").item(0).getTextContent();
				String resCheckInStatus = eElement.getElementsByTagName("checkInStatus").item(0).getTextContent();
				String name = eElement.getElementsByTagName("name").item(0).getTextContent();
				String address = eElement.getElementsByTagName("address").item(0).getTextContent();
				String country = eElement.getElementsByTagName("country").item(0).getTextContent();
				String gender = eElement.getElementsByTagName("gender").item(0).getTextContent();
				String nationality = eElement.getElementsByTagName("nationality").item(0).getTextContent();
				String contact = eElement.getElementsByTagName("contact").item(0).getTextContent();
				String creditCardNo = eElement.getElementsByTagName("creditCardNo").item(0).getTextContent();
				String creditCardCSV = eElement.getElementsByTagName("creditCardCSV").item(0).getTextContent();
				String creditCardExpDate = eElement.getElementsByTagName("creditCardExpDate").item(0).getTextContent();
				String identity = eElement.getElementsByTagName("identity").item(0).getTextContent();
				String resStatus = eElement.getElementsByTagName("resStatus").item(0).getTextContent();
				String resCheckInDate = eElement.getElementsByTagName("checkInDate").item(0).getTextContent();
				String resCheckInTime = eElement.getElementsByTagName("checkInTime").item(0).getTextContent();
				Reservation tempRes = new Reservation (resID,roomNo,roomType,bedType,smoking,startDate,endDate,wifi,
						roomView,availability,resCheckInStatus,name,address,contact,country,gender,nationality,identity,creditCardNo
						,creditCardCSV,creditCardExpDate,noOfGuest,resStatus,resCheckInDate,resCheckInTime);
				rd.add(temp,tempRes);
			}
				
		
		}
		
}


    catch(Exception e){
    	e.printStackTrace();
    }
return rd;
}

/**
method to extract all walk-in details from walkIn.xml
@return wi list of walk-ins and it's details in the system
*/ 
public ArrayList<WalkIns> initializeWalkIns(){
	
	
try{
		File resXmlFile = new File("walkIn.xml");
		DocumentBuilderFactory dbFactory2 = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder2 = dbFactory2.newDocumentBuilder();
		Document doc2 = dBuilder2.parse(resXmlFile);
		doc2.getDocumentElement().normalize();
		NodeList resList = doc2.getElementsByTagName("walkIn");
		//loop through file to obtain attributes
		
		for (int temp = 0; temp < resList.getLength(); temp++) {
				Node nNode = resList.item(temp);
			
			if (nNode.getNodeType() == Node.ELEMENT_NODE) {
				Element eElement = (Element) nNode;		
				
				String roomNo = eElement.getElementsByTagName("roomNo").item(0).getTextContent();
				String roomType = eElement.getElementsByTagName("roomType").item(0).getTextContent();
				String noOfGuest = eElement.getElementsByTagName("noOfGuest").item(0).getTextContent();
				String bedType = eElement.getElementsByTagName("bedType").item(0).getTextContent();
				String smoking = eElement.getElementsByTagName("smoking").item(0).getTextContent();
				String startDate = eElement.getElementsByTagName("startDate").item(0).getTextContent();
				String endDate = eElement.getElementsByTagName("endDate").item(0).getTextContent();
				String wifi = eElement.getElementsByTagName("wifi").item(0).getTextContent();
				String roomView = eElement.getElementsByTagName("roomView").item(0).getTextContent();
				String availability= eElement.getElementsByTagName("availability").item(0).getTextContent();
				String checkInStatus = eElement.getElementsByTagName("checkInStatus").item(0).getTextContent();
				String name = eElement.getElementsByTagName("name").item(0).getTextContent();
				String address = eElement.getElementsByTagName("address").item(0).getTextContent();
				String country = eElement.getElementsByTagName("country").item(0).getTextContent();
				String gender = eElement.getElementsByTagName("gender").item(0).getTextContent();
				String nationality = eElement.getElementsByTagName("nationality").item(0).getTextContent();
				String contact = eElement.getElementsByTagName("contact").item(0).getTextContent();
				String creditCardNo = eElement.getElementsByTagName("creditCardNo").item(0).getTextContent();
				String creditCardCSV = eElement.getElementsByTagName("creditCardCSV").item(0).getTextContent();
				String creditCardExpDate = eElement.getElementsByTagName("creditCardExpDate").item(0).getTextContent();
				String identity = eElement.getElementsByTagName("identity").item(0).getTextContent();
				
				WalkIns tempWalkIn = new WalkIns (roomNo,roomType,bedType,smoking,startDate,endDate,wifi,
						roomView,availability,checkInStatus,name,address,contact,country,gender,nationality,identity,creditCardNo
						,creditCardCSV,creditCardExpDate,noOfGuest);
				wi.add(temp,tempWalkIn);
			}
				
		
		}
		
}


    catch(Exception e){
    	e.printStackTrace();
    }
return wi;
}


/**
method to extract all room service and it's details from roomServiceMenu.xml
@return rs list of room service and it's details in the system
*/ 
public ArrayList<RoomService> initializeRoomServiceMenu() { // 1st run RoomServiceMenu
	int foodIndexCounter = 1, categoryCounter = 1;
	int arrMenuCounter = 0;
	String categoryMenu = "";

	while(categoryCounter < 6){
		
		if (categoryCounter == 1) {
			categoryMenu = "Alcoholic";
		} else if (categoryCounter == 2) {
			categoryMenu = "Snack";
		} else if (categoryCounter == 3) {
			categoryMenu = "Beverage";
		} else if (categoryCounter == 4) {
			categoryMenu = "Main Course";
		} else if (categoryCounter == 5) {
			categoryMenu = "Dessert";
		}
			
		try {
			File fXmlFile = new File("roomServiceMenu.xml");
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(fXmlFile);
			doc.getDocumentElement().normalize();
			NodeList nList = doc.getElementsByTagName("item");

			// loop through file to obtain attributes
			for (int temp = 0; temp < nList.getLength(); temp++) {
				Node nNode = nList.item(temp);

				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode;
					if (eElement.getElementsByTagName("category").item(0).getTextContent().equals(categoryMenu)) {
						String foodName = eElement.getElementsByTagName("name").item(0).getTextContent();
						String foodPrice = eElement.getElementsByTagName("price").item(0).getTextContent();
						String foodDescription = eElement.getElementsByTagName("description").item(0).getTextContent();
						String foodCategory = eElement.getElementsByTagName("category").item(0).getTextContent();
						RoomService tempRoomMenu = new RoomService(foodName, foodPrice, foodDescription,
								foodCategory, foodIndexCounter);
						rs.add(arrMenuCounter, tempRoomMenu);
						arrMenuCounter++;
						foodIndexCounter++;
					}
				}
			} // end xml for loop

		} catch (Exception e) {
			e.printStackTrace();
		}
		
		categoryCounter++;
	}//end while 
	
	return rs;
	
}// end displaySnackMenu

/**
 * When check out it will write back to the file 
 * @param roomNum The room number that is to be checkout 
 */
public void checkOutWriteToFile( String roomNum){
	

	try{
	int position =0;
	
	DocumentBuilderFactory docFactory2 = DocumentBuilderFactory.newInstance();
	DocumentBuilder docBuilder2 = docFactory2.newDocumentBuilder();
	Document doc2 = docBuilder2.parse("roomList.xml");
	TransformerFactory transformerFactory2 = TransformerFactory.newInstance();
	Transformer transformer2 = transformerFactory2.newTransformer();
	DOMSource source2 = new DOMSource(doc2);
	StreamResult result2 = new StreamResult(new File("roomList.xml"));

	NodeList list2 = doc2.getElementsByTagName("room");

	for (int i = 0; i < list2.getLength(); i++) 
	{
		Element item = (Element) list2.item(i);
		Node n= list2.item(i);
		if(item.getElementsByTagName("roomNo").item(0).getTextContent().equals(roomNum))
		{

				position =i;
		}

	}
	Node nodes2 = doc2.getElementsByTagName("room").item(position);
	NodeList list = nodes2.getChildNodes();
	
	for (int i = 0; i != list.getLength(); ++i) {
		Node child = list.item(i);

		if (child.getNodeName().equals("checkInStatus")) {
			child.getFirstChild().setNodeValue("N");
		}
		if (child.getNodeName().equals("availability")) {
			child.getFirstChild().setNodeValue("Vacant");
		}
	
	}

	transformer2.transform(source2, result2);

}
	catch(Exception e){
		e.printStackTrace();
	}
}

/**
 * Remove all the room service order that is related to this reservation/walk in 
 * when the customer check out
 * @param rmNo room number to find the order that have this room number
 */
public void removeRoomServiceItemXML(String rmNo) {


	// link with XML
	try {
		DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
		Document doc = docBuilder.parse("orderRoomService.xml");
		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		DOMSource source = new DOMSource(doc);
		StreamResult result = new StreamResult(new File("orderRoomService.xml"));

		NodeList list = doc.getElementsByTagName("order");

		for (int i = 0; i < list.getLength(); i++) 
		{
			Element item = (Element) list.item(i);
			Element room = (Element) item.getElementsByTagName("roomNo").item(0);
			String proom = room.getTextContent();
			if (proom.equals(rmNo)) {
				item.getParentNode().removeChild(item);
				i--;
			}
		}

		transformer.transform(source, result);

	} catch (Exception e) {
		e.printStackTrace();
	}

}
/**
 * Initialised the arraylist for order
 * @return The order arraylist
 */
public ArrayList<Order> initializeOrder(){
	
	
    try{
		File fXmlFile = new File("orderRoomService.xml");
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
		Document doc = dBuilder.parse(fXmlFile);
		doc.getDocumentElement().normalize();
		NodeList nList = doc.getElementsByTagName("order");
		
		//loop through file to obtain attributes
		for (int temp = 0; temp < nList.getLength(); temp++) {
				Node nNode = nList.item(temp);
			
			if (nNode.getNodeType() == Node.ELEMENT_NODE) {
				Element eElement = (Element) nNode;		
				String rn = eElement.getElementsByTagName("roomNo").item(0).getTextContent();
				String i = eElement.getElementsByTagName("item").item(0).getTextContent();
				String tp = eElement.getElementsByTagName("totalPrice").item(0).getTextContent();
				String s = eElement.getElementsByTagName("status").item(0).getTextContent();
				String ot = eElement.getElementsByTagName("orderTime").item(0).getTextContent();
				String r = eElement.getElementsByTagName("remarks").item(0).getTextContent();
				Order tempo = new Order(rn,i,tp,s,ot,r);
				order.add(temp,tempo);
			}
		}		
		
		//end of initializing guest from guestList.xml
	
}
    catch(Exception e){
    	e.printStackTrace();
    }
	return order;
}
}
