
import java.util.*;
import javax.xml.parsers.*;
import org.w3c.dom.*;
import org.xml.sax.SAXException;

import java.io.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

/**
Represent a reservation menu in the system
Mainly control the logic of how reservation is being handled
@author FSP4
@version 1.0
@since 2016-04-06
*/ 

public class ReservationMenu {
	/**
	* scanner object to obtain user input
	*/
	Scanner sc = new Scanner(System.in);
	
	/**
	* Instance of reservation menu class
	*/
	public ReservationMenu(){ //constructor
			}
	
	/**
	* method to set check in time
	* @return resID reservation ID of current reservation
	*/
	public String generateResID(){
		
			   int reservationId = (int)(Math.random()*100+1);
				String resId = Integer.toString(reservationId);
				
				return resId;
		}
	
	/**
	* method to search for room object in system
	* @param room Collection of room objects in the system
	* @return room returns an instance room object
	*/
	public Room searchForRoom(ArrayList<Room> room){
		System.out.println("Enter room No. :");
		
		String roomNo = sc.next();
		int flag = validateRoomNumber(roomNo,room);
		while (flag != 1) {
			System.out.println("Room Number does not exist in system ! ");
			System.out.println("Please re-enter your a valid room number again!");
			roomNo = sc.next();
			flag = validateRoomNumber(roomNo,room);	
		}
		
		int count =0;
	    for(int i=0;i<room.size();i++){
	    	if(room.get(i).getRoomNo().equals(roomNo)){
	    		count =i;
	    	}
	    }
	    if(!room.get(count).getRoomNo().equals(roomNo)){
	    	return null;
	    }
		return room.get(count);
		
	}
	

	
	/**
	* method to search for guests in system
	* @param guest Collection of guests in the system
	* @return guest returns an instance room object
	*/
	public Guest searchForGuest(ArrayList<Guest> guest){
		System.out.println("Enter Guest identification: ");
		String guestId = sc.next();
		
		int flag = validateGuestID(guestId,guest);
		while (flag != 1) {
			System.out.println("Guest Identity does not exist in system ! ");
			System.out.println("Please re-enter your ID(Passport or driver license) :");
			guestId = sc.next();
			flag = validateGuestID(guestId,guest);	
		}
		int count =0;
	    for(int i=0;i<guest.size();i++){
	    	if(guest.get(i).getIdentity().equals(guestId)){
	    		count =i;
	    	}
	    }
		return guest.get(count);
	}
	
	/**
	* method to search for guest object in system
	* @param reservation Collection of reservation details in system
	* @return count position of reservation that contains the guest
	*/
	public int searchForGuestRes(ArrayList<Reservation> reservation){
		System.out.println("Enter Guest identification: ");
		String guestId = sc.next();
		int flag = validateGuestIDInRes(guestId,reservation);
		while (flag != 1) {
			System.out.println("Guest Identity does not exist in system ! ");
			System.out.println("Please re-enter your ID(Passport or driver license) :");
			guestId = sc.next();
			flag = validateGuestIDInRes(guestId,reservation);	
		}
		
		
		int count =0;
	    for(int i=0;i<reservation.size();i++){
	    	if(reservation.get(i).getGuestIdentity().equals(guestId)){
	    		count =i;
	    	}
	    }
		return count;
	}
	
	
	/**
	* method to search for guest object in system
	* @param reservation Collection of reservation details in system
	* @return count position of reservation that contains the guest
	*/
	public int searchForRoonRes(ArrayList<Reservation> reservation){
		System.out.println("Enter room No. : ");
		String roomNo = sc.next();
		int flag = validateRoomNoInRes(roomNo,reservation);
		while (flag != 1) {
			System.out.println("Room Number does not exist in system ! ");
			System.out.println("Please re-enter a valid room number!");
			roomNo = sc.next();
			flag = validateRoomNoInRes(roomNo,reservation);	
		}
		
		int count =0;
	    for(int i=0;i<reservation.size();i++){
	    	if(reservation.get(i).getResRoomNo().equals(roomNo)){
	    		count =i;
	    	}
	    }
		return count;
	}
	
	/**
	* method to search for guest object in system
	* @param reservation Collection of reservation details in system
	* @return count position of reservation that contains the guest
	*/
	public int searchForResNo(ArrayList<Reservation> reservation){
		System.out.println("Enter Reservation ID : ");
		String resNo = sc.next();
		int flag = validateResID(resNo,reservation);
		while (flag != 1) {
			System.out.println("Rservation ID does not exist in system! ");
			System.out.println("Please re-enter a valid reservation ID!");
			resNo = sc.next();
			flag = validateResID(resNo,reservation);	
		}
		int count =0;
	    for(int i=0;i<reservation.size();i++){
	    	if(reservation.get(i).getResID().equals(resNo)){
	    		count =i;
	    	}
	    }
		return count;
	}
	
	/**
	* method to search for if an reservation has been made for a room
	* @param reservation Collection of Reservation object that exist in the system
	* @return count position of reservation that contains the room
	*/
	public int searchForResRoomPrint(ArrayList<Reservation> reservation){
		System.out.println("Enter room No. ");
		String roomNo = sc.next();
		int flag = validateRoomNoInRes(roomNo,reservation);
		while (flag != 1) {
			System.out.println("Room Number does not exist in system ! ");
			System.out.println("Please re-enter a valid room number!");
			roomNo = sc.next();
			flag = validateRoomNoInRes(roomNo,reservation);	
		}
		int count =0;
	    for(int i=0;i<reservation.size();i++){
	    	if(reservation.get(i).getResRoomNo().equals(roomNo)){
	    		count =i;
	    	}
	    }
		return count;
	}
	
	/**
	* method to search for if an guest has been made for a reservation
	* @param reservation Collection of Reservation object that exist in the system
	* @return count position of reservation that contains the guest
	*/
	public int searchForResGuestPrint(ArrayList<Reservation> reservation){
		System.out.println("Enter guest name :");
		String guestName = sc.next();
		int flag = validateGuestNameInRes(guestName,reservation);
		while (flag != 1) {
			System.out.println("Guest name does not exist in system ! ");
			System.out.println("Please re-enter your name!) :");
			guestName = sc.next();
			flag = validateGuestNameInRes(guestName,reservation);	
		}
		
		int count =0;
	    for(int i=0;i<reservation.size();i++){
	    	if(reservation.get(i).getGuestName().equals(guestName )){
	    		count =i;
	    	}
	    }
		return count;
	}
	
	/**
	* method to search for reservation in system
	* @param reservation Collection of Reservation object that exist in the system
	* @return count position of reservation in the reservation list
	*/
	public int searchForResIDPrint(ArrayList<Reservation> reservation){
		System.out.println("Enter Reservation ID :");
		String resId = sc.next();
		int flag = validateResID(resId,reservation);
		while (flag != 1) {
			System.out.println("Rservation ID does not exist in system! ");
			System.out.println("Please re-enter a valid reservation ID!");
			resId = sc.next();
			flag = validateResID(resId,reservation);	
		}
		int count =0;
	    for(int i=0;i<reservation.size();i++){
	    	if(reservation.get(i).getResID().equals(resId)){
	    		count =i;
	    	}
	    }
		return count;
	}
	
	
	
	
	
	/**
	* method to remove a reservation from the system
	* @param position position of reservation to be removed
	*/
	
	public void removeReservation(int position){
		
		try{
		
			File file = new File("reservations.xml");
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			Document doc = builder.parse(file);
			Element element = (Element)doc.getElementsByTagName("reservation").item(position);
			if ( null != element) {

			element.getParentNode().removeChild(element);
			
		  	TransformerFactory transformerFactory = TransformerFactory.newInstance();
		  	Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);
				
			StreamResult result = new StreamResult(new File("reservations.xml"));
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			transformer.transform(source, result);
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	/**
	* method to print the details of an reservation
	* @param reservation Collection of Reservation object that exist in the system
	* @param position specify of reservation to be printed
	*/
	public void printResToConsole(ArrayList<Reservation> reservation,int position){
		System.out.println("Reservation ID : " + reservation.get(position).getResID());
		System.out.println("Room No : " + reservation.get(position).getResRoomNo());
		System.out.println("Room Type : " + reservation.get(position).getResRoomType());
		System.out.println("No. of Guest : " + reservation.get(position).getNoOfGuest());
		System.out.println("Bed Type : " + reservation.get(position).getResBedType());
		System.out.println("Smoking : " + reservation.get(position).getResSmoking());
		System.out.println("Start Date : " + reservation.get(position).getNoOfGuest());
		System.out.println("End Date : " + reservation.get(position).getResBedType());
		System.out.println("Wifi : " + reservation.get(position).getResBedType());
		System.out.println("Room View : " + reservation.get(position).getResBedType());
		System.out.println("Availability : " + reservation.get(position).getResAvailability());
		System.out.println("Check-in Status : " + reservation.get(position).getCheckInStatus());
		System.out.println("Name " + reservation.get(position).getGuestName());
		System.out.println("Address: " + reservation.get(position).getGuestAddress());
		System.out.println("Country: " + reservation.get(position).getCountry());
		System.out.println("Gender: " + reservation.get(position).getGuestGender());
		System.out.println("Nationality : " + reservation.get(position).getGuestNationality());
		System.out.println("Contact : " + reservation.get(position).getGuestContacts());
		System.out.println("Credit Card No : " + reservation.get(position).getCreditCardNo());
		System.out.println("Credit Card CSV : " + reservation.get(position).getCreditCardCSV());
		System.out.println("Credit Card Exp Date : " + reservation.get(position).getCreditCardExpDate());
		System.out.println("Identity : " + reservation.get(position).getGuestIdentity());
		System.out.println("Reservation Status : " + reservation.get(position).getResStatus());
		System.out.println("Check In Date and Time : " + reservation.get(position).getCheckInDate() + " " + reservation.get(position).getCheckInTime());
	}

	/**
	* method to update the details of a reservation
	* @param reservation collection of Reservation objects in the system
	* @param room collection of of room objects in the system
	* @param guest collection of guest objects i the system
	*/
	public void updateResList(ArrayList<Reservation> reservation, ArrayList<Room> room, ArrayList<Guest> guest) {
		try {
			
			System.out.println("Enter reservation ID:");
			String resID = sc.next();
		
			int flag = validateResID(resID,reservation);
			while (flag != 1) {

				System.out.println("Reservation ID is not valid! Please try again!");
				resID = sc.next();
				flag = validateGuestID(resID,guest);	
			}
			//Get index of current reservation to be modified
			int count= 0 ;
			for(int i=0;i<reservation.size();i++){
	    	if(reservation.get(i).getResID().equals(resID)){
	    		count =i;
	    	}
	    	
	    }
			
			//open reservation file
			String filepath = "reservations.xml";
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(filepath);
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(new File(filepath));
			Node nodes = doc.getElementsByTagName("reservation").item(count);
			NodeList list = nodes.getChildNodes();

			//open RoomList file
			String filepath2 = "roomList.xml";
			DocumentBuilderFactory docFactory2 = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder2 = docFactory2.newDocumentBuilder();
			Document doc2 = docBuilder2.parse(filepath2);
			TransformerFactory transformerFactory2 = TransformerFactory.newInstance();
			Transformer transformer2 = transformerFactory2.newTransformer();
			DOMSource source2 = new DOMSource(doc2);
			StreamResult result2 = new StreamResult(new File(filepath2));
		
			
			System.out.println("1.) Update room\n2.) Update Reservation Status\n3.)"
					+ " Update date of reservation\n4.) Update No. of guest \n5.) Previous menu");

			int userInput = sc.nextInt();
			sc.nextLine();

			switch (userInput) {
			case 1:// allow User to update room
		
				//Get index of new room from room Object
				System.out.println("Enter new Room number:");
				String newRoomNumber = sc.next();
				int count2 = 0 ;
				
				for(int i=0;i<room.size();i++){
		    	if(room.get(i).getRoomNo().equals(newRoomNumber)){
		    		count2 =i;
		    	}
		    	
		    }
			
				Node nodes2 = doc2.getElementsByTagName("room").item(count2);
				NodeList list2 = nodes2.getChildNodes();
				
				//Extract out attributes of new room and store inside temporary variables
				String newRoomNo = room.get(count2).getRoomNo();
				String newRoomType = room.get(count2).getRoomType();
				String newBedType = room.get(count2).getBedType();
				String smoking = room.get(count2).isSmoking();
				String newRoomWifi = room.get(count2).isWifi();
				String newRoomView = room.get(count2).isRoomView();
				
				
				
				//change status of old room to vacant and start date/end date to 000000
				String oldRoomNo = reservation.get(count).getResRoomNo();
				int count3 = 0;
				for(int i=0;i<room.size();i++){
			    	if(room.get(i).getRoomNo().equals(oldRoomNo)){
			    		count3 =i;
			    	}
			    	
			    }

				/////////////////////////////////////////////////////////////////////
				
				for (int i = 0; i != list.getLength(); ++i) {
					Node child = list.item(i);

					if (child.getNodeName().equals("roomNo")) {

						child.getFirstChild().setNodeValue(newRoomNo);

					}

					if (child.getNodeName().equals("roomType")) {

						child.getFirstChild().setNodeValue(newRoomType);

					}
					
					if (child.getNodeName().equals("bedType")) {

						child.getFirstChild().setNodeValue(newBedType);

					}
					if (child.getNodeName().equals("smoking")) {

						child.getFirstChild().setNodeValue(smoking);

					}
					if (child.getNodeName().equals("wifi")) {

						child.getFirstChild().setNodeValue(smoking);

					}
					if (child.getNodeName().equals("roomView")) {

						child.getFirstChild().setNodeValue(newRoomView);

					}
					if (child.getNodeName().equals("availability")) {

						child.getFirstChild().setNodeValue("Reserved");

					}
				}
				
			
				transformer.transform(source, result); // write to file
				//Modify reservation object in ArrayList
				reservation.get(count).setRoomNo(newRoomNo); 
				reservation.get(count).setRoomType(newRoomType);
				reservation.get(count).setbedType(newBedType);
				reservation.get(count).setSmoking(smoking);
				reservation.get(count).setResRoomView(newRoomView);
				reservation.get(count).setResWifi(newRoomWifi);
				reservation.get(count).setResAvailability("Reserved");
				

				//write to roomList file/frees up room
				System.out.println(list2.getLength());
				for (int i = 0; i != list2.getLength(); ++i) {
					Node child = list2.item(i);

					if (child.getNodeName().equals("availability")) {

						child.getFirstChild().setNodeValue("Vacant");

					}
					if (child.getNodeName().equals("startDate")) {

						child.getFirstChild().setNodeValue("000000");

					}
					if (child.getNodeName().equals("endDate")) {

						child.getFirstChild().setNodeValue("000000");

					}
				}
				
				transformer2.transform(source2, result2);
				room.get(count3).setAvailibility("Vacant");
				room.get(count3).setStartDate("000000");
				room.get(count3).setEndDate("000000");
				
				break;
				
			case 2:

				System.out.println("Enter new reservation status:\n1.) confirmed\n2.) In waitlist\n3.) Expired");
			    userInput = sc.nextInt();
			    String resStatus ="";
				switch(userInput){
				
				case 1: resStatus= "Confirmed" ;break;
				case 2: resStatus= "In waitlist" ;break;
				case 3: resStatus= "Expired" ;break;
				}
			    
				//Get index of current reservation to be modified
				count= 0 ;
				for(int i=0;i<reservation.size();i++){
		    	if(reservation.get(i).getResID().equals(resID)){
		    		count =i;
		    	}
				}
		    	
		    	
				for (int i = 0; i != list.getLength(); ++i) {
					Node child = list.item(i);

					if (child.getNodeName().equals("resStatus")) {

						child.getFirstChild().setNodeValue(resStatus);
					}
				}
				transformer.transform(source, result);
				reservation.get(count).setResStatus(resStatus);
				
				break;
				
			case 3:
				
				//Get new dates 
				System.out.println("Enter new start date of stay:");
				String newStartDate = sc.next();
				System.out.println("Enter new end date of stay:");
				String newEndDate = sc.next();
				count= 0 ;
				for(int i=0;i<reservation.size();i++){
		    	if(reservation.get(i).getResID().equals(resID)){
		    		count =i;
		    	}
				}

		for (int i = 0; i != list.getLength(); ++i) {
					Node child = list.item(i);
					if (child.getNodeName().equals("startDate")) {
						child.getFirstChild().setNodeValue(newStartDate);
						
					}
					if (child.getNodeName().equals("endDate")) {
						child.getFirstChild().setNodeValue(newEndDate);
						
					}

				}
		count2=0;
			for(int i=0;i<room.size();i++){
				if(room.get(i).getRoomNo().equals(reservation.get(count).getResRoomNo())){
	    		count2 =i;
	    	}
			}
			nodes2 = doc2.getElementsByTagName("room").item(count2);
			list2 = nodes2.getChildNodes();
		
			for (int i = 0; i != list2.getLength(); ++i) {
				Node child = list2.item(i);
				if (child.getNodeName().equals("startDate")) {
					child.getFirstChild().setNodeValue(newStartDate);
					
				}
				if (child.getNodeName().equals("endDate")) {
					child.getFirstChild().setNodeValue(newEndDate);
					
				}

			}
				//Write to reservation file and modify object in Arraylist
				reservation.get(count).setRoomStartDate(newStartDate);
				reservation.get(count).setRoomStartDate(newEndDate);
				room.get(count2).setStartDate(newStartDate);
				room.get(count2).setEndDate(newEndDate);
				transformer.transform(source, result);
				transformer2.transform(source2, result2);
				
				break;
				
			case 4://updating the number of guest
				System.out.println("Enter New number of Guest:");
				String newNoOfGuest = sc.next();
				//Get index of current reservation to be modified
				count= 0 ;
				for(int i=0;i<reservation.size();i++){
		    	if(reservation.get(i).getResID().equals(resID)){
		    		count =i;
		    	}
				}

				for (int i = 0; i != list.getLength(); ++i) {
					Node child = list.item(i);
					if (child.getNodeName().equals("noOfGuest")) {
						child.getFirstChild().setNodeValue(newNoOfGuest);
					}

				}
				
				transformer.transform(source, result);
				reservation.get(count).setNoOfGuest(newNoOfGuest);
				break;
			
			case 5:break;
			}
			
		}

		catch (Exception e) {
			e.printStackTrace();
		}

	
	}
	
	/**
	* method to create a new reservation
	* @param guests Collection of guest that exist in the system
	* @param room Collection of room that exist in the system
	* @param reservation Collection of Reservation object that exist in the system
	*/
	public void CreateReservation(ArrayList<Guest> guests, ArrayList<Room> room,ArrayList<Reservation> reservation){
		
		GuestMenu gm = new GuestMenu();
		RoomMenu rmenu = new RoomMenu();	 
		InputOutput inOut = new InputOutput();
		boolean proceed = false;
		Guest currGuest = null;
		Room currRoom = null;
		int noOfVacant = 0;
		String resId = null,startDate = "",endDate="",noOfGuest,checkInDate,checkInTime = "",resStatus = "confirmed" ;
		
		for(int i = 0; i <reservation.size();i++){
			if(reservation.get(i).getAvailability().equals("Vacant")){
				noOfVacant++;
			}
		}
		if((reservation.size()==48)){
			if(noOfVacant==0)
				resStatus = "In waitlist";
		}

		
		while(!proceed){
			System.out.println("1.) Exisiting Guest\n2.) New Guest\n3.) Previous Menu");
			int guestExist = sc.nextInt();
			if(guestExist == 3)return;
		switch(guestExist){
	
		case 1:
	
		 currGuest = searchForGuest(guests);
	     break;
	     
		case 2:
			
			Guest tmpGuest = gm.createGuestDetails(guests);
			guests.add(tmpGuest);//create guest and store into ararylist of guests object
			currGuest = tmpGuest;
			inOut.writeToGuestFile(tmpGuest);//update guestList file
			break;
		
		case 3: break;
		}
		
		System.out.println("1.) Exisiting Room\n2.) New Room\n3.) Previous Menu");
		int userInput = sc.nextInt();
		if(userInput==3)return;
		switch(userInput){
		
		case 1:
	
			currRoom = searchForRoom(room);
			
		while(!currRoom.getAvailability().equals("Vacant")){
			currRoom = searchForRoom(room);	
		}	
		 resId = currRoom.getRoomNo() + generateResID();break;
		 
		case 2:Room tmpRoom = rmenu.createRoomDetails(room); 
		currRoom = tmpRoom;
		room.add(currRoom);//create room and store into ararylist of room
		inOut.writeToRoomFile(currRoom);//update room file
	    resId = tmpRoom.getRoomNo() + generateResID();
			 break;
		case 3:break;
		}
		if((currRoom!= null && currGuest!=null)){
			proceed = true;
		}
		else {System.out.println("Guset and Room must exist!");}
		}
		
		
		boolean uProceedStartDate = false;
	    boolean uProceedEndDate = false;
		String ucopySD = "";
		
	  	while(uProceedStartDate != true){
            System.out.println("Enter the start date of stay(MM/DD/YY): ");
            startDate = sc.next();

            if(startDate.length() == 8)
            {
            	String[] arraySDu = startDate.split("", 8);
            	
            	String umm = arraySDu[0] + arraySDu[1];
            	int ummInt = Integer.parseInt(umm);
				
				String udd = arraySDu[3] + arraySDu[4];
            	int uddInt = Integer.parseInt(udd);
            	
            	String uyy = arraySDu[6] + arraySDu[7];
            	int uyyInt = Integer.parseInt(uyy);
            	int uleapYear = uyyInt%4;
            	
            	//making sure there is a valid start date entered given the right mm/dd/yy
            	if(((uddInt >= 1 && uddInt <= 31) && (ummInt == 1 || ummInt == 3 || ummInt == 5 || ummInt == 7 || ummInt == 8 || ummInt == 10 || ummInt == 12) && (uyyInt > 0) && (arraySDu[2].equals("/")) && (arraySDu[5].equals("/")))
            			|| ((uddInt >= 1 && uddInt <= 30) && (ummInt == 4 || ummInt == 6 || ummInt == 9 || ummInt == 11) && (uyyInt > 0) && (arraySDu[2].equals("/")) && (arraySDu[5].equals("/")))
            			|| ((uddInt >= 1 && uddInt <=29) && (ummInt == 2) && (uleapYear == 0 && uyyInt > 0) && (arraySDu[2].equals("/")) && (arraySDu[5].equals("/")))
            			|| ((uddInt >= 1 && uddInt <=28) && (ummInt == 2) && (uyyInt > 0) && (arraySDu[2].equals("/")) && (arraySDu[5].equals("/"))))
            	{
            		uProceedStartDate = true;
  
            	}
            	else
            		System.out.println("Error Input! Please enter a valid start date.");
            }
            else
            	System.out.println("Error Input! Please enter a valid length of start date.");
        	}
        	ucopySD = startDate;
        
        	while(uProceedEndDate != true){
            System.out.println("Enter the end date of stay(MM/DD/YY): ");
            endDate = sc.next();

            if(endDate.length() == 8)
            {
            	//copy startdate
            	String[] arraySDcopyu = ucopySD.split("", 8);
            	
            	String uSmm = arraySDcopyu[0] + arraySDcopyu[1];
            	int uSmmInt = Integer.parseInt(uSmm);
				
            	String uSdd = arraySDcopyu[3] + arraySDcopyu[4];
            	int uSddInt = Integer.parseInt(uSdd);
            	
            	String uSyy = arraySDcopyu[6] + arraySDcopyu[7];
            	int uSyyInt = Integer.parseInt(uSyy);
            	
            	//enddate
            	String[] arrayEDu = endDate.split("", 8);
            	
            	String uEmm = arrayEDu[0] + arrayEDu[1];
            	int uEmmInt = Integer.parseInt(uEmm);
            	
            	String uEdd = arrayEDu[3] + arrayEDu[4];
            	int uEddInt = Integer.parseInt(uEdd);
				
            	String uEyy = arrayEDu[6] + arrayEDu[7];
            	int uEyyInt = Integer.parseInt(uEyy);
            	int uEleapYear = uEyyInt%4;
            	
            	//making sure end date is older than start date
            	if((uEyyInt > uSyyInt) || (uEyyInt >= uSyyInt && uEmmInt > uSmmInt) || (uEyyInt >= uSyyInt && uEmmInt >= uSmmInt && uEddInt > uSddInt))
            	{
            	
            		//making sure there is a valid end date entered given the right mm/dd/yy
            	if(((uEddInt >= 1 && uEddInt <= 31) && (uEmmInt == 1 || uEmmInt == 3 || uEmmInt == 5 || uEmmInt == 7 || uEmmInt == 8 || uEmmInt == 10 || uEmmInt == 12) && (uEyyInt > 0) && (arrayEDu[2].equals("/")) && (arrayEDu[5].equals("/")))
            			|| ((uEddInt >= 1 && uEddInt <= 30) && (uEmmInt == 4 || uEmmInt == 6 || uEmmInt == 9 || uEmmInt == 11) && (uEyyInt > 0) && (arrayEDu[2].equals("/")) && (arrayEDu[5].equals("/")))
            			|| ((uEddInt >= 1 && uEddInt <=29) && (uEmmInt == 2) && (uEleapYear == 0 && uEyyInt > 0) && (arrayEDu[2].equals("/")) && (arrayEDu[5].equals("/")))
            			|| ((uEddInt >= 1 && uEddInt <=28) && (uEmmInt == 2) && (uEyyInt > 0) && (arrayEDu[2].equals("/")) && (arrayEDu[5].equals("/"))))
            	{
            		uProceedEndDate = true;
 
            	}
            	else
            		System.out.println("Error Input! Please enter a valid end date.");
            }
            	else
            		System.out.println("Error Input! Please enter an end date that is later than the start date.");
            }
            else
            	System.out.println("Error Input! Please enter a valid length of end date.");
            
        	}
		
	
		 
		 
		 System.out.println("Number of Guest: ");
		 noOfGuest= sc.next();
		 System.out.println("Enter check-in Date(MM/DD/YY): ");
		 checkInDate= sc.next();
		 System.out.println("Enter check-in Time(HH:mm): ");
		 checkInTime = sc.next();
		 
		 currRoom.setStartDate(startDate);
		 currRoom.setEndDate(endDate);
		 currRoom.setAvailibility("Reserved");
		 rmenu.updateRoomDatesAndAvailabilityInFile(rmenu.searchForRoom(room.size(), room,currRoom.getRoomNo()),startDate,endDate,currRoom.getAvailability());
		 
	     Reservation tempRD = new Reservation(resId,currRoom.getRoomNo(),currRoom.getRoomType(),currRoom.getBedType(),currRoom.isSmoking()
				,startDate,endDate,currRoom.isWifi(),currRoom.isRoomView(),
				currRoom.getAvailability(),"N",currGuest.getGuestName(),currGuest.getAddress(),currGuest.getContact(),currGuest.getCountry(),
				currGuest.getGender(),currGuest.getNationality(),currGuest.getIdentity(),currGuest.getCreditCardNo(),currGuest.getCreditCardCSV(),
				currGuest.getCreditCardExpDate(),noOfGuest,resStatus,checkInDate,checkInTime); 
	   
	     reservation.add(tempRD);//create reservation for existing guest
	     inOut.writeToResFile(tempRD);
		
	}
	
	
	/**
	* method to create print all existing reservation
	* @param reservation Collection of Reservation object that exist in the system
	*/
	public void printAllReservation(ArrayList<Reservation> reservation){
		for(int i=0;i<reservation.size();i++){
			System.out.println("Reservation ID : " + reservation.get(i).getResID());
			System.out.println("Room number : " + reservation.get(i).getResRoomNo());
			System.out.println("Room Type : " + reservation.get(i).getResRoomType());
			System.out.println("Number Of Guest:" + reservation.get(i).getNoOfGuest());
			System.out.println("Bed Type :" + reservation.get(i).getResBedType());
			System.out.println("Smoking Room : " + reservation.get(i).getResSmoking());
			System.out.println("Start Date of Stay : " + reservation.get(i).getResRoomStartDate());
			System.out.println("End Date of Stay : " + reservation.get(i).getResRoomEndDate());
			System.out.println("Wifi availability : " + reservation.get(i).getResRoomWifi());
			System.out.println("Check-in Status : " + reservation.get(i).getCheckInStatus());
			System.out.println("Name of Guest : " + reservation.get(i).getGuestName());
			System.out.println("Address : " + reservation.get(i).getGuestAddress());
			System.out.println("Country : " + reservation.get(i).getCountry());
			System.out.println("Gender : " + reservation.get(i).getGuestGender());
			System.out.println("Nationality : " + reservation.get(i).getGuestNationality());
			System.out.println("Contact : " + reservation.get(i).getGuestContacts());
			System.out.println("Credit Card No : " + reservation.get(i).getCreditCardNo());
			System.out.println("Credit Card CSV : " + reservation.get(i).getCreditCardCSV());
			System.out.println("Credit Card Expiry Date : " + reservation.get(i).getCreditCardExpDate());
			System.out.println("Identity : " + reservation.get(i).getGuestIdentity());
			System.out.println("Reservation Status : " + reservation.get(i).getResStatus());
			System.out.println("Check-in Date : " + reservation.get(i).getCheckInDate());
			System.out.println("Check-in Time : " + reservation.get(i).getCheckInTime());
			System.out.println();
		
			
			
			
		}
		
	}
	
	/**
	* method to validate if room exist
	* @param rmNumber room number of room to be validate
	* @param room Collection of Room object details in systems
	* @return flag -1 if room does not exist , 1 if room exist in the system
	*/
	public int validateRoomNumber(String rmNumber,ArrayList<Room> room) {
		int flag = -1;

		for(int i=0;i<room.size();i++){
			if(rmNumber.equals(room.get(i).getRoomNo())){
			flag = 1;//guest Exist
			}
		}
		return flag;

	}
	
	/**
	* method to validate if guest exist
	* @param guestID identification of guest to be validate
	* @param guest Guest object details in system
	* @return flag -1 if room does not exist , 1 if room exist in the system
	*/
	public int validateGuestID(String guestID,ArrayList<Guest> guest) {
		int flag = -1;

		for(int i=0;i<guest.size();i++){
			if(guestID.equals(guest.get(i).getIdentity())){
			flag = 1;//guest Exist
			}
		}
		return flag;
	}
	
	/**
	* method to validate if reservation exist
	* @param resID ID of reservation to be validate
	* @param reservation Reservation details in system
	* @return flag -1 if room does not exist , 1 if room exist in the system
	*/
	public int validateResID(String resID,ArrayList<Reservation> reservation) {
		int flag = -1;

		for(int i=0;i<reservation.size();i++){
			if(resID.equals(reservation.get(i).getResID())){
			flag = 1;//reservation Exist
			}
		}
		return flag;
	}
	
	/**
	* method to validate if guest has made reservation
	* @param guestID ID of guest to be validate
	* @param reservation Collection of reservation details in system
	* @return flag -1 if room does not exist , 1 if room exist in the system
	*/
	public int validateGuestIDInRes(String guestID,ArrayList<Reservation> reservation) {
		int flag = -1;

		for(int i=0;i<reservation.size();i++){
			if(guestID.equals(reservation.get(i).getGuestIdentity())){
			flag = 1;//guest exist
			}
		}
		return flag;
	}
	
	/**
	* method to validate if room has been reserved
	* @param roomNo room number to be validate
	* @param reservation Collection of reservation details in system
	* @return flag -1 if room does not exist , 1 if room exist in the system
	*/
	public int validateRoomNoInRes(String roomNo,ArrayList<Reservation> reservation) {
		int flag = -1;

		for(int i=0;i<reservation.size();i++){
			if(roomNo.equals(reservation.get(i).getResRoomNo())){
			flag = 1;//guest exist
			}
		}
		return flag;
	}
	
	/**
	* method to validate if guest has made a reservation
	* @param guestName Name of guest used for validation
	* @param reservation Collection of reservation details in system
	* @return flag -1 if room does not exist , 1 if room exist in the system
	*/
	public int validateGuestNameInRes(String guestName, ArrayList<Reservation> reservation) {
		int flag = -1;

		for(int i=0;i<reservation.size();i++){
			if(guestName.equals(reservation.get(i).getGuestName())){
			flag = 1;//guest exist
			}
		}
		return flag;
	}
}
