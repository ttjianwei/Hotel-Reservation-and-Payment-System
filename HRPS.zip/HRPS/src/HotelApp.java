
import java.util.*;

/**
The front-end of the hotel application
Mainly handles the user input and passing the logic to different controls 
@author FSP4
@version 1.0
@since 2016-04-06
*/ 
public class HotelApp {
	/**
	 * Scanner object used to read user Input
	 */
	static Scanner sc = new Scanner(System.in);
	
	/**
	 * Array List used to hold Guest objects
	 */
	private static ArrayList<Guest> guests = new ArrayList<Guest>();
	/**
	 * Array List used to hold Room objects 
	 */
	private static ArrayList<Room> rooms = new ArrayList<Room>();
	/**
	 * Array List used to hold RoomService objects 
	 */
	private static ArrayList<RoomService> rs = new ArrayList<RoomService>();
	/**
	 * Array List used to hold Reservation objects 
	 */
	private static ArrayList<Reservation> rd = new ArrayList<Reservation>();
	/**
	 * Array List used to hold WalkIns objects 
	 */
	private static ArrayList<WalkIns> wi = new ArrayList<WalkIns>();
	/**
	 * Array List used to hold Order objects 
	 */
	private static ArrayList<Order> or = new ArrayList<Order>();
	/**
	 * Declare an instance of GuestMenu object
	 */
	private static GuestMenu gm = new GuestMenu();
	/**
	 * Declare an instance of InputOutput object
	 */
	private static InputOutput inOut = new InputOutput();
	/**
	 * Declare an instance of RoomMenu object
	 */
	private static RoomMenu rmenu = new RoomMenu();	
	/**
	 * Declare an instance of RoomServiceMenu object
	 */
	private static RoomServiceMenu rsm = new RoomServiceMenu();
	/**
	 * Declare an instance of ReservationMenu object
	 */
	private static ReservationMenu res = new ReservationMenu();
	/**
	 * Declare an instance of CheckInController object
	 */
	private static CheckInController ci = new CheckInController();
	/**
	 * Declare an instance of Payment object
	 */
	private static Payment p = new Payment();
	/**
	 * Declare an instance of CheckOut object
	 */
	private static CheckOut co = new CheckOut();
	/**
	 * Declare an instance of WalkInMenu object
	 */
	private static WalkInMenu wm = new WalkInMenu();
	
	
	/**
	 * The Main Method
	 * @param args arguments
	 */
	
	public static void main(String[] args) {
		
        guests = inOut.initializeGuest();
        rooms = inOut.initializeRooms();   
        rd = inOut.initializeReservations(); 
        rs = inOut.initializeRoomServiceMenu();
        wi = inOut.initializeWalkIns();
        or = inOut.initializeOrder();
       
		int userInput =0;
		
			Timer t = new Timer();
			t.schedule(new TimerTask() {
			    @Override
			    public void run() {
			       ci.checkInExpired(rd, rooms);
			       //System.out.println("Checking...");
			    }
			}, 0, 60000);
			
		
		do{//prompting until user exit from system
		displayMainMenu();
		Guest tmpGuest;
		Room tmpRoom;
		
		//get user's input
		while(!sc.hasNextInt()) {
		    sc.next();
		    System.out.println("Please enter a valid choice(1-4)");
		    displayMainMenu();
		}
		
	   userInput = sc.nextInt();
			switch(userInput){
			//////////////////////// Guest class
			case 1:
			switch(displayGuestMenu()){
				case 1: tmpGuest = gm.createGuestDetails(guests);
						guests.add(tmpGuest);//create guest and store into ararylist guests
						inOut.writeToGuestFile(tmpGuest);
						break;
				case 2: int guestPosition = gm.searchForGuest(guests.size(),guests);
						gm.updateGuestList(guestPosition,guests);
						break;//to call updateGuestDetails() from guest class
				case 3: 
					boolean proceed = false;
					while(!proceed)
					try{
					guestPosition = gm.searchForGuest(guests.size(),guests);
					gm.displayGuest(guestPosition,guests);
					proceed = true;
					}
					catch(Exception e){
						System.out.println("Invalid Input!");
					}
					  
					break;//to display guest details
				case 4: break;//return to previous menu
			}break;
		    ////////////////////////
			case 2:
			switch(reservationMenu()){
				case 1:
	
				res.CreateReservation(guests,rooms,rd);	
				break;//to call createReservation() from reservation class
				case 2: 
				res.updateResList(rd, rooms,guests);
				break;//to call updateReservation() from reservation class
				case 3: 
					switch(removeReservationMenu()){
					case 1: int currResID = res.searchForResNo(rd);
					res.removeReservation(currResID);break;//remove object in array List
					case 2: int currResRoom = res.searchForRoonRes(rd);
					res.removeReservation(currResRoom);break;
					case 3:break;
					}
				break;//to call removeReservation() from reservation class
				case 4: 
					
					int userChoice = printReservationMenu();
					switch(userChoice){
				
						case 1:  			
							System.out.println("Print by...\n1.)Reservation ID\n2.)Room No\n3.)Previous menu");
							while(!sc.hasNextInt()) {
							    sc.next();
							    System.out.println("Please enter a valid choice(1-3)");
							}
							
						   userChoice = sc.nextInt();
							switch(userChoice){
								case 1:
								
									int currResID = res.searchForResIDPrint(rd);
									System.out.println(currResID);
									res.printResToConsole(rd,currResID);break;
								case 2:
									int curroomRes = res.searchForResRoomPrint(rd);
									res.printResToConsole(rd,curroomRes);break;
								case 3:break;
								default : System.out.println("Please enter a valid input!");
										break;
								
					}
						break;
						case 2: res.printAllReservation(rd);break;
						case 3: break;
				}
				break;
				case 5: 			
					ci.guestCheckIn(rd, rooms);
					//roomCheckIn() from CheckInController class
					break;
				case 6 :
					co.checkoutCust(rd,wi,rooms,or);
					//reload item from XML to the arraylist
					rd.clear();
					inOut.initializeReservations();
					rooms.clear();
					inOut.initializeRooms();
					wi.clear();
					inOut.initializeWalkIns();
					break;
					
					default : break;
				
				}
					break;//to call printReservation() from reservation class	
			////////////////////////
			case 3:
		    switch(roomDetailsMenu()){
		    	case 1: tmpRoom = rmenu.createRoomDetails(rooms);//to call createRoomDetails() from room class
		    			rooms.add(tmpRoom);
		    			inOut.writeToRoomFile(tmpRoom);break;
		    	case 2: int roomPosition = rmenu.searchForRoom(rooms.size(),rooms);
		    	    	rmenu.updateRoomList(roomPosition,rooms);
		    	    	break;//to call updateRoomDetails() from room class
		    	    		
		    	case 3: 
		    	roomPosition = rmenu.searchForRoom(rooms.size(),rooms);
				System.out.println("Room " + rooms.get(roomPosition).getRoomNo() + " availability status is : " +rooms.get(roomPosition).getAvailability());//checkRoomAvailability() from room class		
		    	break;//return to previous menu	
		    	
		    	case 4: displayRoomServiceMenu();			   
			    break;
		    	case 5:
				////////////////////////
			    rs.clear();
				rs = inOut.initializeRoomServiceMenu();
				rsm.displayMenu(rs);
				switch (roomServiceMenuItems()) {
				case 1:
					rsm.writeNewItemXML(rsm.createRoomServiceItem());
					break;// to call createRoomService() from room service class
				case 2:
					int itemPosition = rsm.searchForItem(rs.size(), rs);
					rsm.updateItemFields(itemPosition, rs);
					break;// to call updateRoomService() from room service class
				case 3:
					rsm.removeItemXML(rs);
					break;// to call removeRoomService() from room service class
				case 4:
					/*
					String statusRoom;
					int rmServivePos = 0;
					sc.nextLine();
					System.out.println("Update Room Service Order");
					System.out.println("Enter Room Number : ");
					statusRoom = sc.nextLine();

					rmServivePos = rsm.searchServiceExist(statusRoom);
					rsm.updateRoomServiceStatus(rmServivePos);*/
					break;
				// return to previous menu
				
				}
				break;
				case 6: 
				System.out.println("1.) Generate report by room status\n2.) Generate report by occupancy rate\n3.) Previous menu");
				userInput = sc.nextInt();
				switch(userInput){
					case 1:	p.generateReportRS(rooms);
					break;
					case 2:p.generateReportOR(rooms);
					break;
					case 3:break;
					
				}break;	
				case 7:break;		
		    }
		    break;

			////////////////////////
			case 4 : wm.CreateWalkIn(guests, rooms, wi,rd);break;
			case 0 : System.exit(0);
	
			}
		}
		
		while(true);
		
	}
		
			
	/**
	 * Display initial menu to user, choice of staff to enter "Guest Menu", "Reservation Menu", "Room Menu" or a Walk-in Guest
	 */	
public static void displayMainMenu(){
	
	System.out.println("Enter your choice...");
	System.out.println("1.) Guest Menu");
	System.out.println("2.) Reservation Menu");//create update/update/remove/print methods 
	System.out.println("3.) Room Menu"); //create & update room methods
	System.out.println("4.) Walk-In Guest");
	System.out.println("0.) Exit");
}
/**
 * Display guest menu to user, choice of staff to create guest, update guest, search for guest or go back to previous menu
 * @return staff's choice for guest menu
 */
public static int displayGuestMenu(){
	
	System.out.println("Enter your choice...");
	System.out.println("1.)Create guest details.");
	System.out.println("2.)Update guest details.");
	System.out.println("3.)Search for guest details.");
	System.out.println("4.)Previous menu.");
	while(!sc.hasNextInt()) {
		
	    sc.next();
	    System.out.println("Please enter a valid choice(1-4)");
	    System.out.println("Enter your choice...");
		System.out.println("1.)Create guest details.");
		System.out.println("2.)Update guest details.");
		System.out.println("3.)Search for guest details.");
		System.out.println("4.)Previous menu.");
	}
  int userInput = sc.nextInt();
	return userInput;
}

/**
 * Display Reservation menu to user, choice of staff to create reservation, update reservation, remove reservation, print reservation, check-in, check-out and print bill invoice
 * @return staff's choice for reservation menu
 */
public static int reservationMenu(){
	
	System.out.println("Enter your choice...");
	System.out.println("1.)Create reservation");
	System.out.println("2.)Update reservation");
	System.out.println("3.)Remove reservation");
	System.out.println("4.)Print reservation");
	System.out.println("5.)Check-in");
	System.out.println("6.)Check-out and print bill invoice");
	System.out.println("Any other number to previous menu ");
	while(!sc.hasNextInt()) {
	    sc.next();
	    System.out.println("1.)Please enter a valid choice");
	    System.out.println("Enter your choice...");
		System.out.println("1.)Create reservation");
		System.out.println("2.)Update reservation");
		System.out.println("3.)Remove reservation");
		System.out.println("4.)Print reservation");
		System.out.println("5.)Check-in");
		System.out.println("6.)Check-out and print bill invoice");
		System.out.println("Any other number to previous menu ");
	    
	}
	return sc.nextInt();
}
/**
 * Display Room menu to user, choice of staff to create room, update room, check for room's availability, order menu from room service, update room service menu's item or print room's statistic report
 * @return staff's choice for room menu
 */
public static int roomDetailsMenu(){
	System.out.println("1.)Create room details");
	System.out.println("2.)Update room details");
	System.out.println("3.)Check room availability");
	System.out.println("4.)Room service order menu");
	System.out.println("5.)Update room service menu items");
	System.out.println("6.)Print room statistic report");
	System.out.println("7.)Previous menu");
	return sc.nextInt();
}
/**
 * Display room service menu to staff, choice of staff to create, update or remove room service menu items
 * @return staff's choice for room service menu items
 */
public static int roomServiceMenuItems(){
	System.out.println("1.)Create room service menu items");
	System.out.println("2.)Update room service menu items");
	System.out.println("3.)Remove room service menu items");
	System.out.println("4.)Previous menu");
	return sc.nextInt();
}
/**
 * Allows user to remove a certain reservation either base on reservation ID, guest ID or by Room ID
 * @return user's choice
 */
public static int removeReservationMenu(){
	
	
	System.out.println("Remove by...\n1.) By Reservation ID\n2.) By Room ID\n3.) Previous menu");
	int userInput = sc.nextInt();
	switch(userInput){
	case 1: return 1;
	case 2: return 2;
	case 3: break;
	default : break;
	
	}
	return 4;
}
/**
 * Display printing of reservation menu to user, choice of user to print by single reservation or all reservation
 * @return staff's choice for choice of printing
 */
public static int printReservationMenu(){
	int userInput =0;
	
	
	System.out.println("1.)Print Single Reservation\n2.)All Reservation\n3.)Previous menu");
	userInput = sc.nextInt();
 
	switch(userInput){
	case 1: return 1;
	case 2: return 2;
	case 3: return 3;
	}
	return 3;
}

public static void displayRoomServiceMenu() {

	String userInput;
	int flag = -1, userChoice = 0;

	Scanner sc = new Scanner(System.in);

	// 1) check room number
	System.out.println("Enter Room Number for ordering room service ");
	userInput = sc.nextLine();

	for(int i = 0; i < rooms.size(); i++){
		if(userInput.equals(rooms.get(i).getRoomNo())){
			flag = 1;
		}
	}
	
//	flag = RoomServiceMenu.validateRoomNumber(userInput);

	while (flag != 1) {
		System.out.println("Room Does not exist in system ! ");
		System.out.println("Please re-enter room Number for ordering room service ");
		userInput = sc.nextLine();
		for(int i = 0; i < rooms.size(); i++){
			if(userInput.equals(rooms.get(i).getRoomNo())){
				flag = 1;
			}
		}
	}
	// load menu, enter order,save to xml
	// rs = idb.initializeRoomServiceMenu();
		rs.clear();
	rs = inOut.initializeRoomServiceMenu();
	rsm.displayMenu(rs);
	rsm.createOrder(userInput, rs, or);


}

}
