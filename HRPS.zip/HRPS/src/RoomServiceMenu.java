
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;
import java.util.regex.Pattern;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
/**
Represent a room service menu in the system
Mainly control the logic of how room service menu is being handled
@author FSP4
@version 1.0
@since 2016-04-06
*/ 


public class RoomServiceMenu {
	final String DOUBLE_PATTERN = "[0-9]+(\\.){0,1}[0-9]*";
	final String INTEGER_PATTERN = "\\d+";
	Scanner sc = new Scanner(System.in);
	
	/**
	 * Display All Room Service Menu Item
	 * @param arRoomServiceMenu Display all data stored in ArrayList
	 */
	public void displayMenu(ArrayList<RoomService> arRoomServiceMenu) {
		// variable to store according to category
		String category;

		System.out.println(String.format("%35s", "Alcoholic"));
		System.out.println("============================================================================");
		System.out.println("Item" + String.format("%25s", "Price") + String.format("%18s", "Description"));

		for (int i = 0; i < arRoomServiceMenu.size(); i++) {
			category = arRoomServiceMenu.get(i).getFoodCategory();
			// do if condition for each category
			if (category.equals("Alcoholic")) {
				System.out.println(String.format("%-4s", arRoomServiceMenu.get(i).getFoodIndex() + ") ")
						+ String.format("%-20s", arRoomServiceMenu.get(i).getFoodName()) + " $"
						+ String.format("%-8s", arRoomServiceMenu.get(i).getFoodPrice())
						+ arRoomServiceMenu.get(i).getFoodDescription());

			} // end if
		} // end for

		System.out.println(String.format("%35s", "Snack"));
		System.out.println("============================================================================");
		System.out.println("Item" + String.format("%25s", "Price") + String.format("%18s", "Description"));

		for (int i = 0; i < arRoomServiceMenu.size(); i++) {
			category = arRoomServiceMenu.get(i).getFoodCategory();
			// do if condition for each category
			if (category.equals("Snack")) {
				System.out.println(String.format("%-4s", arRoomServiceMenu.get(i).getFoodIndex() + ") ")
						+ String.format("%-20s", arRoomServiceMenu.get(i).getFoodName()) + " $"
						+ String.format("%-8s", arRoomServiceMenu.get(i).getFoodPrice())
						+ arRoomServiceMenu.get(i).getFoodDescription());

			} // end if
		} // end for

		System.out.println(String.format("%35s", "Beverage"));
		System.out.println("============================================================================");
		System.out.println("Item" + String.format("%25s", "Price") + String.format("%18s", "Description"));

		for (int i = 0; i < arRoomServiceMenu.size(); i++) {
			category = arRoomServiceMenu.get(i).getFoodCategory();
			// do if condition for each category
			if (category.equals("Beverage")) {
				System.out.println(String.format("%-4s", arRoomServiceMenu.get(i).getFoodIndex() + ") ")
						+ String.format("%-20s", arRoomServiceMenu.get(i).getFoodName()) + " $"
						+ String.format("%-8s", arRoomServiceMenu.get(i).getFoodPrice())
						+ arRoomServiceMenu.get(i).getFoodDescription());

			} // end if
		} // end for

		System.out.println(String.format("%35s", "Main Course"));
		System.out.println("============================================================================");
		System.out.println("Item" + String.format("%25s", "Price") + String.format("%18s", "Description"));

		for (int i = 0; i < arRoomServiceMenu.size(); i++) {
			category = arRoomServiceMenu.get(i).getFoodCategory();
			// do if condition for each category
			if (category.equals("Main Course")) {
				System.out.println(String.format("%-4s", arRoomServiceMenu.get(i).getFoodIndex() + ") ")
						+ String.format("%-20s", arRoomServiceMenu.get(i).getFoodName()) + " $"
						+ String.format("%-8s", arRoomServiceMenu.get(i).getFoodPrice())
						+ arRoomServiceMenu.get(i).getFoodDescription());

			} // end if
		} // end for

		System.out.println(String.format("%35s", "Dessert"));
		System.out.println("============================================================================");
		System.out.println("Item" + String.format("%25s", "Price") + String.format("%18s", "Description"));

		for (int i = 0; i < arRoomServiceMenu.size(); i++) {
			category = arRoomServiceMenu.get(i).getFoodCategory();
			// do if condition for each category
			if (category.equals("Dessert")) {
				System.out.println(String.format("%-4s", arRoomServiceMenu.get(i).getFoodIndex() + ") ")
						+ String.format("%-20s", arRoomServiceMenu.get(i).getFoodName()) + " $"
						+ String.format("%-8s", arRoomServiceMenu.get(i).getFoodPrice())
						+ arRoomServiceMenu.get(i).getFoodDescription());

			} // end if
		} // end for

	}// end displayMenu()

	/**
	 * Create Room Service Menu
	 * @param roomNo User input of Room Number
	 * @param rmService Retrieve Menu Details 
	 * @param o Collection of Orders in the system
	 */
	public void createOrder(String roomNo, ArrayList<RoomService> rmService, ArrayList<Order> o) {
		InputOutput io = new InputOutput();
		OrderController orderCon = new OrderController();
		ArrayList<String> rmOrder = new ArrayList<String>();
		int reorderFlag = 1;
		int userChoice = 0;
		String foodItem = "", guestRemarks = "";
		double foodTotalPrice = 0.0;

		// to create date and time
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();

		while (reorderFlag == 1) {

			System.out.println("Enter Index to Order (Enter 0 to Exit)");
			userChoice = sc.nextInt();

			if (userChoice == 0) {
				return;
			}
			for (int i = 0; i < rmService.size(); i++) {
				// do if condition for each category
				if (rmService.get(i).getFoodIndex() == userChoice) {
					rmOrder.add(rmService.get(i).getFoodName());
					rmOrder.add(rmService.get(i).getFoodPrice());
				}
			} // end for loop

			System.out.println("Anymore items to add ?\n1.Yes\n2.No");
			reorderFlag = sc.nextInt();
			sc.nextLine();

		} // end while

		System.out.println("Any Remarks to add ? (ie Less oil, Less salt)");
		guestRemarks = sc.nextLine();

		// write to orderRoomService.xml
		io.writeOrderXML(rmOrder, roomNo, guestRemarks); // write to xml 
		orderCon.addOrder(o, rmOrder, guestRemarks, roomNo); //write to ArrayList Order Object
		
		
		// print receipt order
		System.out.println("===================================================");
		System.out.println("Order Created at");

		System.out.println(dateFormat.format(date) + "\n");

		for (int i = 0; i < rmOrder.size(); i++) {
			if (i % 2 == 0) {
				foodItem = foodItem.concat(rmOrder.get(i));
				foodItem = foodItem.concat("\n");
			}
		}
		for (int i = 0; i < rmOrder.size(); i++) {
			if (i % 2 == 1) {
				foodTotalPrice += Double.parseDouble(rmOrder.get(i));
			}
		}

		System.out.println("Item\n------------------------------------------------------");
		System.out.println(foodItem);
		System.out.println("Payable Amount Outstanding : " + foodTotalPrice);
		System.out.println("Order successfully placed !!");
		System.out.println("==============================================\n");
		
	}


	/**
	 * Add new Room Service Item into the current Menu
	 * @return stored new item created by user
	 */
	public RoomService createRoomServiceItem() {
		RoomService rsMenu = null;
		int flag = -1;
		String foodName, foodPrice, foodDescription, foodCategory;

		
		
		System.out.println("Enter Food Item Name : ");
		foodName = sc.nextLine();
		
		System.out.println("Enter Food Price : ($) ");
		foodPrice = sc.nextLine();
		
		do{
			if(Pattern.matches(DOUBLE_PATTERN, foodPrice)||(Pattern.matches(INTEGER_PATTERN, foodPrice))){
				flag = 1;
			}else{
				System.out.println("Please enter a numerical value !!!");
				foodPrice = sc.nextLine();
			}
		}while (flag == -1);
		
		System.out.println("Enter Food Description : ");
		foodDescription = sc.nextLine();
		
		System.out.println("Enter Food Category : (Snack, Alcoholic, Beverage, Main Course, Dessert");
		foodCategory = sc.nextLine();
		
		do {
			if (foodCategory.equals("Snack") || foodCategory.equals("Alcoholic") || foodCategory.equals("Beverage")
					|| foodCategory.equals("Main Course") || foodCategory.equals("Dessert")) {
				rsMenu = new RoomService(foodName, foodPrice, foodDescription, foodCategory);
				flag = 1;
			} else {
				System.out.println("Category must match Snack or Alcoholic or Beverage or Main Course or Dessert !");
				System.out.println("Enter Food Category : (Snack, Alcoholic, Beverage, Main Course, Dessert");
				foodCategory = sc.nextLine();
			}
		} while (flag == -1);

		return rsMenu;
	}

	/**
	 * Store new item created into database
	 * @param rs New Item created by user
	 */
	public void writeNewItemXML(RoomService rs) {
		try {
			String filepath = "roomServiceMenu.xml";
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(filepath);

			Element dataTag = doc.getDocumentElement();
			Element menuListTag = (Element) dataTag.getElementsByTagName("Menu").item(0);
			Element item = doc.createElement("item");
			Element foodName = doc.createElement("name");
			Element foodPrice = doc.createElement("price");
			Element foodDescription = doc.createElement("description");
			Element foodCategory = doc.createElement("category");

			foodName.setTextContent(rs.getFoodName());
			foodPrice.setTextContent(rs.getFoodPrice());
			foodDescription.setTextContent(rs.getFoodDescription());
			foodCategory.setTextContent(rs.getFoodCategory());

			item.appendChild(foodName);
			item.appendChild(foodPrice);
			item.appendChild(foodDescription);
			item.appendChild(foodCategory);

			menuListTag.appendChild(item);

			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);

			StreamResult result = new StreamResult(new File(filepath));
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			transformer.transform(source, result);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Remove a particular Menu Item
	 * @param rmService store updated Arraylist of items after removing
	 */
	public void removeItemXML(ArrayList<RoomService> rmService) {
		int userChoice = 0;
		String itemToRemove = "";
	
		System.out.println("Enter index to remove item from Menu");
		userChoice = sc.nextInt();

		// loop thru to find same name
		for (int i = 0; i < rmService.size(); i++) {
			// do if condition for each category
			if (rmService.get(i).getFoodIndex() == userChoice) {
				itemToRemove = rmService.get(i).getFoodName();
			}
		} // end for loop

		// link with XML
		try {
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse("roomServiceMenu.xml");
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(new File("roomServiceMenu.xml"));

			NodeList list = doc.getElementsByTagName("item");

			for (int i = 0; i < list.getLength(); i++) {
				Element item = (Element) list.item(i);
				Element name = (Element) item.getElementsByTagName("name").item(0);
				String pName = name.getTextContent();
				if (pName.equals(itemToRemove)) {
					item.getParentNode().removeChild(item);
				}
			}

			transformer.transform(source, result);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * Update a particular field for each Menu Item
	 * @param position index in XML file
	 * @param rmService Update fields and save copy to ArrayList
	 */
	public void updateItemFields(int position, ArrayList<RoomService> rmService) {
		int flag = -1;
	
		try {
			String filepath = "roomServiceMenu.xml";
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(filepath);
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(new File(filepath));
			Node nodes = doc.getElementsByTagName("item").item(position);
			NodeList list = nodes.getChildNodes();

			System.out.println("1)Update Food Name\n2)Update Food Price\n3)Update Description");
			int userInput = sc.nextInt();
			sc.nextLine();

			switch (userInput) {
			case 1:
				System.out.println("1.)New Food Name:");
				String name = sc.nextLine();

				for (int i = 0; i != list.getLength(); ++i) {
					Node child = list.item(i);
					if (child.getNodeName().equals("name")) {
						child.getFirstChild().setNodeValue(name);
					}
				}
				transformer.transform(source, result);
				rmService.get(position).setFoodName(name);
				break;
			case 2:
				System.out.println("1.)Revised Food Price:");
				String price = sc.nextLine();

				//validation of price 
				do{
					if(Pattern.matches(DOUBLE_PATTERN, price)||(Pattern.matches(INTEGER_PATTERN, price))){
						flag = 1;
					}else{
						System.out.println("Please enter a numerical value !!!");
						price = sc.nextLine();
					}
				}while (flag == -1);
				
				
				for (int i = 0; i != list.getLength(); ++i) {
					Node child = list.item(i);
					if (child.getNodeName().equals("price")) {
						child.getFirstChild().setNodeValue(price);
					}
				}
				transformer.transform(source, result);
				rmService.get(position).setFoodPrice(price);
				break;
			case 3:
				System.out.println("1.)New Food Description:");
				String description = sc.nextLine();

				for (int i = 0; i != list.getLength(); ++i) {
					Node child = list.item(i);
					if (child.getNodeName().equals("description")) {
						child.getFirstChild().setNodeValue(description);
					}
				}
				transformer.transform(source, result);
				rmService.get(position).setFoodDescription(description);
				break;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}// end updateItemFields

	/**
	 * Search for a certain Menu Item in XML
	 * @param size Total Size of Menu Item
	 * @param rsMenu All Room Service Item data
	 * @return	index of item found
	 */
	public int searchForItem(int size, ArrayList<RoomService> rsMenu) {
		int userChoice = 0;
		int count = 0; // xml matches input

		System.out.println("Enter item index to update from Menu");
		userChoice = sc.nextInt();

		// search pos in XML
		try {
			File fXmlFile = new File("roomServiceMenu.xml");
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(fXmlFile);
			doc.getDocumentElement().normalize();
			NodeList nList = doc.getElementsByTagName("item");

			// loop through file to obtain attributes
			for (int temp = 0; temp < nList.getLength(); temp++) {
				Node nNode = nList.item(temp);

				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode;
					if (rsMenu.get(userChoice - 1).getFoodName()
							.equals(eElement.getElementsByTagName("name").item(0).getTextContent())) {
						count = temp;
						System.out.println(count + " pos in xml is "
								+ eElement.getElementsByTagName("name").item(0).getTextContent());
					}
				}

			} // end xml for loop

		} catch (Exception e) {
			e.printStackTrace();
		}

		return count;

	}

	/**
	 * Update Room Service Status
	 * @param position update postion of Status in XML after search
	 */
	public void updateRoomServiceStatus(int position) {
	
		int statusChoice = 0;

		if (position != -1) {
			System.out.println("1) Change status to Delivered");
			System.out.println("2) Change status to Preparing");
			statusChoice = sc.nextInt();
			try {
				String filepath = "orderRoomService.xml";
				DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
				DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
				Document doc = docBuilder.parse(filepath);
				TransformerFactory transformerFactory = TransformerFactory.newInstance();
				Transformer transformer = transformerFactory.newTransformer();
				DOMSource source = new DOMSource(doc);
				StreamResult result = new StreamResult(new File(filepath));
				Node nodes = doc.getElementsByTagName("order").item(position);
				NodeList list = nodes.getChildNodes();

				for (int i = 0; i != list.getLength(); ++i) {
					Node child = list.item(i);
					if (child.getNodeName().equals("status")) {
						if (statusChoice == 1) {
							child.getFirstChild().setNodeValue("Delivered");
							System.out.println("Status changed to Delivered");
						} else if (statusChoice == 2) {
							child.getFirstChild().setNodeValue("Preparing");
							System.out.println("Status changed to Preparing");
						}
					}
				}
				transformer.transform(source, result);

			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			System.out.println("Room never order service !!");
		} // end flag

	}// end update status

	/**
	 * Retrieve a Order from Room
	 * @param rmNumber User input of Room Number
	 * @return position of order in XML
	 */
	public int displayOrder(String rmNumber){
		ArrayList al = new ArrayList();
		int orderIndex = 1;
		int userChoice = 0;
		
		//retrive all order from the list
		try {
			File fXmlFile = new File("orderRoomService.xml");
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(fXmlFile);
			doc.getDocumentElement().normalize();
			NodeList nList = doc.getElementsByTagName("order");

			// loop through file to obtain attributes
			for (int temp = 0; temp < nList.getLength(); temp++) {
				Node nNode = nList.item(temp);

				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) nNode;
					if(eElement.getElementsByTagName("roomNo").item(0).getTextContent().equals(rmNumber)){
						System.out.println(orderIndex + ") " + eElement.getElementsByTagName("item").item(0).getTextContent());
						al.add(temp);//store position in xml
						orderIndex++;
					}
				}
			} // end xml for loop
			System.out.println("Which order number do you want to change ? ");
			userChoice = sc.nextInt();		
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return (int) al.get(userChoice - 1); //position in XML
	}



}// end class
