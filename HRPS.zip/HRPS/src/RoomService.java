

/**
Represent a room service object menu in the system
@author FSP4
@version 1.0
@since 2016-04-06
*/ 
public class RoomService {

	private String foodName;
	private String foodPrice;
	private String foodDescription;
	private String foodCategory;
	private int foodIndex;

	/**
	 * Constructor
	 * @param foodName Food Naming	
	 * @param foodPrice Food Pricing
	 * @param foodDescription Food Description 
	 * @param foodCategory Food Category
	 * @param foodIndex Food Index
	 */
	public RoomService(String foodName, String foodPrice, String foodDescription, String foodCategory, int foodIndex) {
		this.foodName = foodName;
		this.foodPrice = foodPrice;
		this.foodDescription = foodDescription;
		this.foodCategory = foodCategory;
		this.foodIndex = foodIndex;
	}

	/**
	 * Constructor used when creating Room Service
	 * @param foodName Food Naming	
	 * @param foodPrice Food Pricing
	 * @param foodDescription Food Description 
	 * @param foodCategory Food Category
	 */
	public RoomService(String foodName, String foodPrice, String foodDescription, String foodCategory) {
		this.foodName = foodName;
		this.foodPrice = foodPrice;
		this.foodDescription = foodDescription;
		this.foodCategory = foodCategory;
	}

	/**
	 * Get Food Index
	 * @return foodIndex return the index of food
	 */
	public int getFoodIndex() {
		return foodIndex;
	}

	/**
	 * Set Food Index 
	 * @param foodIndex index of food
	 */
	public void setFoodIndex(int foodIndex) {
		this.foodIndex = foodIndex;
	}

	/**
	 * Get Food Category
	 * @return category 
	 */
	public String getFoodCategory() {
		return foodCategory;
	}

	/**
	 * Set Food Category
	 * @param foodCategory category 
	 */
	public void setFoodCategory(String foodCategory) {
		this.foodCategory = foodCategory;
	}

	/**
	 * Get Food Name
	 * @return Food naming 
	 */
	public String getFoodName() {
		return foodName;
	}

	/**
	 * Set new Food Name
	 * @param foodName new name of food
	 */
	public void setFoodName(String foodName) {
		this.foodName = foodName;
	}

	/**
	 * Get Food Pricing
	 * @return foodPrice return price of food
	 */
	public String getFoodPrice() {
		return foodPrice;
	}

	/**
	 * Set Food Price
	 * @param foodPrice food pricing
	 */
	public void setFoodPrice(String foodPrice) {
		this.foodPrice = foodPrice;
	}

	/**
	 * Get Food Description
	 * @return description of food
	 */
	public String getFoodDescription() {
		return foodDescription;
	}

	/**
	 * Set Food Description 
	 * @param foodDescription description of food
	 */
	public void setFoodDescription(String foodDescription) {
		this.foodDescription = foodDescription;
	}

}
