
/**
Represent a Room in the System
A system can has many Room
@author FSP4
@version 1.0
@since 2016-04-06
*/ 

public class Room {
	/**
	* roomType Type of room preference by guest
	*/
	private String roomType;
	/**
	* roomNo room number of choice
	*/ 
	private String roomNo;
	/**
	* bedType Type of bed preference by guest
	*/
	private String bedType;
	/**
	* smoking smoking preference of guest
	*/
	private String smoking;
	/**
	* roomStartDate start date of room
	*/
	private String startDate;
	/**
	* roomEndDate end date of room
	*/
	private String endDate;
	/**
	* wifi wifi preference of guest
	*/
	private String wifi;
	/**
	* roomView Room view preference of guest
	*/
	private String roomView;
	/**
	* roomAvailability Availability of room
	*/
	private String availability;
	/**
	* checkInStatus check-in status of guest
	*/
	private String checkInStatus;
	
	
	 /**
	 * Room constructor with room details
	 * @param roomNo room number of requested room by guest
	 * @param roomType room type preference
	 * @param bedType bed type preference
	 * @param smoking smoking preference 
	 * @param startDate start date of room
	 * @param endDate end date of room
	 * @param roomAvailability current availability of room
	 * @param checkInStatus check in status of guest
	 * @param roomView room view preference
	 * @param wifi room wifi preference
	 */
	public Room(String roomType,String bedType,String roomNo
			,String smoking,String startDate,String endDate
			,String wifi,String roomView,String roomAvailability,String checkInStatus){
		
		this.roomType= roomType;
		this.roomNo = roomNo;
		this.bedType = bedType;
		this.smoking = smoking;
		this.startDate = startDate;
		this.endDate = endDate;
		this.wifi = wifi;
		this.roomView = roomView;
		this.availability = roomAvailability;
		this.checkInStatus = checkInStatus;
		
	}
	
	/**
	* Method to get room type
	* @return room's type(String)
	*/ 
	public String getRoomType() {
		return roomType;
	}
	/**
	* Method to set room type
	* @param roomType new room type
	*/
	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}

	/**
	* Method to get room number 
	* @return room's number(String)
	*/ 
	public String getRoomNo() {
		return roomNo;
	}
	/**
	* Method to set room number
	* @param roomNo new room number
	*/
	public void setRoomNo(String roomNo) {
		this.roomNo = roomNo;
	}
	/**
	* Method to get the bed Type
	* @return bed's type(String)
	*/ 
	public String getBedType() {
		return bedType;
	}
	/**
	* Method to set bedType
	* @param bedType new type of bed
	*/
	public void setBedType(String bedType) {
		this.bedType = bedType;
	}
	/**
	* Method to get the guest smoking preference
	* @return smoking guest's room smoking preference(String)
	*/ 
	public String isSmoking() {
		return smoking;
	}
	/**
	* Method to set smoking preference
	* @param smoking new smoking preference
	*/
	public void setSmoking(String smoking) {
		this.smoking = smoking;
	}
	/**
	* Method to get the room start date 
	* @return startDate room's start date(String)
	*/ 
	public String getStartDate() {
		return startDate;
	}
	/**
	* Method to set start date of room
	* @param startDate new start date of room
	*/
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	/**
	* Method to get the room end date 
	* @return room's end date(String)
	*/ 
	public String getEndDate() {
		return endDate;
	}
	/**
	* Method to set end date of room
	* @param endDate new end date of room
	*/
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	/**
	* Method to get the room wifi preference
	* @return wifi room's wifi preference(String)
	*/ 
	public String isWifi() {
		return wifi;
	}
	/**
	* Method to set wifi preference of room
	* @param wifi new wifi preference of room
	*/
	public void setWifi(String wifi) {
		this.wifi = wifi;
	}
	/**
	* Method to get room view preference of room
	* @return roomView room view preference of room
	*/
	public String isRoomView() {
		return roomView;
	}
	/**
	* Method to set room view preference of room
	* @param roomView new room view preference of room
	*/
	public void setRoomView(String roomView) {
		this.roomView = roomView;
	}
	/**
	* Method to set new room availability
	* @param available new room availability 
	*/
	public void setAvailibility(String available){
		
		this.availability= available;
	}
	/**
	* Method to get the room's availability
	* @return roomAvaiability room's availability(String)
	*/ 
	public String getAvailability(){
		return availability;
	}
	/**
	* Method to get check in status
	* @return checkInStatus Check In status(String)
	*/ 
	public String getCheckInStatus(){
		return checkInStatus;
	}
	/**
	* Method to set new check in status
	* @param checkInStatus new check in status 
	*/
	public void setCheckInStatus(String checkInStatus){
		this.checkInStatus = checkInStatus;
	}
}
