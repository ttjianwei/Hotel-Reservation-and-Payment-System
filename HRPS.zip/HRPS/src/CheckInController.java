

import java.io.File;
import java.sql.*;
import java.util.Date;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Scanner;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
Represent the control and logic for guest check in
Mainly handles the the state of reservation check-in status and update room availability when a guest check in 
@author FSP4
@version 1.0
@since 2016-04-06
*/ 


public class CheckInController {
	/**
	 * Scanner object to take in user input
	 */
	Scanner sc = new Scanner(System.in);
	
	/**
	 * method to validate guest check in to room 
	 @param reservation list of reservations that has been made
	 @param room list of current rooms in hotel
	 */
public void guestCheckIn(ArrayList<Reservation> reservation, ArrayList<Room> room){
	/**
	 * instance of inputOutput object
	 */
	InputOutput io = new InputOutput();
	
	System.out.println("Enter room to check-in: ");
	/**
	 * roomNo room number of check in room
	 */
	String roomNo = sc.next();
	int flag = validateRoomNumber(roomNo);
	while (flag != 1) {
		System.out.println("Room does not exist in system ! ");
		System.out.println("Please re-enter your room number again!");
		roomNo = sc.next();
		flag = validateRoomNumber(roomNo);	
	}
	
	int count = 0;
	for(int i=0;i<room.size();i++){
    	if(room.get(i).getRoomNo().equals(roomNo)){
    		count =i;
    	}
    	
    	
    }
	int count2=  0;
	for(int i=0;i<reservation.size();i++){
    	if(reservation.get(i).getResRoomNo().equals(roomNo)){
    		count2 =i;
    	}
    	
    }
	room.get(count).setAvailibility("Occupied");
	room.get(count).setCheckInStatus("Y");
	reservation.get(count2).setCheckInStatus("Y");
	reservation.get(count2).setResAvailability("Occupied");
	io.checkInWriteToFile(count2,count);
	System.out.println("Check-in Successful for room " + room.get(count).getRoomNo() + "!");
	
}


/**
 * method to check check-in date and time in reservations.xml and validate if reservations has expired 
 * @param reservation list of reservations that has been made
 * @param room list of current rooms in hotel
 */
public void checkInExpired(ArrayList<Reservation> reservation,ArrayList<Room> room){
	
	
	
	DateFormat formatter = new SimpleDateFormat("MM/dd/yy HH:mm");
	
	try{
	//open reservations file
	String filepath = "reservations.xml";
	DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
	DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
	Document doc = docBuilder.parse(filepath);
	TransformerFactory transformerFactory = TransformerFactory.newInstance();
	Transformer transformer = transformerFactory.newTransformer();
	DOMSource source = new DOMSource(doc);
	StreamResult result = new StreamResult(new File(filepath));
	
	//open RoomList file
	String filepath2 = "roomList.xml";
	DocumentBuilderFactory docFactory2 = DocumentBuilderFactory.newInstance();
	DocumentBuilder docBuilder2 = docFactory2.newDocumentBuilder();
	Document doc2 = docBuilder2.parse(filepath2);
	TransformerFactory transformerFactory2 = TransformerFactory.newInstance();
	Transformer transformer2 = transformerFactory2.newTransformer();
	DOMSource source2 = new DOMSource(doc2);
	StreamResult result2 = new StreamResult(new File(filepath2));

	

	
	for(int i=0;i<reservation.size();i++){//loop through file to check check-in dates against current date
	
		
		
			String date = reservation.get(i).getCheckInDate() ;
			String time =  reservation.get(i).getCheckInTime();
			String dateTime = date + " " + time;
			Date yourDateObject = (Date) formatter.parse(dateTime);
			Date dateobj = new Date(); 
	
			if(dateobj.after(yourDateObject)){
				
				reservation.get(i).setResStatus("Expired");
			    reservation.get(i).setResAvailability("Vacant");
				if(reservation.get(i).getResStatus().equals("Expired")){
					Element element = (Element)doc.getElementsByTagName("reservation").item(i);
					if ( null != element) {

					element.getParentNode().removeChild(element);

					transformer.setOutputProperty(OutputKeys.INDENT, "yes");
					}
				}
				transformer.transform(source, result);
				
				
				
				
				int moreReservations = 0;
			    for(int j=0;j<room.size();j++){
			    	if(room.get(j).getRoomNo().equals(reservation.get(i).getResRoomNo())){
			    		room.get(j).setAvailibility("Vacant");
			    		reservation.remove(i); // Remove reservation from Reservation arrayList
			    		
			    				
			    		for(int t = 0; t < reservation.size(); t++){
			    			if(reservation.get(t).getResRoomNo().equals(room.get(j)))
			    				 moreReservations++;
			    			
			    		}
			    		
			    		if(moreReservations==0){
			    		
			    		Node nodes2 = doc2.getElementsByTagName("room").item(j);
			    		NodeList list2 = nodes2.getChildNodes();
			    		for (int l = 0; l != list2.getLength(); ++l) {
			    			Node child = list2.item(l);

			    			if (child.getNodeName().equals("availability")) {
			    				child.getFirstChild().setNodeValue("Vacant");
			    			}
			    		}

						transformer2.transform(source2, result2);

			    	}
			    }
			    }
			}	
			
						
	}
	}
		 catch (Exception e) {
			//e.printStackTrace();
			return;
		}
	
	}

/**
 * method to check check-in date and time in reservations.xml and validate if reservations has expired 
 * @param rmNumber room number to be validated
 * @return flag 1 to represent room number exist, return -1 if room number doesn't exist in system
 */
public int validateRoomNumber(String rmNumber) {
	int flag = -1;

	// check with xml
	try {
		File fXmlFile = new File("roomList.xml");
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
		Document doc = dBuilder.parse(fXmlFile);
		doc.getDocumentElement().normalize();

		NodeList nList = doc.getElementsByTagName("room");

		for (int temp = 0; temp < nList.getLength(); temp++) {
			Node nNode = nList.item(temp);

			if (nNode.getNodeType() == Node.ELEMENT_NODE) {
				Element eElement = (Element) nNode;
				if (eElement.getElementsByTagName("roomNo").item(0).getTextContent().equals(rmNumber)) {
					flag = 1;
				}
			}
		}
	} catch (Exception e) {
		e.printStackTrace();
	}

	return flag;
}
}
