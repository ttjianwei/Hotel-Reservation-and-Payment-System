import java.util.*;

import java.util.Date;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
/**
 * Represent the payment and the report
 * One checkout will have one report
 * @author FSP group 4
 *
 */


public class Payment {
	/**
	 * The card payment type: 1 for credit 0 for cash
	 */
	private int cardPaymentType;//1 = credit 0 = cash
	/**
	 * Amount the promotion will be given
	 * Assumption: any event there is only 5% discount
	 */
	private static final double promotion=0.05;//assumption: any event there is only 5% discount
	/**
	 * Amount the extra charges given
	 * Assumption: weekend there is only 5% surcharge
	 */
	private static final double extraCharge=0.05;//assumption: weekend there is only 5% extra
	/**
	 * Rate of GST
	 */
	private static final double gst=0.07;//assumption: any event there is only 5% discount
	/**
	 * Rate of service charge
	 */
	private static final double serviceCharge=0.1;//assumption: any event there is only 5% discount
	/**
	 * Name of Customer as per their credit card
	 */
	private String creditCardName;
	/**
	 * Credit card billing address
	 */
	private String billingAddr;
	
	/**
	 * Default constructor
	 */
	public Payment(){
		cardPaymentType = 0;
		creditCardName ="";
		billingAddr = "";
	}
	
	
	//get/set method
	/**
	 * Get the card payment Type
	 * @return cardPaymentType
	 */
	public int getCardPaymentType(){return cardPaymentType;}
	
	/**
	 * Change the card payment type
	 * @param cpt should be 1 or 0
	 */
	public void setCardPaymentType(int cpt){cardPaymentType = cpt;}
	
	/**
	 * Get the name of customer as per credit card 
	 * @return creditCardName this credit Card name 
	 */
	public String getCreditCardName(){return creditCardName;}
	
	/**
	 * Change the name based on the credit card
	 * @param ccname new name should include the name
	 */
	public void setCreditCardName(String ccname){creditCardName = ccname;}
	
	/**
	 *  Get the billing address based on the credit card
	 * @return billingAddr 
	 */
	public String getBillingAddr(){return billingAddr;}
	
	/**
	 * Change the billing address to another billing address based on the credit card
	 * @param ba this is the new billing address
	 */
	public void setBillingAddr(String ba){billingAddr = ba;}
	///////////////////////////////////////////////////////////////////
	
	/**
	 * Get the room charges based on what the customer have checkin from the XML 
	 * @param roomT This indicates the type of room that the customer have stayed
	 * @param withV This indicates whether the room have views
	 * @return The charges of the room
	 */
	public int getRoomCharge(String roomT, String withV)
	{
		int charge=0;
		
		if(roomT.equals("Single"))
		{
			charge = 155;
		}
		else if(roomT.equals("Double"))
		{
			charge = 255;
		}
		else if(roomT.equals("Deluxe"))
		{
			charge = 355;
		}
		else if(roomT.equals("VIPSuite"))
		{
			charge = 455;
		}
		
		if(withV.equals("Y"))
		{
			charge += 50;
		}
	
		return charge;
	}
	
/**
 * Print the bill when the customer checked out
 *  according to what type of room they have stayed in
 * @param r The walkin / reservation that is to be checkout
 * @param res Check whether it is a reservation or walk in
 * @param o The room service order that the customer has made
 */
	public void printBillInvoice(WalkIns r,boolean res, ArrayList<Order> o)
	{
		int poption =0;
		String promo ="" ;
		String name="";
		double rsPrice=0;
		double totalRoomc=0;
		int totaldays=0;
		int weekend=0;
		String sdate="";
		Date d2;
		boolean uname=false;

		
		Scanner sc = new Scanner(System.in);
		do{
			try {
				System.out.println("Payment by Cash or Credit card:");
				System.out.println("Please enter 0 for cash and 1 for credit card:");
				poption = sc.nextInt();
				if(poption==0 || poption==1)
				{
					
					if(poption ==1)
					{
						do
						{
							sc.nextLine();
							System.out.println("Enter name as per credit card:");
							name = sc.nextLine();
							
							if(name.matches("[a-zA-Z]+"))
							{
								uname = true;
								System.out.println("Enter Billing Address :");
								billingAddr = sc.nextLine();
							}
							else
							{
								System.out.println("Please only enter alphabets");
								
							}
							
						}while(uname!=true);
					}
					System.out.println("Promotion given(y/n): ");
					promo=sc.next();
					
				}
				else
				{
					System.out.println("Wrong option, please enter again.");
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				System.out.println("Wrong option, please enter again.");
			}
		}while(poption!=0 && poption!=1);
		
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm");
		   //get current date time with Date()
		  //get current date time with Calendar()
		 Date now = new Date();
		 System.out.println(dateFormat.format(now.getTime()));		
		
		 
		
			try {
				
				SimpleDateFormat format = new SimpleDateFormat("MM/dd/yy HH:mm");
				if(res)
				{
					Reservation a = (Reservation)r;
				sdate = r.getRoomStartDate() + " " + a.getCheckInTime();
				}
				else
					sdate = r.getRoomStartDate() + " 13:00";
				
				Date d1 = null;

					
				d1 = format.parse(sdate);


					//in milliseconds
				long diff = now.getTime() - d1.getTime();
				long diffDays = diff / (24 * 60 * 60 * 1000);
				
				totaldays= (int)diffDays;
				
				//find the no of weekends
				int dayofweek=0;
				Calendar c = Calendar.getInstance();
				d2 = format.parse(sdate);
				c.setTime(d2);
				for(int i=1;i<=totaldays;i++)
				{
					
					dayofweek = c.get(Calendar.DAY_OF_WEEK);
					if(dayofweek == 7 || dayofweek ==1)
					{
						weekend ++;
					}	
					c.add(Calendar.DATE,1);
				}
				
			} catch (ParseException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}  
			
			
	     
	     System.out.println("Guest name :" + r.getGuestName());
	     if(poption ==1)
	     {
	    	 System.out.println("Name as per credit card: "+ name);
	    	 long ccnum = Long.parseLong(r.getCreditCardNo());
	    	 ccnum=ccnum%10000;
	    	 System.out.println("Credit Card number: XXXXXXXXXXXX" + ccnum );
	    	 System.out.println("Billing Address: " + billingAddr);
	     }
	     System.out.println("====================================================");
	     System.out.println("Room details: ");
	     System.out.println("Room Number: "+ r.getRoomNo());
	     System.out.println("Room Type: " + r.getRoomType());
	     System.out.println("Bed Type: "+ r.getBedType());
	     System.out.println("Smoking: " + r.getSmoking());
	     System.out.println("Room with Wi-Fi: " + r.getRoomWifi());
	     System.out.println("Room with view: "+ r.getRoomView());
	     System.out.println();
	     System.out.println("====================================================");
	     System.out.println("Room service: ");
	     
	   //get the price of the room service
	     String rmno= r.getRoomNo();
	     String rmnos;
	     int counter=0;
	     try {
			for(int a=0;a<o.size();a++)
			 {
				 rmnos= o.get(a).getRoomNo();
				 if( rmnos.equals(rmno))
				 {
					 counter ++;
					 System.out.println(counter + ".) Items Ordered: " + o.get(a).getItem());
					 System.out.println("Time Ordered: " + o.get(a).getTotalPrice());
					 System.out.println();
					 rsPrice += Double.parseDouble(o.get(a).getTotalPrice());
						
				 }
			 }
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	     
	     
	     System.out.println("Total room service price: $" + String.format( "%.2f", rsPrice ));
	     System.out.println("====================================================");
	     
	     
	     double wecharge=0;
	     double wdcharge=0;
	     
	     // Print room charge 
	     System.out.println("Duration of stay: " +sdate + " - " + dateFormat.format(now.getTime()));
	     wdcharge = getRoomCharge(r.getRoomType(),r.getRoomView());
	     System.out.println("Room charges: $" + String.format( "%.2f", wdcharge ) + " per Night");
	     if(weekend>0)
	     {
		     wecharge = (extraCharge * wdcharge) + wdcharge;
	    	 System.out.println("Room charges for weekends (+5%): $" + String.format("%.2f",wecharge) + " per Night");
	    	 System.out.println("Total weekends stayed: " + weekend);
	     }
	     totalRoomc = ((totaldays-weekend)*wdcharge) + (weekend*wecharge);
	     System.out.println("Total days stayed: " + totaldays);
	     System.out.println("Total Room Charges: $" + String.format( "%.2f", totalRoomc ));
	     
	     //add in roomservice price
	     totalRoomc += rsPrice;
	     //check promo
	     if(promo.equals("y"))
	     {
	    	 System.out.println("Promotion: $" + String.format( "%.2f", totalRoomc*promotion ));
	    	 totalRoomc -= (totalRoomc*promotion);
	     } 
	     else 
	    	 System.out.println("Promotion: $0" );
	     
	     System.out.println("Service Charge(10%): $"+ String.format( "%.2f", totalRoomc*serviceCharge ));
	     totalRoomc += (totalRoomc*serviceCharge);
	     System.out.println("GST(7%): $" + String.format( "%.2f", (totalRoomc*gst)));
	     totalRoomc += (totalRoomc*gst);
	     System.out.println("Total Price: $"+ String.format( "%.2f", totalRoomc ));

	}
	
	
	/**
	 * generate report based on the percentage of 
	 * occupied rooms in a particular day for room occupancy report
	 * @param rm a whole array list of the rooms 
	 */
	public void generateReportOR(ArrayList<Room> rm)
	{
		int vs=0;//store the vacancy of single
		int ts=0;//store the total of single
		int vd=0;//store the vacancy of double
		int td=0;//store the total of double
		int vde=0;//store the vacancy of deluxe
		int tde=0;//store the total of deluxe
		int vVIP=0;//store the vacancy of VIP
		int tv=0;//store the total of VIP
		
		int rn=0;//store room no
		int runningno=0;//store running no
		String formatted;
		String formatted2;
		
		System.out.println("============================================");
		System.out.println("Statstic report by room type occupancy rate");
		System.out.println("============================================");
		
		//print out single room vacancy
		System.out.println("Single: ");
		System.out.print("Rooms: ");
		for(int i=0;i<rm.size();i++)
		{
			if(rm.get(i).getRoomType().equals("Single"))
			{
				ts++;
				if(rm.get(i).getAvailability().equals("Vacant"))
				{
					try{
						rn = Integer.parseInt(rm.get(i).getRoomNo());
						runningno = rn%100;//get last two digit of running no
						rn = rn/100;
						formatted = String.format("%02d", rn);
						formatted2 = String.format("%02d", runningno);
						System.out.print(formatted + "-"+ formatted2+" , ");
						vs++;
						
					}
					catch(NumberFormatException e)
					{
						e.printStackTrace();
						
					}
				}
			}
			
		}
		System.out.println("");
		System.out.println("Numbers: " +vs+ " out of "+ ts);
		System.out.println("============================================");
		
		//print out double room vacancy
		System.out.println("Double: ");
		System.out.print("Rooms: ");
		for(int i=0;i<rm.size();i++)
		{
			if(rm.get(i).getRoomType().equals("Double") )
			{
				td++;
				if(rm.get(i).getAvailability().equals("Vacant"))
				{
					
					try{
						rn = Integer.parseInt(rm.get(i).getRoomNo());
						runningno = rn%100;//get last two digit of running no
						rn = rn/100;
						formatted = String.format("%02d", rn);
						formatted2 = String.format("%02d", runningno);
						System.out.print(formatted + "-"+ formatted2+" , ");
						vd++;
						
					}
					catch(NumberFormatException e)
					{
						e.printStackTrace();
						
					}
				}
			}

		}
		System.out.println("");
		System.out.println("Numbers: " +vd+ " out of "+ td);
		System.out.println("============================================");
		
		//print out Deluxe room vacancy
		System.out.println("Deluxe: ");
		System.out.print("Rooms: ");
		for(int i=0;i<rm.size();i++)
		{
			if(rm.get(i).getRoomType().equals("Deluxe") )
			{
				tde++;
				if(rm.get(i).getAvailability().equals("Vacant"))
				{
					try{
						rn = Integer.parseInt(rm.get(i).getRoomNo());
						runningno = rn%100;//get last two digit of running no
						rn = rn/100;
						formatted = String.format("%02d", rn);
						formatted2 = String.format("%02d", runningno);
						System.out.print(formatted + "-"+ formatted2+" , ");
						vde++;
						
					}
					catch(NumberFormatException e)
					{
						e.printStackTrace();
						
					}
				}
			}
		}
		System.out.println("");
		System.out.println("Numbers: " +vde+ " out of "+ tde);
		System.out.println("============================================");
		
		//print out VIPSuite room vacancy
		System.out.println("VIPSuite: ");
		System.out.print("Rooms: ");
		for(int i=0;i<rm.size();i++)
		{
			if(rm.get(i).getRoomType().equals("VIPSuite") )
			{
				tv++;
				if(rm.get(i).getAvailability().equals("Vacant"))
				{
					try{
						rn = Integer.parseInt(rm.get(i).getRoomNo());
						runningno = rn%100;//get last two digit of running no
						rn = rn/100;
						formatted = String.format("%02d", rn);
						formatted2 = String.format("%02d", runningno);
						System.out.print(formatted + "-"+ formatted2+" , ");
						vVIP++;
								
					}
					catch(NumberFormatException e)
					{
						e.printStackTrace();
								
					}
				}
			}
		}
		System.out.println("");
		System.out.println("Numbers: " +vVIP+ " out of "+ tv);	
		System.out.println("============================================");
				
	}
	
	/**
	 * Generate report based on the room status
	 * @param rm a whole array list of the rooms 
	 */
	public void generateReportRS(ArrayList<Room> rm)
	{
		ArrayList <String> vacant = new ArrayList<String>();
		ArrayList <String> occupied = new ArrayList<String>();
		ArrayList <String> reserved = new ArrayList<String>();
		ArrayList <String> maintainance = new ArrayList<String>();
		String formatted ="";
		String formatted2 = "";
		
		int runningno=0;
		int rn=0;
		//Categorised the vacant and occupied
		System.out.println("===============================");
		System.out.println("Statstic report by room status");
		System.out.println("===============================");
		for(int i=0;i<rm.size();i++)
		{
			if(rm.get(i).getAvailability().equals("Vacant"))
			{
				//add the room no into vacant
				try{
					rn = Integer.parseInt(rm.get(i).getRoomNo());
					runningno = rn%100;//get last two digit of running no
					rn = rn/100;
					formatted = String.format("%02d", rn);
					formatted2 = String.format("%02d", runningno);
					vacant.add(formatted + "-"+ formatted2);
					
				}
				catch(NumberFormatException e)
				{
					e.printStackTrace();
					
				}
				
			}
			else if(rm.get(i).getAvailability().equals("Occupied"))
			{
				//add the room no into occupied
				try{
					rn = Integer.parseInt(rm.get(i).getRoomNo());
					runningno = rn%100;//get last two digit of running no
					rn = rn/100;
					formatted = String.format("%02d", rn);
					formatted2 = String.format("%02d", runningno);
					occupied.add(formatted + "-"+ formatted2);
					
				}
				catch(NumberFormatException e)
				{
					e.printStackTrace();
					
				}
			}
			else if(rm.get(i).getAvailability().equals("Reserved"))
			{
				//add the room no into reserved
				try{
					rn = Integer.parseInt(rm.get(i).getRoomNo());
					runningno = rn%100;//get last two digit of running no
					rn = rn/100;
					formatted = String.format("%02d", rn);
					formatted2 = String.format("%02d", runningno);
					reserved.add(formatted + "-"+ formatted2);
					
				}
				catch(NumberFormatException e)
				{
					e.printStackTrace();
					
				}
			}
			else 
			{
				//add the room no into under maintainance
				try{
					rn = Integer.parseInt(rm.get(i).getRoomNo());
					runningno = rn%100;//get last two digit of running no
					rn = rn/100;
					formatted = String.format("%02d", rn);
					formatted2 = String.format("%02d", runningno);
					maintainance.add(formatted + "-"+ formatted2);
					
				}
				catch(NumberFormatException e)
				{
					e.printStackTrace();
					
				}
			}
		}
		
		//print out vacant
		System.out.println("Vacant :");
		System.out.print("Rooms: ");
		for(int i=0;i<vacant.size();i++)
		{
			System.out.print(vacant.get(i));
			if((i+1)<vacant.size())
				System.out.print(" , ");

		}
		
		System.out.println("");
		System.out.println("===============================");
		
		//print out available
		System.out.println("Occupied:");
		System.out.print("Rooms: ");
		for(int i=0;i<occupied.size();i++)
		{
			System.out.print(occupied.get(i));
			if((i+1)<occupied.size())
				System.out.print(" , ");
				
		}
		System.out.println("");
		System.out.println("===============================");
		
		//print out reserved
		System.out.println("Reserved:");
		System.out.print("Rooms: ");
		for(int i=0;i<reserved.size();i++)
		{
			System.out.print(reserved.get(i));
			if((i+1)<reserved.size())
				System.out.print(" , ");
					
		}
		System.out.println("");
		System.out.println("===============================");
		
		//print out maintenance
		System.out.println("Maintenance:");
		System.out.print("Rooms: ");
		for(int i=0;i<maintainance.size();i++)
		{
			System.out.print(maintainance.get(i));
			if((i+1)<maintainance.size())
				System.out.print(" , ");
						
		}
		System.out.println("");
		System.out.println("===============================");
	}

}


