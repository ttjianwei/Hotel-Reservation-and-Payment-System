
/**
Represent a Guest in the System
A system can has many Guest
@author FSP4
@version 1.0
@since 2016-04-06
*/ 

public class Guest {

/**
* Name of guest
*/ 
 private String guestName;
 /**
 * Number on Credit Card
 */ 
 private String creditCardNo;
 /**
 * CSV code of Credit Card
 */ 
 private String creditCardCSV;
 /**
 * Expiry Date of Credit Card
 */ 
 private String creditCardExpDate;
 /**
 * Address of Guest
 */ 
 private String address;
 /**
 * Country of resident of guest
 */ 
 private String country;
 /**
 * Nationality of guest
 */ 
 private String nationality;
 /**
 * contact of guest
 */ 
 private String contact;
 /**
 * gender of guest
 */ 
 private String gender;
 /**
 * identity of guest, passport or NRIC
 */ 
 private String identity;

 /**
 * Constructor for Guest object, contains information of guest
 * @param Name Name of guest
 * @param guestAddress Address of guest
 * @param guestCountry Country of guest
 * @param guestNationality Nationality of guest
 * @param identity Unique identification of guest
 * @param gender Gender of guest 
 * @param contact Contact number of guest
 * @param creditCardCSV credit card's 3 digit CSV code
 * @param creditCardNo credit Card number
 * @param creditCardExpDate Card expiry date
 */

public Guest(String Name, String guestAddress,String guestCountry, String guestNationality
		,String identity,String gender,String contact, String creditCardNo,String creditCardCSV,
	 String creditCardExpDate){//constructor
	
	guestName = Name;
	address = guestAddress;
	country = guestCountry;
	nationality = guestNationality;
	this.identity = identity;
	this.gender = gender;
	this.contact = contact;
	this.creditCardCSV = creditCardCSV;
	this.creditCardNo = creditCardNo;
	this.creditCardExpDate = creditCardExpDate;
	
}
//getMethods
/**
* Method to get the name of guest
* @return guest's Name(String)
*/ 
public String getGuestName(){
	return guestName;
}
/**
* Method to get the credit card's number of guest
* @return credit card number(String)
*/ 
public String getCreditCardNo(){
	return creditCardNo;
}
/**
* Method to get the CSV code of credit card
* @return credit card's CSV code(String)
*/ 
public String getCreditCardCSV(){
	return creditCardCSV;
}
/**
* Method to get the expiry date of credit card
* @return credit card expiry date(String)
*/ 
public String getCreditCardExpDate(){
	return creditCardExpDate;
}
/**
* Method to get the address of Guest
* @return guest's Address(String)
*/ 
public String getAddress(){
	return address;
}
/**
* Method to get the country of Guest
* @return guest's country(String)
*/ 
public String getCountry(){
	return country;
}
/**
* Method to get the nationality of Guest
* @return guest's Nationality(String)
*/ 
public String getNationality(){
	return nationality;
}

/**
* Method to get the contacts of Guest
* @return guest's Contacts(String)
*/ 
public String getContact(){
	return contact;
}

/**
* Method to get the gender of Guest
* @return guest's gender(String)
*/ 
public String getGender(){
	return gender;
}

/**
* Method to get the unique Identity of Guest
* @return guest's unique identity(String)
*/ 
public String getIdentity(){
	return identity;
}
//end of get methods

//Set Methods, used for updating guest details
/**
* Method to set the address of Guest
* @param Name new name of guest
*/ 
public void setGuestName(String Name){
	guestName = Name;
}
/**
* Method to set the credit card number of Guest
* @param creditNo new credit card number of guest
*/ 
public void setCreditCardNo(String creditNo){
	creditCardNo = creditNo;
}
/**
* Method to set the credit card CSV code of Guest
* @param CSV new credit card CSV code
*/ 
public void setCreditCardCSV(String CSV){
	creditCardCSV = CSV;
}
/**
* Method to set the credit card expiry date of Guest
* @param expiryDate new credit card expiry date
*/ 
public void setCreditCardExpDate(String expiryDate){
	creditCardExpDate = expiryDate;
}
/**
* Method to set the address of Guest
* @param addr new guest address 
*/ 
public void setAddress(String addr){
	address = addr;
}
/**
* Method to set the country of Guest
* @param guestCountry new guest country
*/ 
public void setCountry(String guestCountry){
	country = guestCountry;
}
/**
* Method to set the Nationality of Guest
* @param guestNationality new guest nationality 
*/ 
public void setNationality(String guestNationality){
	nationality = guestNationality;
}
/**
* Method to set the contacts of Guest
* @param contactNo new guest contacts 
*/ 
public void setContact(String contactNo){
	contact = contactNo;
}
/**
* Method to set the gender of Guest
* @param guestGender new guest gender 
*/ 
public void setGender(String guestGender){
	gender = guestGender;
}
/**
* Method to set the identity of Guest
* @param identity new guest identity 
*/ 
public void setIdentity(String identity){
	this.identity = identity;
}
//end of set Methods

}