import java.text.SimpleDateFormat;
import java.util.*;
/**
 * Order Controller that control the order classes
 * @author FSP4 Group 5
 *
 */

public class OrderController {
	/**
	 * InputOutput to change things in XML
	 */
	InputOutput io = new InputOutput();

	/**
	 * Add in a order to Order ArrayList
	 * @param o ArrayList of Order 
	 * @param arOrders ArrayList of String that contains the food item and the price
	 * @param guestRemarks Guest remarks
	 * @param roomNo The room number of the order
	 */
	public void addOrder(ArrayList<Order> o,ArrayList<String> arOrders,String guestRemarks,String roomNo)
	{
		String foodItem = "";
		double foodTotalPrice = 0.0;
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/YY HH:mm:ss");
		
		
		for (int i = 0; i < arOrders.size(); i++) {
			if (i % 2 == 0) {
				foodItem = foodItem.concat(arOrders.get(i));
				foodItem = foodItem.concat(",");
			}
		}
		for (int i = 0; i < arOrders.size(); i++) {
			if (i % 2 == 1) {
				foodTotalPrice += Double.parseDouble(arOrders.get(i));
			}
		}
		
		String tp = String.valueOf(foodTotalPrice);
		String status = "Comfirmed";
		String time = sdf.format(cal.getTime());
		
		Order orders = new Order(roomNo, foodItem,tp, status,time,guestRemarks);
		o.add(orders);
	
	}
/**
 * Remove any room service order 	
 * @param o ArrayList of Order
 * @param rn Room number of the order to be removed
 */
	public void removeOrder(ArrayList<Order> o,String rn)
	{
		//remove from arraylist
		for(int i=0;i<o.size();i++)
		{
			if(o.get(i).getRoomNo().equals(rn))
			{
				o.remove(i);
			}
		}
		
		//remove from XML
		io.removeRoomServiceItemXML(rn);
	}
}
