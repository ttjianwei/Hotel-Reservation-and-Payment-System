import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
Represent a guest menu which mainly handles the control of guest object
@author FSP4
@version 1.0
@since 2016-04-06
*/ 

public class GuestMenu {
	/**
	 * Scanner object used to read user Input
	 */
	Scanner sc = new Scanner(System.in);
	
	/**
	 * method to update guest details 
	 * @param position position of guest in the file
	 * @param guestList list of guests that is already in the system
	 */
	public void updateGuestList(int position, ArrayList<Guest> guestList) {
		String name = "";
		String country = "";
		String gender = "";
		String nationality = "";
		String contact = "";
		String creditCardNo = "";
		String creditCardCSV = "";
		String creditCardExpDate = "";
		String identity = "";
		
		boolean uProceedName = false;
		boolean uProceedCountry = false;
		boolean uProceedGender = false;
		boolean uProceedNationality = false;
		boolean uProceedCN = false;
		boolean uProceedCC16 = false;
		boolean uProceedCSV = false;
		boolean uProceedCCExpiry = false;
		boolean uProceedNRIC = false;
		
		try {
 
			String filepath = "guestList.xml";
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(filepath);
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(new File(filepath));
			Node nodes = doc.getElementsByTagName("Guest").item(position);
			NodeList list = nodes.getChildNodes();

			System.out.println("1.)Update Name:\n2.)Update Address:\n3.)"
					+ "Update Country:\n4.)Update Gender:\n5.)Update Contact:\n"
					+ "6.)Update Nationality:\n7.)Update Credit card number:\n"
					+ "8.)Update Credit card CSV code:\n9.)Update Credit card expiry date:\n"
					+ "10.)Update Identification No:\n0.)Previous Menu");

			int userInput = sc.nextInt();
			sc.nextLine();

			switch (userInput) {
			case 1:// allow User to update name
				while(uProceedName != true){
				System.out.println("1.)Enter new Name:");
				name = sc.nextLine();

				if(!name.matches(".*\\d.*"))
				{
					uProceedName = true;
					for (int i = 0; i != list.getLength(); ++i) {
						Node child = list.item(i);

						if (child.getNodeName().equals("name")) {

							child.getFirstChild().setNodeValue(name);

						}
					}
					transformer.transform(source, result); // write to file
					guestList.get(position).setGuestName(name);// make changes to arrayList
					break;
				}
				else
					System.out.println("Error input. Please enter only alphabets for name.");
				}break;
			case 2:
				System.out.println("2.)Enter new Address:");
				String address = sc.nextLine();

				for (int i = 0; i != list.getLength(); ++i) {
					Node child = list.item(i);

					if (child.getNodeName().equals("address")) {

						child.getFirstChild().setNodeValue(address);
					}
				}
				transformer.transform(source, result);
				guestList.get(position).setAddress(address);
				break;
			case 3:
				while(uProceedCountry != true){
				System.out.println("3.)Enter new Country:");
				country = sc.nextLine();
				
				if(!country.matches(".*\\d.*"))
				{
					uProceedCountry = true;
					for (int i = 0; i != list.getLength(); ++i) {
						Node child = list.item(i);
						if (child.getNodeName().equals("country")) {
							child.getFirstChild().setNodeValue(country);
						}

					}
					transformer.transform(source, result);
					guestList.get(position).setCountry(country);
					break;
				}
				else
					System.out.println("Error input! Please enter only alphabets for country.");
				}break;
				
			case 4:
				while(uProceedGender != true){
				System.out.println("4.)Enter new Gender:");
				gender = sc.nextLine();

				if(gender.equals("M") || gender.equals("F"))
				{
					uProceedGender = true;
					for (int i = 0; i != list.getLength(); ++i) {
						Node child = list.item(i);
						if (child.getNodeName().equals("gender")) {
							child.getFirstChild().setNodeValue(gender);
						}

					}
					transformer.transform(source, result);
					guestList.get(position).setGender(gender);
					break;
				}
				else
					System.out.println("Error input! Please only key M or F for gender. ");
				}break;
			case 5:
				while(uProceedNationality != true){
				System.out.println("5.)Enter new nationality:");
				nationality = sc.nextLine();

				if(!nationality.matches(".*\\d.*"))
				{
					uProceedNationality = true;
					for (int i = 0; i != list.getLength(); ++i) {
						Node child = list.item(i);
						if (child.getNodeName().equals("nationality")) {
							child.getFirstChild().setNodeValue(nationality);
						}

					}
					transformer.transform(source, result);
					guestList.get(position).setNationality(nationality);
					break;
				}
				else
					System.out.println("Error input! Please only enter alphabets for nationality.");
				}break;
			case 6:
				while(uProceedCN != true){
				System.out.println("6.)Enter new Contact.(8 digits):");
				contact = sc.nextLine();

				if(contact.length() == 8 && contact.matches("\\d+"))
				{
					uProceedCN = true;
					for (int i = 0; i != list.getLength(); ++i) {
						Node child = list.item(i);
						if (child.getNodeName().equals("contact")) {
							child.getFirstChild().setNodeValue(contact);
						}

					}
					transformer.transform(source, result);
					guestList.get(position).setContact(contact);
					break;
				
				}
				else
					System.out.println("Error input! Please only enter 8 numbers.");
				}break;
			case 7:
				while(uProceedCC16 != true){
				System.out.println("7.)Enter new Credit card number.(16 digits):");
				creditCardNo = sc.nextLine();
				
				if(creditCardNo.length() == 16 && creditCardNo.matches("\\d+"))
				{
					uProceedCC16 = true;
					for (int i = 0; i != list.getLength(); ++i) {
						Node child = list.item(i);
						if (child.getNodeName().equals("creditCardNo")) {
							child.getFirstChild().setNodeValue(creditCardNo);
						}

					}
					transformer.transform(source, result);
					guestList.get(position).setCreditCardNo(creditCardNo);
					break;

				}
				else
					System.out.println("Error input! Please only enter 16 numbers.");
				}break;
			case 8:
				while(uProceedCSV != true){
				System.out.println("8.)Enter new Credit card CSV code.(3 digits):");
				creditCardCSV = sc.nextLine();
				
				if(creditCardCSV.length() == 3 && creditCardCSV.matches("\\d+"))
				{
					uProceedCSV = true;
					for (int i = 0; i != list.getLength(); ++i) {
						Node child = list.item(i);
						if (child.getNodeName().equals("creditCardCSV")) {
							child.getFirstChild().setNodeValue(creditCardCSV);
						}

					}
					transformer.transform(source, result);
					guestList.get(position).setCreditCardNo(creditCardCSV);
					break;
				
				}
				else
					System.out.println("Error input! Please only enter 3 numbers.");
				}break;
			case 9:
				while(uProceedCCExpiry != true){
				System.out.println("9.)Enter new Credit card expiry date(MM/YY):");
				creditCardExpDate = sc.nextLine();
				
				if(creditCardExpDate.length() == 5)
				{
					String[] ccExpiryDateArr = creditCardExpDate.split("", 5);
		        	
		        	String mm = ccExpiryDateArr[0] + ccExpiryDateArr[1];
		        	int mmInt = Integer.parseInt(mm);
		        	
		        	String yy = ccExpiryDateArr[3] + ccExpiryDateArr[4];
		        	int yyInt = Integer.parseInt(yy);
		        	
		        	if((mmInt >= 1 && mmInt <= 12) && (yyInt > 0) && (ccExpiryDateArr[2].equals("/")))
		        	{
		        		uProceedCCExpiry = true;
		        		for (int i = 0; i != list.getLength(); ++i) {
							Node child = list.item(i);
							if (child.getNodeName().equals("creditCardExpDate")) {
								child.getFirstChild().setNodeValue(creditCardExpDate);
							}

						}
						transformer.transform(source, result);
						guestList.get(position).setCreditCardNo(creditCardExpDate);
						break;
		        	}
		        	else
		        		System.out.println("Error input! Please enter a valid Credit Card Expiry Date(MM/YY).");
				}
				else
					System.out.println("Error input! Please enter a valid Credit Card Expiry Date(MM/YY).");
				}break;
			case 10:
				
				
				while(uProceedNRIC != true){
				System.out.println("10.)Enter new Identification No(eg. S1234567A):");
				identity = sc.nextLine();
				
				if(identity.length() == 9)
				{
					String[] identityArr = identity.split("",9);
					String firstAlpha = identityArr[0];
					String middleNumbers = identityArr[1] + identityArr[2] + identityArr[3] + identityArr[4] + identityArr[5] + identityArr[6] + identityArr[7];
					String lastAlpha = identityArr[8];
					
					if(!firstAlpha.matches(".*\\d.*")) //if first character is not number
					{
						if(middleNumbers.matches(".*\\d.*")) //if 2nd character to 8th character are numbers
						{
							if(!lastAlpha.matches(".*\\d.*")) //if last character is not number
							{
								uProceedNRIC = true;
								for (int i = 0; i != list.getLength(); ++i) {
									Node child = list.item(i);
									if (child.getNodeName().equals("identity")) {
										child.getFirstChild().setNodeValue(identity);
									}
								}
								transformer.transform(source, result);
								guestList.get(position).setIdentity(identity);

								break;
							}
							else
								System.out.println("Please enter an alphabet for the last character for the Identity(Passport or Driving License eg. S1234567A).");
						}
						System.out.println("Please enter only numbers from the second character to eighth character for the Identity(Passport or Driving License eg. S1234567A).");
					}
					else
						System.out.println("Please enter an alphabet for the first character for the Identity(Passport or Driving License eg. S1234567A).");
						
				}
				else
					System.out.println("Please enter a valid Identity(Passport or Driving License eg. S1234567A).");
				
				}break;
			case 0:
				break;

			}

		}

		catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	/**
	 * method to display guest details 
	 * @param position position of guest in the file
	 * @param guestList list of guests that is already in the system
	 */
	public void displayGuest(int position,ArrayList<Guest> guestList){
		
		System.out.println("Name :" + guestList.get(position).getGuestName());
		System.out.println("Address :" + guestList.get(position).getAddress());
		System.out.println("Country : " + guestList.get(position).getCountry());
		System.out.println("Gender: " + guestList.get(position).getGender());
		System.out.println("Nationality : " + guestList.get(position).getNationality());
		System.out.println("Contact : " + guestList.get(position).getContact());
		System.out.println("Credit Card No. : " + guestList.get(position).getCreditCardNo());
		System.out.println("Credit Card CSV : " + guestList.get(position).getCreditCardCSV());
		System.out.println("Credit Card Expiry Date : " + guestList.get(position).getCreditCardExpDate());
		System.out.println("Identity(passport/driving license) : " + guestList.get(position).getIdentity());
		System.out.println();
		
		
	}
	/**
	 * method to search for position of guest in the system
	 * @param size size of the array list
	 * @param guestList list of guests that is already in the system
	 * @return count guest position in guest list
	 */
	public int searchForGuest(int size,ArrayList<Guest> guestList){ //search by unique identification number
		System.out.println("Enter your ID(Passport or driver license): ");
		String id = sc.next();
		int flag = validateGuestInSystem(id,guestList);
		while (flag != 1) {
			System.out.println("Guest Identity does not exist in system ! ");
			System.out.println("Please re-enter your ID(Passport or driver license) :");
			id = sc.next();
			flag = validateGuestInSystem(id,guestList);	
		}
		int count =0;
		for(int i=0;i<guestList.size();i++){
			if( guestList.get(i).getIdentity().equals(id)){
				count =i;
				
			}
		}
		
		return count;
		
	}
	
	/**
	 * method to display guest details 
	 * @return gst current instance of guest details
	 * @param guestList Collection of guest objects in the system
	 */
	public Guest createGuestDetails(ArrayList<Guest> guestList){
		
		Scanner sc1 = new Scanner(System.in);
		
		String name = "";
		String country = "";
		String gender = "";
		String nationality = "";
		String contact = "";
		String creditCardNo = "";
		String creditCardCSV = "";
		String creditCardExpDate = "";
		String identity = "";
		
		boolean proceedName = false;
		boolean proceedCountry = false;
		boolean proceedGender = false;
		boolean proceedNationality = false;
		boolean proceedCN = false;
		boolean proceedCC16 = false;
		boolean proceedCSV = false;
		boolean proceedCCExpiry = false;
		boolean proceedNRIC = false;
		
		
		//start validation for GuestName
		while(proceedName != true){
		System.out.println("Enter Name:");
		name = sc1.nextLine();
		
		if(name.matches(".*\\d.*")) //if name is keyed with numbers, .*\\d.* means contains a number
		{
			System.out.println("Error input! Please enter only alphabets for name.");
		}
		else
			proceedName = true;
		}
		//end validation for GuestName
		
		System.out.println("Enter Address:");
		String address =sc1.nextLine();
		
		//start validation for country
		while(proceedCountry != true){
		System.out.println("Enter Country:");
		country = sc1.nextLine();
		
		if(!country.matches(".*\\d.*")) //if country is keyed with numbers, .*\\d.* means contains a number
		{
			proceedCountry = true;
		}
		else
			System.out.println("Error input! Please enter only alphabets for country.");
		}
		//end validation for country
		
		//start validation for gender
		while(proceedGender != true){
		System.out.println("Enter Gender(M/F):");
		gender = sc1.nextLine();
		
		if(gender.equals("M") || gender.equals("F"))
		{
			proceedGender = true;
		}
		else
			System.out.println("Error input! Please only key M or F for gender.");
		}
		//end validation for gender
		
		//start validation for nationality
		while(proceedNationality != true){
		System.out.println("Enter Nationality:");
		nationality = sc1.nextLine();
		
		if(!nationality.matches(".*\\d.*"))
		{
			proceedNationality = true;
		}
		else
			System.out.println("Error input! Please enter only alphabets for nationality.");
		}
		//end validation for nationality
		//start validation for contact no
		while(proceedCN != true){
		System.out.println("Enter Contact No.(8 digits):");
		contact = sc1.nextLine();
		
		if(contact.length() == 8 && contact.matches("\\d+"))//contact is 8 numbers, \\d+ means only numbers
		{
			proceedCN = true;
		}
		else
			System.out.println("Error input! Please only enter 8 numbers.");
		}
		//end validation for contact no
		
		//start validation for CC 16 digits
		while(proceedCC16 != true){
		System.out.println("Enter Credit Card No.(16 digits):");
		creditCardNo = sc1.nextLine();
		
		if(creditCardNo.length() == 16 && creditCardNo.matches("\\d+"))//creditCardNo is 16 numbers, \\d+ means only numbers
		{
			proceedCC16 = true;
		}
		else
			System.out.println("Error input! Please only enter 16 numbers.");
		}
		//end validation for CC 16 digits
		
		//start validation for CC CSV
		while(proceedCSV != true){
		System.out.println("Enter Credit Card CSV.(3 digits):");
		creditCardCSV = sc1.nextLine();
		
		if(creditCardCSV.length() == 3 && creditCardCSV.matches("\\d+"))//creditCardCSV is 3 numbers, \\d+ means only numbers
		{
			proceedCSV = true;
		}
		else
			System.out.println("Error input! Please only enter 3 numbers.");
		}
		//end validation for CC CSV
		
		//start validation for CC Expiry Date 
		while(proceedCCExpiry != true){
		System.out.println("Enter Credit Card Expiry Date(MM/YY):");
		creditCardExpDate = sc1.nextLine();
		
		if(creditCardExpDate.length() == 5)
		{
			String[] ccExpiryDateArr = creditCardExpDate.split("", 5);
        	
        	String mm = ccExpiryDateArr[0] + ccExpiryDateArr[1];
        	int mmInt = Integer.parseInt(mm);
        	
        	String yy = ccExpiryDateArr[3] + ccExpiryDateArr[4];
        	int yyInt = Integer.parseInt(yy);
        	
        	if((mmInt >= 1 && mmInt <= 12) && (yyInt > 0) && (ccExpiryDateArr[2].equals("/")))
        	{
        		proceedCCExpiry = true;
        	}
        	else
        		System.out.println("Error input! Please enter a valid Credit Card Expiry Date(MM/YY).");
		}
		else
			System.out.println("Error input! Please enter a valid Credit Card Expiry Date(MM/YY).");
		}
		//end validation for CC Expiry Date
		
		
		//start validation for NRIC
		while(proceedNRIC != true){
		System.out.println("Enter Identity(Passport or Driving License eg. S1234567A)");
		identity = sc1.next();
		int flag = validateGuestInSystem(identity,guestList);
		while (flag == 1) {
			System.out.println("Guest Identity already exist in system ! ");
			System.out.println("Please re-enter your ID(Passport or driver license) :");
			identity = sc.next();
			flag = validateGuestInSystem(identity,guestList);	
		}
		
		
		
		
		if(identity.length() == 9)
		{
			String[] identityArr = identity.split("",9);
			String firstAlpha = identityArr[0];
			String middleNumbers = identityArr[1] + identityArr[2] + identityArr[3] + identityArr[4] + identityArr[5] + identityArr[6] + identityArr[7];
			String lastAlpha = identityArr[8];
			
			if(!firstAlpha.matches(".*\\d.*")) //if first character is not number
			{
				if(middleNumbers.matches(".*\\d.*")) //if 2nd character to 8th character are numbers
				{
					if(!lastAlpha.matches(".*\\d.*")) //if last character is not number
					{
						proceedNRIC = true;
					}
					else
						System.out.println("Please enter an alphabet for the last character for the Identity(Passport or Driving License eg. S1234567A).");
				}
				else{
				System.out.println("Please enter only numbers from the second character to eighth character for the Identity(Passport or Driving License eg. S1234567A).");
			System.out.println(middleNumbers);
				}
				}
			else
				System.out.println("Please enter an alphabet for the first character for the Identity(Passport or Driving License eg. S1234567A).");
				
		}
		else
			System.out.println("Please enter a valid Identity(Passport or Driving License eg. S1234567A).");
		
			
		}
		//end validation for NRIC
		
		Guest gst = new Guest(name,address,country,nationality,identity,gender,contact,creditCardNo,creditCardCSV,creditCardExpDate);
		
		return gst;
	}
	
	/**
	 * validate current guest ID if it 
	 * @param guestID guest unique identification number
	 * @param guest Guest object details in system
	 * @return flag 1 to represent room number exist, return -1 if room number doesn't exist in system
	 */
	public int validateGuestInSystem(String guestID,ArrayList<Guest> guest) {
		int flag = -1;

		for(int i=0;i<guest.size();i++){
			if(guestID.equals(guest.get(i).getIdentity())){
			flag = 1;//guest exist
			}
		}
		return flag;
}
}
