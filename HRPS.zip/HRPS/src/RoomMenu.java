import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
Represent a room menu in the system
Mainly control the logic of how rooms are being handled
@author FSP4
@version 1.0
@since 2016-04-06
*/ 
public class RoomMenu {
	Scanner sc = new Scanner(System.in);
	
	
	/**
	* Method to create room details
	* @return instance of room created
	* @param room Collection of Room objects in the system
	*/ 
	public Room createRoomDetails(ArrayList<Room> room) {

		String roomType="";
		String bedType="";
		String wifi="";
		String roomView="";
		String smoking="";
		String roomNo ="";
		int inputRoomType = 0,inputBedType = 0;
		boolean proceedRmNo = false;
	    boolean proceedRmType = false;
	    boolean proceedBedType = false;
	    boolean proceedWifi = false;
	    boolean proceedRmView = false;
	    boolean proceedSmoking = false;
	    
		//start validation of room type
	    while(proceedRmNo != true){
	        System.out.println("Enter Room number(Floor-unit e.g 02-01 = 0201)");
	        roomNo = sc.next();
	        int flag = validateRoomNo(roomNo,room);
			while (flag == 1) {
				System.out.println("Room already exist in system ! ");
				System.out.println("Please re-enter your room number!(floor number between 02 to 08 and unit number between 01 to 08.)");
				;
				roomNo = sc.next();
				flag = validateRoomNo(roomNo,room);	
			}
	        
	        
	        
	        if(roomNo.length() == 4)
	        {
	             
	            String[] arrayRm = roomNo.split("", 4);
	            String floorNo = arrayRm[0] + arrayRm[1];
	            int floorNoInt = Integer.parseInt(floorNo);
	             
	            String unitNo = arrayRm[2] + arrayRm[3];
	            int unitNoInt = Integer.parseInt(unitNo);
	             
	            if(floorNoInt >= 2 && floorNoInt <= 7)
	            {
	                if(unitNoInt >= 1 && unitNoInt <= 8)
	                    proceedRmNo = true;
	            }
    
	            } 
	        if(proceedRmNo==false)
	        System.out.println("Incorrect input! Please enter a floor number between 02 to 08 and unit number between 01 to 08.");
	        }
	        //end validation of room number
         
	  //start validation of room type
        while(proceedRmType != true){
        System.out.println("Choose the room type \n1.Single\n2.Double\n3.Deluxe\n4.VIP Suite ");
        inputRoomType = sc.nextInt();
        sc.nextLine();
        if(inputRoomType >= 1 && inputRoomType <= 4){
            proceedRmType = true;
            }
        else
            System.out.println("Incorrect input! Please select an option between (1) to (4).");
        }
        //end validation of room type
        
		//start validation of bed type
        while(proceedBedType != true){
            System.out.println("Choose the bed type \n1.Single\n2.Double\n3.Master ");
            inputBedType = sc.nextInt();
            sc.nextLine();
            if(inputBedType >= 1 && inputBedType <= 3){
                proceedBedType = true;
                }
            else
                System.out.println("Incorrect input! Please select an option between (1) to (3).");
            }
		//end validation of bed type
 
      //start validation of wifi enabling
        while(proceedWifi != true){
        System.out.println("Enter (Y/N) for WIFI enabling: ");
        wifi = sc.next();
        if(wifi.equals("Y")|| wifi.equals("N"))
            proceedWifi = true;
        else
            System.out.println("Error Input! Please only enter (Y/N) for Wifi enabling.");
        }
        //end validation of wifi enabling
		
        //start validation of room view
        while(proceedRmView != true){
        System.out.println("Enter (Y/N) for room facing with view: ");
        roomView = sc.next();
        if(roomView.equals("Y") || roomView.equals("N"))
            proceedRmView = true;
        else
            System.out.println("Error Input! Please only enter (Y/N) for room facing with view.");
        }
        //end validation of room view
      //start validation of smoking-friendly room
        while(proceedSmoking != true){
        System.out.println("Smoking-friendly room (Y/N): ");
        smoking = sc.next();
        if(smoking.equals("Y") || smoking.equals("N"))
            proceedSmoking = true;
        else
            System.out.println("Error Input! Please only enter (Y/N) for Smoking-friendly room.");
        }
        //end validation of smoking-friendly room
        
        
		switch(inputRoomType){
		case 1: roomType = "Single";break;
		case 2: roomType = "Double";break;
		case 3: roomType = "Deluxe";break;
		case 4: roomType = "VIPSuite";break;
		}
		switch(inputBedType){
		case 1: bedType = "Single";break;
		case 2: bedType = "Double";break;
		case 3: bedType = "Master";break;
		}
		Room tmpRoom = new Room(roomType,bedType,roomNo,smoking,"00/00/00","00/00/00",wifi,roomView,"Vacant","N");
		return tmpRoom;
		
	}
	
	
	/**
	* Method to search for position of room in the system
	* @param size total numbers of room in the system
	* @param room Collection of room object that exist in the system
	* @return room returns room position in system
	*/ 
	public int searchForRoom(int size,ArrayList<Room> room){ //search by unique identification number
		System.out.println("Enter room number: ");
		String roomNo = sc.next();
		int flag = validateRoomNo(roomNo,room);
		while (flag != 1) {
			System.out.println("Room Number does not exist in system ! ");
			System.out.println("Please re-enter your room number! :");
			roomNo = sc.next();
			flag = validateRoomNo(roomNo,room);	
		}
		int count =0;
		for(int i=0;i<room.size();i++){
			if( room.get(i).getRoomNo().equals(roomNo)){
				count =i;
				
			}
		}
		
		return count;
		
	}
	/**
	* Method to search for position of room in the system
	* @param size total numbers of room in the system
	* @param room Collection of room object that exist in the system
	* @param roomNo number of room to be searched
	* @return count position of room in system
	*/ 
	public int searchForRoom(int size,ArrayList<Room> room,String roomNo){ //search by unique identification number
		
		int count =0;
		for(int i=0;i<room.size();i++){
			if( room.get(i).getRoomNo().equals(roomNo)){
				count =i;
				
			}
		}
		
		return count;
		
	}
	
	/**
	* Method to update room's date and availability
	* @param position position of room to be update
	* @param startDate start date of room
	* @param endDate end date of room
	* @param availability current room's availability
	*/ 
	public void updateRoomDatesAndAvailabilityInFile(int position,String startDate,String endDate,String availability){
		try{
		String filepath = "roomList.xml";
		DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
		Document doc = docBuilder.parse(filepath);
		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		DOMSource source = new DOMSource(doc);
		StreamResult result = new StreamResult(new File(filepath));
		Node nodes = doc.getElementsByTagName("room").item(position);
		NodeList list = nodes.getChildNodes();
		
		for (int i = 0; i != list.getLength(); ++i) {
			Node child = list.item(i);

			if (child.getNodeName().equals("startDate")) {

				child.getFirstChild().setNodeValue(startDate);

			}
			
			if (child.getNodeName().equals("endDate")) {

				child.getFirstChild().setNodeValue(endDate);

			}
			if (child.getNodeName().equals("availability")) {

				child.getFirstChild().setNodeValue(availability);
				
			}
			
			
			
		}
		transformer.transform(source, result); // write to file
		}
		catch(Exception e){
			
		}
		
		
		
	}
	
	/**
	* Method to update room details
	* @param position total numbers of room in the system
	* @param room Collection of room object that exist in the system
	*/ 
	public void updateRoomList(int position, ArrayList<Room> room) {
		
		int roomTypeInput = 0, bedInputType = 0, available = 0;
    	String startDate = "";
    	String ucopySD = "";
    	String endDate = "";
    	String wifi = "";
    	String roomView = "";
    	String smoking = "";
    	
    	//for updateRoomList validation purposes
        //boolean uProceedSelection = false;
        boolean uProceedRmType = false;
        boolean uProceedBedType = false;
        boolean uProceedStartDate = false;
        boolean uProceedEndDate = false;
        boolean uProceedWifi = false;
        boolean uProceedRmView = false;
        boolean uProceedSmoking = false;
        boolean uProceedAvail = false;
         
    	
    	try {
  
            String filepath = "roomList.xml";
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
            Document doc = docBuilder.parse(filepath);
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File(filepath));
            Node nodes = doc.getElementsByTagName("room").item(position);
            NodeList list = nodes.getChildNodes();
 
            System.out.println("1.)Update Room Type:\n2.)Update bed Type:\n3.)"
                    + "Update start date of stay:\n4.)Update end date of stay:\n5.)Update Wifi preference:\n"
                    + "6.)Update room view preference:\n7.)Update smoking preference:\n8.)Update room availability\n0.)Exit");
 
            int userInput = sc.nextInt();
             
            sc.nextLine();
            
            switch (userInput) {
            case 1:// allow User to update roomtype
            	
            	while(uProceedRmType != true){
                System.out.println("Choose the room type \n1.Single\n2.Double\n3.Deluxe\n4.VIP Suite ");
                roomTypeInput = sc.nextInt();
                sc.nextLine();
                if(roomTypeInput >= 1 && roomTypeInput <= 4){
                	
                	uProceedRmType = true;
                	String roomType="";
                    switch(roomTypeInput){
                    case 1: roomType = "Single";break;
                    case 2: roomType = "Double";break;
                    case 3: roomType = "Deluxe";break;
                    case 4: roomType = "VIPSuite";break;
                    }
                    for (int i = 0; i != list.getLength(); ++i) {
                        Node child = list.item(i);
     
                        if (child.getNodeName().equals("roomType")) {
     
                            child.getFirstChild().setNodeValue(roomType);
     
                        }
                    }
                    transformer.transform(source, result); // write to file
                    room.get(position).setRoomType(roomType);// make changes to arrayList
                    break;
                	}
                else
                	System.out.println("Incorrect input! Please select an option between (1) to (4).");
            	}break;
                
            case 2:
            	while(uProceedBedType != true){
                System.out.println("Choose the bed type \n1.Single\n2.Double\n3.Master ");
                bedInputType = sc.nextInt();
                sc.nextLine();
                
                if(bedInputType >= 1 && bedInputType <= 3){
                	
                	uProceedBedType = true;
                	String bedType="";
                    switch(bedInputType){
                    case 1: bedType = "Single";break;
                    case 2: bedType = "Double";break;
                    case 3: bedType = "Master";break;
                    }
                    for (int i = 0; i != list.getLength(); ++i) {
                        Node child = list.item(i);
     
                        if (child.getNodeName().equals("bedType")) {
     
                            child.getFirstChild().setNodeValue(bedType);
                        }
                    }
                    transformer.transform(source, result);
                    room.get(position).setBedType(bedType);
                    
                	
                }
                else
                	System.out.println("Incorrect input! Please select an option between (1) to (3).");
            	}break;
            case 3:
            	while(uProceedStartDate != true){
                System.out.println("Enter the start date of stay(MM/DD/YY): ");
                startDate = sc.nextLine();
 
                if(startDate.length() == 8)
                {
                	String[] arraySDu = startDate.split("", 8);
                	
                	String umm = arraySDu[0] + arraySDu[1];
                	int ummInt = Integer.parseInt(umm);
					
					String udd = arraySDu[3] + arraySDu[4];
                	int uddInt = Integer.parseInt(udd);
                	
                	String uyy = arraySDu[6] + arraySDu[7];
                	int uyyInt = Integer.parseInt(uyy);
                	int uleapYear = uyyInt%4;
                	
                	//making sure there is a valid start date entered given the right mm/dd/yy
                	if(((uddInt >= 1 && uddInt <= 31) && (ummInt == 1 || ummInt == 3 || ummInt == 5 || ummInt == 7 || ummInt == 8 || ummInt == 10 || ummInt == 12) && (uyyInt > 0) && (arraySDu[2].equals("/")) && (arraySDu[5].equals("/")))
                			|| ((uddInt >= 1 && uddInt <= 30) && (ummInt == 4 || ummInt == 6 || ummInt == 9 || ummInt == 11) && (uyyInt > 0) && (arraySDu[2].equals("/")) && (arraySDu[5].equals("/")))
                			|| ((uddInt >= 1 && uddInt <=29) && (ummInt == 2) && (uleapYear == 0 && uyyInt > 0) && (arraySDu[2].equals("/")) && (arraySDu[5].equals("/")))
                			|| ((uddInt >= 1 && uddInt <=28) && (ummInt == 2) && (uyyInt > 0) && (arraySDu[2].equals("/")) && (arraySDu[5].equals("/"))))
                	{
                		uProceedStartDate = true;
                		for (int i = 0; i != list.getLength(); ++i) {
                            Node child = list.item(i);
                            if (child.getNodeName().equals("startDate")) {
                                child.getFirstChild().setNodeValue(startDate);
                            }
         
                        }
                        transformer.transform(source, result);
                        room.get(position).setStartDate(startDate);;
                        break;
                	}
                	else
                		System.out.println("Error Input! Please enter a valid start date.");
                }
                else
                	System.out.println("Error Input! Please enter a valid length of start date.");
            	}
            	ucopySD = startDate;
            case 4:
            	while(uProceedEndDate != true){
                System.out.println("Enter the end date of stay(MM/DD/YY): ");
                endDate = sc.nextLine();
 
                if(endDate.length() == 8)
                {
                	//copy startdate
                	String[] arraySDcopyu = ucopySD.split("", 8);
                	
                	String uSmm = arraySDcopyu[0] + arraySDcopyu[1];
                	int uSmmInt = Integer.parseInt(uSmm);
					
                	String uSdd = arraySDcopyu[3] + arraySDcopyu[4];
                	int uSddInt = Integer.parseInt(uSdd);
                	
                	String uSyy = arraySDcopyu[6] + arraySDcopyu[7];
                	int uSyyInt = Integer.parseInt(uSyy);
                	
                	//enddate
                	String[] arrayEDu = endDate.split("", 8);
                	
                	String uEmm = arrayEDu[0] + arrayEDu[1];
                	int uEmmInt = Integer.parseInt(uEmm);
                	
                	String uEdd = arrayEDu[3] + arrayEDu[4];
                	int uEddInt = Integer.parseInt(uEdd);
					
                	String uEyy = arrayEDu[6] + arrayEDu[7];
                	int uEyyInt = Integer.parseInt(uEyy);
                	int uEleapYear = uEyyInt%4;
                	
                	//making sure end date is older than start date
                	if((uEyyInt > uSyyInt) || (uEyyInt >= uSyyInt && uEmmInt > uSmmInt) || (uEyyInt >= uSyyInt && uEmmInt >= uSmmInt && uEddInt > uSddInt))
                	{
                	
                		//making sure there is a valid end date entered given the right mm/dd/yy
                	if(((uEddInt >= 1 && uEddInt <= 31) && (uEmmInt == 1 || uEmmInt == 3 || uEmmInt == 5 || uEmmInt == 7 || uEmmInt == 8 || uEmmInt == 10 || uEmmInt == 12) && (uEyyInt > 0) && (arrayEDu[2].equals("/")) && (arrayEDu[5].equals("/")))
                			|| ((uEddInt >= 1 && uEddInt <= 30) && (uEmmInt == 4 || uEmmInt == 6 || uEmmInt == 9 || uEmmInt == 11) && (uEyyInt > 0) && (arrayEDu[2].equals("/")) && (arrayEDu[5].equals("/")))
                			|| ((uEddInt >= 1 && uEddInt <=29) && (uEmmInt == 2) && (uEleapYear == 0 && uEyyInt > 0) && (arrayEDu[2].equals("/")) && (arrayEDu[5].equals("/")))
                			|| ((uEddInt >= 1 && uEddInt <=28) && (uEmmInt == 2) && (uEyyInt > 0) && (arrayEDu[2].equals("/")) && (arrayEDu[5].equals("/"))))
                	{
                		uProceedEndDate = true;
                		for (int i = 0; i != list.getLength(); ++i) {
                            Node child = list.item(i);
                            if (child.getNodeName().equals("endDate")) {
                                child.getFirstChild().setNodeValue(endDate);
                            }
         
                        }
                        transformer.transform(source, result);
                        room.get(position).setEndDate(endDate);
                        break;
                	}
                	else
                		System.out.println("Error Input! Please enter a valid end date.");
                }
                	else
                		System.out.println("Error Input! Please enter an end date that is later than the start date.");
                }
                else
                	System.out.println("Error Input! Please enter a valid length of end date.");
                
            	}break;
            case 5:
            	while(uProceedWifi != true){
                System.out.println("Enter (Y/N) for WIFI enabling: ");
                wifi = sc.nextLine();
 
                if(wifi.equals("Y")|| wifi.equals("N"))
                {
                	uProceedWifi = true;
                	for (int i = 0; i != list.getLength(); ++i) {
                        Node child = list.item(i);
                        if (child.getNodeName().equals("wifi")) {
                            child.getFirstChild().setNodeValue(wifi);
                        }
     
                    }
                    transformer.transform(source, result);
                    room.get(position).setWifi(wifi);
                    break;
                }
                else
                	System.out.println("Error Input! Please only enter (Y/N) for Wifi enabling.");
                }break;
            case 6:
            	while(uProceedRmView != true){
                System.out.println("Enter (Y/N) for room facing with view: ");
                roomView = sc.nextLine();
 
                if(roomView.equals("Y") || roomView.equals("N"))
                {
                	uProceedRmView = true;
                	for (int i = 0; i != list.getLength(); ++i) {
                        Node child = list.item(i);
                        if (child.getNodeName().equals("roomView")) {
                            child.getFirstChild().setNodeValue(roomView);
                        }
     
                    }
                    transformer.transform(source, result);
                    room.get(position).setRoomView(roomView);
                 
                }
                else
                	System.out.println("Error Input! Please only enter (Y/N) for room facing with view.");
            	}break;
            case 7:
            	while(uProceedSmoking != true){
                System.out.println("Smoking-friendly room (Y/N): ");
                smoking = sc.nextLine();
                
                if(smoking.equals("Y") || smoking.equals("N"))
                {
                	uProceedSmoking = true;
                	for (int i = 0; i != list.getLength(); ++i) {
                        Node child = list.item(i);
                        if (child.getNodeName().equals("smoking")) {
                            child.getFirstChild().setNodeValue(smoking);
                        }
     
                    }
                    transformer.transform(source, result);
                    room.get(position).setSmoking(smoking);
                    break;
                }
                else
                	System.out.println("Error Input! Please only enter (Y/N) for Smoking-friendly room.");
            	}break;
            case 8:
            	  String availability="";
            	while(uProceedAvail != true){
                System.out.println("Change availability of room:\n1.Vacant\n2.Occupied\n3.Reserved\n4.Under Maintenance ");
                available = sc.nextInt();
                sc.nextLine();
              
                if(available >= 1 && available <= 4)
                {
                	uProceedAvail = true;
                	
                    switch(available){
                    case 1: availability = "Vacant";break;
                    case 2: availability = "Occupied";break;
                    case 3: availability = "Reserved";break;
                    case 4: availability = "Under Maintenance";break;
                    }
                    for (int i = 0; i != list.getLength(); ++i) {
                        Node child = list.item(i);
                        if (child.getNodeName().equals("availability")) {
                            child.getFirstChild().setNodeValue(availability);
                        }
     
                    }
                    transformer.transform(source, result);
                    room.get(position).setAvailibility(availability);break;
                
                }
                else
                	System.out.println("Incorrect input! Please select an option between (1) to (4).");
            	}
            	
                break;
            case 0:
                break;
            }
 
        }
 
        catch (Exception e) {
            e.printStackTrace();
        }
 
    }
	
	/**
	* Method to search for if room already exist in the system
	* @param roomNo room number to be validated
	* @param room Single Room object in the System
	* @return flag -1 if room does not exist , 1 if room exist in the system
	*/ 
	public int validateRoomNo(String roomNo,ArrayList<Room> room) {
		int flag = -1;

		for(int i=0;i<room.size();i++){
			if(roomNo.equals(room.get(i).getRoomNo())){
			flag = 1;//room exist
			}
		}
		return flag;
	}
}

