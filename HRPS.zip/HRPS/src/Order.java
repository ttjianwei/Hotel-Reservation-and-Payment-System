/**
 * The Room service Order entity
 * @author FSP4 group 5
 *
 */
public class Order {
	/**
	 * Order;s room number
	 */
	private String roomNo;
	/**
	 * The item that is ordered by customer
	 */
	private String item;
	/**
	 * Total price of the items ordered
	 */
	private String totalPrice;
	/**
	 * Status of the order
	 */
	private String status;
	/**
	 * Order time of the Order
	 */
	private String orderTime;
	/**
	 * Any other remarks for customer order
	 */
	private String remarks;
	
	/**
	 *Default Constructor
	 */
	public Order()
	{
		roomNo="";
		item="";
		totalPrice="";
		status="";
		orderTime="";
		remarks="";
	}
	
	/**
	 * Constructor of Order
	 * @param rn The room number of the order
	 * @param i The food items that is ordered
	 * @param tp The total price of the items ordered
	 * @param s The status of the order
	 * @param ot The order time
	 * @param r Any other remarks
	 */
	public Order(String rn, String i, String tp, String s, String ot,String r)
	{
		roomNo=rn;
		item=i;
		totalPrice=tp;
		status=s;
		orderTime=ot;
		remarks=r;
		
	}
	
	
	/**
	 * Get the room number of the order
	 * @return roomNo The room number of the order
	 */
	public String getRoomNo(){return roomNo;}
	
	/**
	 * Changed the room number of the order
	 * @param rn The room number to be change
	 */
	public void setRoomNo(String rn){roomNo=rn;}
	
	/**
	 * Get the food item of the order
	 * @return item Food item of the order
	 */
	public String getItem(){return item;}
	
	/**
	 * Changed the food item of the order
	 * @param i The food item
	 */
	public void setItem(String i){item =i;}
	
	/**
	 * Get the total price of the order
	 * @return totalPrice The price of the order
	 */
	public String getTotalPrice(){return totalPrice;}
	
	/**
	 * Change the total price of the order
	 * @param tp Total price of the order
	 */
	public void setTotalPrice(String tp){totalPrice=tp;}
	
	/**
	 * Get the status of the order
	 * @return Status of the order
	 */
	public String getStatus(){return status;}
	
	/**
	 * Changed the order status
	 * @param s The order status
	 */
	public void setStatus(String s){status = s;}
	
	/**
	 * Get the order time
	 * @return The time when the order is created
	 */
	public String getOrderTime(){return orderTime;}
	
	/**
	 * Changed the order time 
	 * @param ot The order time
	 */
	public void setOrderTime(String ot){orderTime = ot;}
	
	/**
	 * Get any remarks the customer had made
	 * @return The remarks of the order
	 */
	public String getRemarks(){return remarks;}
	
	/**
	 * Changed the remarks of the order
	 * @param r The remarks 
	 */
	public void setRemarks(String r){remarks = r;}
}
