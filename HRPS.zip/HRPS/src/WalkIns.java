/**
Represent a Walk-in Guest's details in the System
A system can has many walk-in details
@author FSP4
@version 1.0
@since 2016-04-06
*/ 

public class WalkIns {
	/**
	* roomNo room number of choice
	*/ 
	protected String roomNo;
	/**
	* roomType Type of room preference by guest
	*/
	protected String roomType;
	/**
	* bedType Type of bed preference by guest
	*/
	protected String bedType;
	/**
	* smoking smoking preference of guest
	*/
	protected String smoking;
	/**
	* roomStartDate start date of room
	*/
	protected String roomStartDate;
	/**
	* roomEndDate end date of room
	*/
	protected String roomEndDate;
	/**
	* wifi wifi preference of guest
	*/
	protected String wifi;
	/**
	* roomView Room view preference of guest
	*/
	protected String roomView;
	/**
	* roomAvailability Availability of room
	*/
	protected String roomAvailability;
	/**
	* checkInStatus check-in status of guest
	*/
	protected String checkInStatus;
	/**
	* guestName name of guest
	*/
	protected String guestName;
	/**
	* guestAddress address of guest
	*/
	protected String guestAddress;
	/**
	* guestContacts contacts of guest
	*/
	protected String guestContacts;
	/**
	* guestGender Gender of guest
	*/
	protected String guestGender;
	/**
	* guestCountry Country of guest
	*/
	protected String guestCountry;
	/**
	* guestIdentity Identity of guest
	*/
	protected String guestIdentity;
	/**
	* guestNationality Nationality of guest
	*/
	protected String guestNationality;
	/**
	* guestguestCreditCardNo credit card number of guest
	*/
	protected String guestCreditCardNo;
	/**
	* guestIdentity credit card CSV code of guest
	*/
	protected String guestCreditCardCSV;
	/**
	* guestCreditCardExpDate credit card expiry date
	*/
	protected String guestCreditCardExpDate;
	/**
	* numberOfGuest number of guest
	*/
	protected String numberOfGuest;
	/**
	* checkInDate date of check-in
	*/
	protected String checkInDate;
	/**
	* checkInTime time of check-in
	*/
	protected String checkInTime;
	
/**
*Default Walk-In constructor to create an instance of walk-in class
*/ 
	
public WalkIns(){		
	}

/**
* Walk-In constructor with walk-in guests details
* @param roomNo room number of requested room by guest
* @param roomType room type preference of guest
* @param bedType bed type preference of guest
* @param smoking smoking preference of guest
* @param guestNationality nationality of guest
* @param roomStartDate start date of room
* @param roomEndDate end date of room
* @param availability current availability of room
* @param guestCountry country of guest
* @param wifi wifi preference of guest
* @param numberOfGuest number of guest 
* @param guestName name of guest
* @param guestAddress address of guest
* @param guestContacts contacts of guest
* @param guestGender gender of guest
* @param guestIdentity identity of guest
* @param guestCreditCardNo credit card number of guest
* @param guestCreditCardCSV credit card CSV code of guest
* @param guestCreditCardExpDate credit card expiry date of guest
* @param checkInStatus Check in status of current room
* @param roomView room view preference of current room
*/ 
public WalkIns(String roomNo,String roomType,String bedType,String smoking
		,String roomStartDate,String roomEndDate,String wifi,String roomView,
		String availability,String checkInStatus,String guestName,String guestAddress,String guestContacts,String guestCountry,
		String guestGender,String guestNationality,String guestIdentity,String guestCreditCardNo,String guestCreditCardCSV,
		String guestCreditCardExpDate,String numberOfGuest){
	
	this.roomNo = roomNo;
	this.roomType = roomType;
	this.bedType = bedType;
	this.smoking = smoking;
	this.guestNationality = guestNationality;
	this.roomStartDate = roomStartDate;
	this.roomEndDate = roomEndDate;
	this.roomAvailability = availability;
	this.guestCountry = guestCountry;
	this.wifi = wifi;
	this.numberOfGuest = numberOfGuest;
	this.roomView = roomView;
	this.guestName = guestName;
	this.guestAddress = guestAddress;
	this.guestContacts = guestContacts;
	this.guestGender = guestGender;
	this.guestIdentity = guestIdentity;
	this.guestCreditCardNo = guestCreditCardNo;
	this.guestCreditCardCSV = guestCreditCardCSV;
	this.guestCreditCardExpDate = guestCreditCardExpDate;
	this.checkInStatus = checkInStatus;
	
}

/**
* Method to get room number 
* @return roomNo room's number(String)
*/ 
public String getRoomNo(){
	return roomNo;
}
/**
* Method to get room type
* @return roomType room's type(String)
*/ 
public String getRoomType(){
	return roomType;
}
/**
* Method to get the bed type
* @return bedType bed's type(String)
*/ 
public String getBedType(){
	return bedType;
}
/**
* Method to get the guest smoking preference
* @return smoking guest's room smoking preference(String)
*/ 
public String getSmoking(){
	return smoking;
}
/**
* Method to get the room start date 
* @return roomStartDate room's start date(String)
*/ 
public String getRoomStartDate(){
	return roomStartDate;
}
/**
* Method to get the room end date 
* @return roomEndDate room's end date(String)
*/ 
public String getRoomEndDate(){
	return roomEndDate;
}
/**
* Method to get the room wifi preference
* @return wifi room's wifi preference(String)
*/ 
public String getRoomWifi(){
	return wifi;
}
/**
* Method to get the room view preference
* @return roomView room view preference(String)
*/ 
public String getRoomView(){
	return roomView;
}
/**
* Method to get the room's availability
* @return roomAvaiability room's availability(String)
*/ 
public String getAvailability(){
	return roomAvailability;
}
/**
* Method to get the guest's name 
* @return guestName guest's name(String)
*/ 
public String getGuestName(){
	return guestName;
}
/**
* Method to get the guest's address 
* @return guestAddress guest's address(String)
*/ 
public String getGuestAddress(){
	return guestAddress;
}
/**
* Method to get the guest's contacts
* @return guestContacts guest's contacts(String)
*/ 
public String getGuestContacts(){
	return guestContacts;
}
/**
* Method to get the guest's gender
* @return guestGender guest's gender(String)
*/ 
public String getGuestGender(){
	return guestGender;
}
/**
* Method to get the guest's country 
* @return guestCountry guest's country(String)
*/ 
public String getCountry(){
	return guestCountry;
}
/**
* Method to get the guest's identity
* @return guestIdentity guest's identity(String)
*/
public String getGuestIdentity(){
	return guestIdentity;
}
/**
* Method to get the guest's credit card number 
* @return guestCreditCardNo guest's credit card number(String)
*/
public String getCreditCardNo(){
	return guestCreditCardNo;
}
/**
* Method to get the guest's credit expiry date
* @return guestCreditCardExpDate guest's credit card expiry date(String)
*/
public String getCreditCardExpDate(){
	return guestCreditCardExpDate;
}
/**
* Method to get the guest's credit card CSV 
* @return guestCreditCardCSV guest's credit card CSV code(String)
*/
public String getCreditCardCSV(){
	return guestCreditCardCSV;
}
/**
* Method to set room number
* @param roomNo new room number
*/
public void setRoomNo(String roomNo){
this.roomNo = roomNo;
}
/**
* Method to set room type
* @param roomType new room type
*/
public void setRoomType(String roomType){
	this.roomType = roomType;
}
/**
* Method to set bedType
* @param bedType new type of bed
*/
public void setbedType(String bedType){
	this.bedType = bedType;
}
/**
* Method to set smoking preference
* @param smoking new smoking preference
*/
public void setSmoking(String smoking){
	this.smoking = smoking;
}
/**
* Method to set start date of room
* @param roomStartDate new start date of room
*/
public void setRoomStartDate(String roomStartDate){
	this.roomStartDate = roomStartDate;
}
/**
* Method to set end date of room
* @param roomEndDate new end date of room
*/
public void setRoomEndDate(String roomEndDate){

 this.roomEndDate = roomEndDate;
}
/**
* Method to set wifi preference of room
* @param wifi new wifi preference of room
*/
public void setResWifi(String wifi){
	this.wifi = wifi;
}
/**
* Method to set room view preference of room
* @param roomView new room view preference of room
*/
public void setResRoomView(String roomView){
	this.roomView = roomView;
}
/**
* Method to get room view preference of room
* @return roomView return room view preference of room
*/
public String getResRoomView(){
	return this.roomView;
}
/**
* Method to set guest name
* @param guestName new guest name
*/
public void setGuestName(String guestName){
	this.guestName = guestName;
}
/**
* Method to set guest contact
* @param guestContacts new guest contact
*/
public void setGuestContacts(String guestContacts){
	this.guestContacts = guestContacts;
}
/**
* Method to set guest address
* @param guestAddress new guest address
*/
public void setGuestAddress(String guestAddress){
	this.guestAddress = guestAddress;
}
/**
* Method to set new guest gender
* @param guestGender new guest name
*/
public void setGuestGender(String guestGender){
	this.guestGender = guestGender;
}
/**
* Method to set new identity of guest
* @param guestIdentity new guest identity
*/
public void setGuestIdentity(String guestIdentity){
	this.guestIdentity = guestIdentity;
}
/**
* Method to set new credit card number of guest
* @param creditCardNo new credit card number of guest 
*/
public void setCreditCardNo(String creditCardNo){
	this.guestCreditCardNo = creditCardNo;
}
/**
* Method to set new credit card CSV code of guest
* @param creditCardCSV new credit card CSV code of guest 
*/
public void setCreditCardCSV(String creditCardCSV){
	this.guestCreditCardCSV = creditCardCSV;
}
/**
* Method to set new credit card expiry date
* @param creditCardExpDate new credit card expiry date  
*/
public void setCreditCardExpDate(String creditCardExpDate){
	this.guestCreditCardExpDate = creditCardExpDate;
}
/**
* Method to set new room availability
* @param availability new room availability 
*/
public void setRoomAvailability(String availability){
	roomAvailability = availability;
}
/**
* Method to get guest nationality
* @return guestNationality(String)
*/ 
 public String getGuestNationality(){
	return guestNationality;
}
 /**
 * Method to set new guest nationality
 * @param guestNationality new guest's nationality 
 */
public void setGuestNationality(String guestNationality){
	this.guestNationality = guestNationality;
}
/**
* Method to get number of guest
* @return numberOfGuest(String);
*/ 
public String getNoOfGuest(){
	return numberOfGuest;
}
/**
* Method to set new number of guest
* @param noOfGuest new number of guest
*/ 
public void setNoOfGuest(String noOfGuest){

this.numberOfGuest = noOfGuest;
}
/**
* Method to get check in status
* @return checkInStatus Check In status(String)
*/ 
public String getCheckInStatus(){
  return checkInStatus;
}
/**
* Method to set new check in status
* @param checkInStatus new check in status
*/ 
public void setCheckInStatus(String checkInStatus){
	this.checkInStatus = checkInStatus ;
}


}
