

/**
Represent a reservation and it's details in the system
A system can have many reservations
@author FSP4
@version 1.0
@since 2016-04-06
*/ 
public class Reservation extends WalkIns {
	/**
	* Reservation ID of reservation 
	*/ 
	private String resId;
	/**
	* Reservation status of reservation
	*/ 
	private String resStatus;
	/**
	* Check In Date of reservation
	*/ 
	private String checkInDate;
	/**
	* Check in Time of reservation
	*/ 
	private String checkInTime;
	/**
	* Check in status of reservation
	*/ 
	private String checkInStatus;
	
	
	/**
	* Constructor for an instance of the reservation object
	*/ 
	public Reservation(){
		
	}
	
	
	/**
	* Reservation details
	* @param resId reservation ID
	* @param resStatus status of reservation
	* @param checkInDate date of check In
	* @param checkInTime time of check in
	* @param resRoomNo room number of requested room by guest
	* @param resRoomType room type preference of guest
	* @param resBedType bed type preference of guest
	* @param resSmoking smoking preference of guest
	* @param guestNationality nationality of guest
	* @param resRoomStartDate start date of room
	* @param resRoomEndDate end date of room
	* @param resAvailability current availability of room
	* @param guestCountry country of guest
	* @param resWifi wifi preference of guest
	* @param numberOfGuest number of guest 
	* @param guestName name of guest
	* @param guestAddress address of guest
	* @param guestContacts contacts of guest
	* @param guestGender gender of guest
	* @param guestIdentity identity of guest
	* @param guestCreditCardNo credit card number of guest
	* @param guestCreditCardCSV credit card CSV code of guest
	* @param guestCreditCardExpDate credit card expiry date of guest
	* @param checkInStatus Check in status of current room
	* @param resRoomView room view preference
	*/ 
	public Reservation(String resId,String resRoomNo,String resRoomType,String resBedType,String resSmoking
			,String resRoomStartDate,String resRoomEndDate,String resWifi,String resRoomView,
			String resAvailability,String checkInStatus,String guestName,String guestAddress,String guestContacts,String guestCountry,
			String guestGender,String guestNationality,String guestIdentity,String guestCreditCardNo,String guestCreditCardCSV,
			String guestCreditCardExpDate,String numberOfGuest,String resStatus,String checkInDate,String checkInTime){
		/**
		* Reservation ID of reservation
		*/ 
		this.resId = resId;
		/**
		* Room number of room reserved
		*/ 
		this.roomNo= resRoomNo;
		/**
		* Room type of room reserved
		*/ 
		this.roomType = resRoomType;
		/**
		* Bed type of room reserved
		*/ 
		this.bedType = resBedType;
		/**
		* smoking preference of room reserved
		*/ 
		this.smoking = resSmoking;
		/**
		* Nationality of guest 
		*/ 
		this.guestNationality = guestNationality;
		/**
		* start date of room reserved
		*/ 
		this.roomStartDate = resRoomStartDate;
		/**
		* end date of room reserved
		*/ 
		this.roomEndDate = resRoomEndDate;
		/**
		* Availability of room reserved
		*/ 
		this.roomAvailability = resAvailability;
		/**
		* Country of guest
		*/ 
		this.guestCountry = guestCountry;
		/**
		* wifi preference of room reserved
		*/ 
		this.wifi = resWifi;
		/**
		* number of guest for room reserved 
		*/ 
		this.numberOfGuest = numberOfGuest;
		/**
		* room view preference of room reserved
		*/ 
		this.roomView = resRoomView;
		/**
		* name of guest
		*/ 
		this.guestName = guestName;
		/**
		* address of guest
		*/ 
		this.guestAddress = guestAddress;
		/**
		* contact of guest
		*/ 
		this.guestContacts = guestContacts;
		/**
		* gender of guest
		*/ 
		this.guestGender = guestGender;
		/**
		* Identity of guest
		*/ 
		this.guestIdentity = guestIdentity;
		/**
		* Credit card number of guest
		*/ 
		this.guestCreditCardNo = guestCreditCardNo;
		/**
		* Credit card number CSV code of guest
		*/ 
		this.guestCreditCardCSV = guestCreditCardCSV;
		/**
		* Credit card expiry date of guest
		*/ 
		this.guestCreditCardExpDate = guestCreditCardExpDate;
		/**
		* Status of Reservation
		*/ 
		this.resStatus = resStatus;
		/**
		* check in date of reservation 
		*/ 
		this.checkInDate = checkInDate;
		/**
		* check in time of reservation 
		*/
		this.checkInTime = checkInTime;
		/**
		* check in status of reservation 
		*/
		this.checkInStatus = checkInStatus;
		
	}
	/**
	* method to get room number
	* @return roomNo room number of room reserved 
	*/
	public String getResRoomNo(){
		return super.getRoomNo();
	}
	/**
	* method to get room type
	* @return roomType room type of room reserved 
	*/
	public String getResRoomType(){
		return super.getRoomType();
	}
	/**
	* method to get bed type
	* @return bedType bed type of room reserved 
	*/
	public String getResBedType(){
		return super.getBedType();
	}
	/**
	* method to get smoking preference
	* @return isSmoking return smoking preference of guest
	*/
	public String getResSmoking(){
		return super.getSmoking();
	}
	/**
	* method to get room start date
	* @return roomStartDate return room start date
	*/
	public String getResRoomStartDate(){
		return super.getRoomStartDate();
	}
	/**
	* method to get room start date
	* @return roomStartDate return room start date
	*/
	public String getResRoomEndDate(){
		return super.getRoomEndDate();
	}
	/**
	* method to get room start date
	* @return roomStartDate return room start date
	*/
	public String getResRoomWifi(){
		return super.getRoomWifi();
	}
	/**
	* method to get room view preference
	* @return roomView room view preference
	*/
	public String getResRoomView(){
		return super.getRoomView();
	}
	/**
	* method to get room availability
	* @return room return room availability
	*/
	public String getResAvailability(){
		return super.roomAvailability;
	}
	
	/**
	* method to get guest name
	* @return guestName return name of guest
	*/
	public String getGuestName(){
		return super.getGuestName();
	}
	/**
	* method to get guest address
	* @return guestAddress return address of guest
	*/
	public String getGuestAddress(){
		return super.getGuestAddress();
	}
	/**
	* method to get guest contacts
	* @return guestContacts return contacts of guest
	*/
	public String getGuestContacts(){
		return super.getGuestContacts();
	}
	
	/**
	* method to get guest gender
	* @return guestGender return gender of guest
	*/
	public String getGuestGender(){
		return super.getGuestGender();
	}
	/**
	* method to get guest country
	* @return guestCountry return country of guest
	*/
	public String getCountry(){
		return super.getCountry();
	}
	/**
	* method to get guest identity
	* @return guestIdentity return identity of guest
	*/
	public String getGuestIdentity(){
		return super.getGuestIdentity();
	}
	/**
	* method to get guest credit card number
	* @return creditCardNo return number of credit card
	*/
	public String getCreditCardNo(){
		return super.getCreditCardNo();
	}
	/**
	* method to get guest credit card expiry date
	* @return creditCardExpDate return credit card expiry date
	*/
	public String getCreditCardExpDate(){
		return super.getCreditCardExpDate();
	}
	/**
	* method to get guest credot card CSV
	* @return creditCardCSV return credit card CSV
	*/
	public String getCreditCardCSV(){
		return super.getCreditCardCSV();
	}
	
	/**
	* method to set new room number
	* @param roomNo new room number
	*/
	public void setRoomNo(String roomNo){
	super.setRoomNo(roomNo);
	}
	
	/**
	* method to set new room type
	* @param roomType new room type
	*/
	public void setRoomType(String roomType){
	super.setRoomType(roomType);
	}
	
	/**
	* method to set new bed type
	* @param bedType new bed type
	*/
	public void setbedType(String bedType){
		super.setbedType(bedType);
	}
	/**
	* method to set smoking preference
	* @param smoking guest's new smoking preference
	*/
	public void setSmoking(String smoking){
		super.setSmoking(smoking);
	}
	/**
	* method to set room start date
	* @param roomStartDate new start date of room
	*/
	public void setRoomStartDate(String roomStartDate){
		super.setRoomStartDate(roomStartDate);;
	}
	/**
	* method to set room end date
	* @param roomEndDate new end date of room
	*/
	public void setRoomEndDate(String roomEndDate){

	super.setRoomEndDate(roomEndDate);
}
	
	/**
	* method to set new wifi
	* @param wifi new wifi preference of guest
	*/
	public void setResWifi(String wifi){
		super.setResWifi(wifi);
	}

	/**
	* method to set new room view
	* @param roomView new room view preference of guest
	*/
	public void setResRoomView(String roomView){
		super.setResRoomView(roomView);
	}

	/**
	* method to set new guest name
	* @param guestName new guest name 
	*/
	public void setGuestName(String guestName){
		super.setGuestName(guestName);
	}
	/**
	* method to set new guest contacts
	* @param guestContacts new contacts of guests
	*/
	public void setGuestContacts(String guestContacts){
		super.setGuestContacts(guestContacts);
	}
	/**
	* method to set new guest address
	* @param guestAddress new address of guests
	*/
	public void setGuestAddress(String guestAddress){
		super.setGuestAddress(guestAddress);
	}
	/**
	* method to set new guest gender
	* @param guestGender new contacts of guests
	*/
	public void setGuestGender(String guestGender){
		super.setGuestGender(guestGender);
	}
	
	/**
	* method to set new guest identity
	* @param guestIdentity new identity of guest
	*/
	public void setGuestIdentity(String guestIdentity){
		super.setGuestIdentity(guestIdentity);
	}
	
	/**
	* method to set new credit card number
	* @param creditCardNo new credit card contacts
	*/
	public void setCreditCardNo(String creditCardNo){
		super.setCreditCardNo(creditCardNo);
	}
	
	/**
	* method to set new credit card CSV
	* @param creditCardCSV new credit card CSV code
	*/
	public void setCreditCardCSV(String creditCardCSV){
		super.setCreditCardCSV(creditCardCSV);
	}
	
	/**
	* method to set new credit card expiry date
	* @param creditCardExpDate new credit card expiry date
	*/
	public void setCreditCardExpDate(String creditCardExpDate){
		super.setCreditCardExpDate(creditCardExpDate);
	}
	
	/**
	* method to set new room availability
	* @param availability new room availability status
	*/
	public void setResAvailability(String availability){
		super.setRoomAvailability(availability);
	}
	/**
	* method to get reservation ID
	* @return resId Reservation ID of reservation
	*/
	public String getResID(){
		return resId;
	}
	/**
	* method to set new reservation ID
	* @param ResID new reservation ID
	*/
	public void setResID(String ResID){
		this.resId = ResID;
	}
	/**
	* method to get guest nationality
	* @return guestNationality new nationality of guest
	*/
	public String getGuestNationality(){
		return super.getGuestNationality();
	}
	/**
	* method to set new guest nationality
	* @param guestNationality new nationality of guest
	*/
	public void setGuestNationality(String guestNationality){
	super.setGuestNationality(guestNationality);
	}
	/**
	* method to get number of guest
	* @return noOfGuest returns number of guest
	*/
	public String getNoOfGuest(){
		return super.getNoOfGuest();
	}
	/**
	* method to set new number of guest
	* @param noOfGuest new number of guest
	*/
	public void setNoOfGuest(String noOfGuest){
	super.setNoOfGuest(noOfGuest);
	}
	/**
	* method to set new reservation status
	* @param resStatus new reservation status
	*/
	public void setResStatus(String resStatus){
		
	this.resStatus = resStatus;
	}
	
	/**
	* method to get new reservation status
	* @return resStatus return new reservation status
	*/
	public String getResStatus(){
		return resStatus;
	}
	
	/**
	* method to get check in date 
	* @return checkInDate return new check in date
	*/
	public String getCheckInDate(){
		return checkInDate;
	}

	/**
	* method to get check in time 
	* @return checkInTime return new check in time
	*/
	public String getCheckInTime(){
		return checkInTime;
	}
	/**
	* method to set check in date
	* @param checkInDate new check in date
	*/
	public void setCheckInDate(String checkInDate){
		this.checkInDate = checkInDate;
	}
	/**
	* method to set check in time
	* @param checkInTime return new check in time
	*/
	public void setCheckInIime(String checkInTime){
		this.checkInTime = checkInTime;
	}
	/**
	* method to set check in status
	* @return checkInStatus return new check in status
	*/
	public String getCheckInStatus(){
	  return checkInStatus;
	}
	
	/**
	* method to set check in status
	* @param checkInStatus return new check in status
	*/
	public void setCheckInStatus(String checkInStatus){
		this.checkInStatus = checkInStatus ;
	}
	
	}
