import java.util.*;
import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
Walk in menu that contains methods to control walk-in objects
@author FSP4
@version 1.0
@since 2016-04-06
*/ 
public class WalkInMenu {
	/**
	 * Scanner object used to read user Input
	 */
	Scanner sc = new Scanner(System.in);
	
	ReservationMenu rm = new ReservationMenu();
	
	
	/**
	 * method to create a walkIns object and write to walkIn.xml
	 * @param guests Collection of guests objects that exists in the system
	 * @param room Collection of rooms objects that exists in the systems
	 * @param walkIn Collection of walk in details objects in the system
	 * @param reservation Collection of reservation details objects in the system
	 */
	public void CreateWalkIn(ArrayList<Guest> guests, ArrayList<Room> room,ArrayList<WalkIns> walkIn, ArrayList<Reservation> reservation){
		/**
		 * instance of guest menu object
		 */
		GuestMenu gm = new GuestMenu();
		/**
		 * instance of room menu object
		 */
		RoomMenu rmenu = new RoomMenu();
		/**
		 * instance of inputOutput object
		 */
		InputOutput inOut = new InputOutput();
		boolean proceed = false;
		Guest currGuest = null;
		Room currRoom = null;
		int noOfVacant = 0;
		String startDate="",endDate="",noOfGuest;
	

		
		for(int i = 0; i <reservation.size();i++){
			if(reservation.get(i).getAvailability().equals("Vacant")){
				noOfVacant++;
			}
		}
		if((reservation.size()==48)){
			if(noOfVacant==0)
				System.out.println("Rooms are all full!");
			return;
		}

		
		while(!proceed){
			System.out.println("1.) Exisiting Guest\n2.) New Guest\n3.) Previous Menu");
			int guestExist = sc.nextInt();
			if(guestExist == 3)return;
		switch(guestExist){
	
		case 1:
	
		 currGuest = rm.searchForGuest(guests);
	     break;
	     
		case 2:
			
			Guest tmpGuest = gm.createGuestDetails(guests);
			guests.add(tmpGuest);//create guest and store into ararylist of guests object
			currGuest = tmpGuest;
			inOut.writeToGuestFile(tmpGuest);//update guestList file
			break;
		
		case 3: break;
		}
		
		System.out.println("1.) Exisiting Room\n2.) New Room\n3.) Previous Menu");
		int userInput = sc.nextInt();
		if(userInput==3)return;
		switch(userInput){
		
		case 1:
	
			currRoom = rm.searchForRoom(room);
			
		while(!currRoom.getAvailability().equals("Vacant")){
			currRoom = rm.searchForRoom(room);	
		}	
		 break;
		 
		case 2:Room tmpRoom = rmenu.createRoomDetails(room); 
		currRoom = tmpRoom;
		room.add(currRoom);//create room and store into ararylist of room
		inOut.writeToRoomFile(currRoom);//update room file

			 break;
		case 3:break;
		}
		if((currRoom!= null && currGuest!=null)){
			proceed = true;
		}
		else {System.out.println("Guset and Room must exist!");}
		}
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yy");
		   //get current date time with Date()
		  //get current date time with Calendar()
		 Date now = new Date();
		 startDate = (String)dateFormat.format(now.getTime());	
		 boolean uProceedEndDate = false;
		 String ucopySD = startDate;
		 
		 while(uProceedEndDate != true){
	            System.out.println("Enter the end date of stay(MM/DD/YY): ");
	            endDate = sc.next();

	            if(endDate.length() == 8)
	            {
	            	//copy startdate
	            	String[] arraySDcopyu = ucopySD.split("", 8);
	            	
	            	String uSmm = arraySDcopyu[0] + arraySDcopyu[1];
	            	int uSmmInt = Integer.parseInt(uSmm);
					
	            	String uSdd = arraySDcopyu[3] + arraySDcopyu[4];
	            	int uSddInt = Integer.parseInt(uSdd);
	            	
	            	String uSyy = arraySDcopyu[6] + arraySDcopyu[7];
	            	int uSyyInt = Integer.parseInt(uSyy);
	            	
	            	//enddate
	            	String[] arrayEDu = endDate.split("", 8);
	            	
	            	String uEmm = arrayEDu[0] + arrayEDu[1];
	            	int uEmmInt = Integer.parseInt(uEmm);
	            	
	            	String uEdd = arrayEDu[3] + arrayEDu[4];
	            	int uEddInt = Integer.parseInt(uEdd);
					
	            	String uEyy = arrayEDu[6] + arrayEDu[7];
	            	int uEyyInt = Integer.parseInt(uEyy);
	            	int uEleapYear = uEyyInt%4;
	            	
	            	//making sure end date is older than start date
	            	if((uEyyInt > uSyyInt) || (uEyyInt >= uSyyInt && uEmmInt > uSmmInt) || (uEyyInt >= uSyyInt && uEmmInt >= uSmmInt && uEddInt > uSddInt))
	            	{
	            	
	            		//making sure there is a valid end date entered given the right mm/dd/yy
	            	if(((uEddInt >= 1 && uEddInt <= 31) && (uEmmInt == 1 || uEmmInt == 3 || uEmmInt == 5 || uEmmInt == 7 || uEmmInt == 8 || uEmmInt == 10 || uEmmInt == 12) && (uEyyInt > 0) && (arrayEDu[2].equals("/")) && (arrayEDu[5].equals("/")))
	            			|| ((uEddInt >= 1 && uEddInt <= 30) && (uEmmInt == 4 || uEmmInt == 6 || uEmmInt == 9 || uEmmInt == 11) && (uEyyInt > 0) && (arrayEDu[2].equals("/")) && (arrayEDu[5].equals("/")))
	            			|| ((uEddInt >= 1 && uEddInt <=29) && (uEmmInt == 2) && (uEleapYear == 0 && uEyyInt > 0) && (arrayEDu[2].equals("/")) && (arrayEDu[5].equals("/")))
	            			|| ((uEddInt >= 1 && uEddInt <=28) && (uEmmInt == 2) && (uEyyInt > 0) && (arrayEDu[2].equals("/")) && (arrayEDu[5].equals("/"))))
	            	{
	            		uProceedEndDate = true;
	 
	            	}
	            	else
	            		System.out.println("Error Input! Please enter a valid end date.");
	            }
	            	else
	            		System.out.println("Error Input! Please enter an end date that is later than the start date.");
	            }
	            else
	            	System.out.println("Error Input! Please enter a valid length of end date.");
	            
	        	}
			
		
		 
		 
		 
		 System.out.println("Number of Guest: ");
		 noOfGuest= sc.next();
		 
		 currRoom.setStartDate(startDate);
		 currRoom.setEndDate(endDate);
		 currRoom.setAvailibility("Occupied");
		 rmenu.updateRoomDatesAndAvailabilityInFile(rmenu.searchForRoom(room.size(), room,currRoom.getRoomNo()),startDate,endDate,currRoom.getAvailability());
		 
	     WalkIns tempWi = new WalkIns(currRoom.getRoomNo(),currRoom.getRoomType(),currRoom.getBedType(),currRoom.isSmoking()
				,startDate,endDate,currRoom.isWifi(),currRoom.isRoomView(),
				currRoom.getAvailability(),"Y",currGuest.getGuestName(),currGuest.getAddress(),currGuest.getContact(),currGuest.getCountry(),
				currGuest.getGender(),currGuest.getNationality(),currGuest.getIdentity(),currGuest.getCreditCardNo(),currGuest.getCreditCardCSV(),
				currGuest.getCreditCardExpDate(),noOfGuest); 
	   
	     walkIn.add(tempWi);//Add walk-in guest object into arrayList
	     inOut.writeToWalkInFile(tempWi);
		
	}
	
	/**
	* method to remove a Walk in from the system
	* @param position position of WalkIns to be removed
	* @param w Collection of WalkInObjects in the system 
	*/
	public void removeWalkin(int position,ArrayList<WalkIns> w)
	{
		w.remove(position);
		try{
		
			File file = new File("walkIn.xml");
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			Document doc = builder.parse(file);
			Element element = (Element)doc.getElementsByTagName("walkIn").item(position);
			if ( null != element) {

			element.getParentNode().removeChild(element);
			
		  	TransformerFactory transformerFactory = TransformerFactory.newInstance();
		  	Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);
				
			StreamResult result = new StreamResult(new File("walkIn.xml"));
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			transformer.transform(source, result);
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	
}
